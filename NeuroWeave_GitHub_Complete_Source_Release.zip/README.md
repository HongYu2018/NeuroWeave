# NeuroWeave: sparse neural circuits and continual visual recognition

Reproducible research implementation and archived numerical evidence associated with the manuscript **What Enables Neural Networks to Learn Without Replaying the Past? Neuron Complexity, Readout Interference and Sparse Circuit Adaptation** (target journal: *Neural Networks*).

The research examines three related but separate architectural questions: (1) whether stable sparse neural graphs can add recognised classes through compact class-indexed memory, (2) whether individual dendritic complexity improves over nonlinear point neurons, and (3) whether old-class prediction failures can arise from an expanding classifier even when the feature graph is unchanged. A separate CIFAR-10 graph-construction analysis compares stochastic and guided wiring with a different sensory encoder and task-specific readouts.

**What the results do not show:** this is not a general-purpose agent, an autonomous discovery of globally optimal circuit topology, or proof that point neurons are universally better than dendritic neurons. The different experimental protocols must not be statistically pooled.

## 1. Repository layout

| Folder | Description |
| --- | --- |
| `experiments/protected_core/` | Complete runnable source for the sparse 32-neuron graph, point and dendritic variants, compact class prototypes, soma-integrated branch proposals, COIL-100, digits, official-data CIFAR-10 loader and regression tests. |
| `experiments/readout_audit/` | Complete runnable source for the frozen-representation vs expanding-classifier diagnostic, zero-image-replay controls, prototype comparisons and regression tests. |
| `results/archived/` | Original COIL and digit CSV/JSON data, audit CSVs, verified result records, and the distinctly labelled CIFAR-10 transcribed aggregate. |
| `scripts/` | Windows scripts, result checks and portable research helpers. |
| `paper/` | LaTeX manuscript source, bibliography, vector figures and figure-generator source. |
| `.github/workflows/tests.yml` | CPU tests and archived-result check on GitHub Actions. |

The two experimental codebases intentionally have **different modules with the same Python package name** `neuro_weave`. Always execute them from their respective experiment folders, rather than combining their Python modules into one import path.

## 2. Requirements and supported environment

* Windows 10/11 PowerShell, macOS or Linux.
* Recommended Python: **3.11**. Do not rely on bleeding-edge Python/PyTorch combinations.
* PyTorch 2.2+; CUDA-capable PyTorch and NVIDIA GPU are optional for smoke tests, recommended for COIL-100 runs.
* NumPy, scikit-learn, Pillow, pandas, matplotlib and pytest (see `requirements.txt`).
* Internet for the first COIL-100 and official CIFAR-10 dataset downloads, unless already cached. Do not redistribute third-party image archives.

Original experiments did not save a complete dependency lockfile. Consequently, the archived CSV checks are reproducible exactly from the saved results, while new training runs may vary by environment, hardware kernels and package versions.

### Windows: one virtual environment without PowerShell activation

Open PowerShell in the repository root and run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
# Install the PyTorch wheel appropriate for your CUDA driver using the official instructions.
# Or, for CPU-only verification:
.\.venv\Scripts\python.exe -m pip install torch
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -c "import torch; print('Torch:',torch.__version__,'CUDA:',torch.cuda.is_available())"
```

You do not need to run `Activate.ps1`, so an unsigned-script execution policy does not block the Python environment. If you want GPU acceleration, consult <https://pytorch.org/get-started/locally/> and install the wheel corresponding to the driver and CUDA platform before installing other packages. Running `pip install torch` by itself does not guarantee a CUDA-enabled build.

### Linux/macOS

```bash
python3.11 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install torch
.venv/bin/python -m pip install -r requirements.txt
```

## 3. Run the tests first

Windows, from the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_TESTS_WINDOWS.ps1
```

Linux/macOS:

```bash
(cd experiments/protected_core && ../../.venv/bin/python -m pytest -q tests)
(cd experiments/readout_audit && ../../.venv/bin/python -m pytest -q tests)
.venv/bin/python scripts/verify_recorded_results.py
```

The preparation environment passed **25 tests with 2 CUDA-only skips** for the protected-core code and **51 tests with 4 CUDA-only skips** for the readout audit. The archived-result verification checks the COIL and digit headline values independently from the paper's text. GPU-only and real dataset results have to be checked on the research team's machines.

## 4. Verify the existing results without retraining

From the repository root:

```powershell
.\.venv\Scripts\python.exe .\scripts\verify_recorded_results.py
```

The checker reads `results/archived/COIL_v21_seed11/summary.csv`, all five `digits_seedNN/summary.csv` files, and the COIL readout audit records. It verifies known means and selected row-level values. The CIFAR-10 CSV contains an independently transcribed aggregate from a different protocol, for which the original per-seed logs were not included in the available source archive; see `results/archived/CIFAR10_PROVENANCE.md`.

## 5. Repeat the protected-core experiments

### COIL-100, single-seed, 36 classes

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_COIL_WINDOWS.ps1
```

Uses 24 initial classes, three increments of 4, seed 11, four labelled supports for each new category, a 32-neuron sparse graph, 30 source-training epochs and 20 candidate fitting steps. The experiment writes to `experiments/protected_core/results/coil_seed11/`, including `summary.csv`, `configuration.json`, `development_events.csv`, `per_class_accuracy.csv`, `training_summary.json`, checkpoints and graph topology JSON.

Dataset loader: `experiments/protected_core/neuro_weave/data.py`. Raw COIL-100 images are obtained from the Columbia University dataset host, under `experiments/protected_core/data/coil100/images`. The public image dataset is **not included** here. Source/training/validation/query splits are defined in the code; train and query viewpoints are disjoint.

### Digits, five seeded repeats

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_DIGITS_5SEEDS_WINDOWS.ps1
```

Seeds 11, 12, 13, 14 and 15, six initial categories followed by two groups of two new classes, four training examples per class. Digits are loaded from `sklearn.datasets.load_digits` and processed by the same protected-core driver. Results are saved to `experiments/protected_core/results/digits_seedNN/`.

### Official CIFAR-10 loader (different, not-yet-run protected-core protocol)

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_CIFAR10_PROTECTED_CORE_WINDOWS.ps1
```

This is a **new runnable protected-core CIFAR-10 procedure** using the official five training batches and test batch with MD5 verification. It is not a reproduction of the paper's separate CNN-to-graph results. No accuracy result from this command appears in the paper. The complete archived CIFAR-10 graph-construction source and seed-level raw data are unavailable in this release, and no result is claimed for them. Do not merge these conditions.

## 6. Repeat the zero-image-replay readout diagnostic

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_ZERO_REPLAY_AUDIT_WINDOWS.ps1
```

Runs the COIL readout audit with no old raw-image training replay, 24 initial plus 12 new object categories (in increments of four). The experiment includes expanding-classifier controls, protected-prototype readouts and a frozen-feature diagnostic. It produces a distinct output folder. Key measurements:

* `old_only_accuracy`: old-label accuracy when competing only with previously learned classes.
* `old_full_accuracy`: old-label accuracy among all current classes.
* `old_predictions_as_new_fraction`: percentage of old queries assigned to newer labels.
* `graph_representation_RMSE`: feature drift between checkpoints; zero for a completely frozen representation.

**Training data policy:** this experiment may retain feature prototypes or online importance statistics. No raw old-image replay does not mean zero memory. The frozen-feature readout experiment establishes recognition-access failure without changing the graph, not biological synaptic consolidation.

## 7. Regenerate manuscript figures

From the repository root:

```powershell
.\.venv\Scripts\python.exe .\paper\make_figures.py
```

`paper/figures/generate_architecture.py` regenerates the vector architecture diagram without raw images. The other figures are drawn from the archived CSV files. The paper can be compiled using pdfLaTeX/BibTeX (or upload the separate Overleaf ZIP); figures are committed as PDF vector artwork.

## 8. Map between the paper and the source

| Paper component | Code or record location |
| --- | --- |
| Sparse point and dendritic computational graph | `experiments/protected_core/neuro_weave/model.py` |
| Class-indexed memory and soma branches | `experiments/protected_core/neuro_weave/assemblies_v21.py` |
| Class schedule, support/query splits | `experiments/protected_core/neuro_weave/continual.py` and `data.py` |
| Protected-core experiment driver and outputs | `experiments/protected_core/neuro_weave/assemblies_v21_run.py`, `results/archived/COIL_v21_seed11`, `digits_seedNN` |
| Frozen representation/readout diagnostic | `experiments/readout_audit/neuro_weave/continual_v166.py`, `results/archived/COIL_v166_audit_*.csv` |
| CIFAR-10 graph-construction aggregate | `results/archived/cifar10_graph_protocol_two_seed_means.csv` and provenance note; original training source not available |
| Official CIFAR-10 alternative runner | `experiments/protected_core/neuro_weave/data.py`, `RUN_CIFAR10_V21_PILOT.ps1` (unrun) |
| Headline results confirmation | `scripts/verify_recorded_results.py` |
| Scientific figures | `paper/make_figures.py` and `paper/figures/generate_architecture.py` |

## 9. Uploading the folder to GitHub

Do not publish private correspondence, `.env` files, downloaded datasets, local virtual environments or personal identifiers. The archive already excludes those. Choose an open-source licence with the research team before making the repository public; no licence or institutional permission is assumed.

```powershell
git init
git add .
git commit -m "Initial NeuroWeave research source and archived results"
git branch -M main
# Create an empty repository on github.com first, then use its REAL URL:
git remote add origin https://github.com/YOUR-ORGANISATION/YOUR-REPOSITORY.git
git push -u origin main
```

Do **not** leave the placeholder remote URL unchanged. Prepare a `CITATION.cff` with confirmed author details and manuscript information, and obtain the actual public repository URL or archival DOI before placing it in the journal's Data and Code Availability section.

## 10. Scientific and reproducibility qualifications

* Protected-core COIL-100 is a single seeded run; digit results are five independent seeds. These figures are not equally precise estimates.
* The readout diagnostic and the protected-core algorithms are different training and decision systems. Their outcome differences cannot be treated as the causal effect of a single intervention.
* Point-neuron parameter counts are approximately, not computation/FLOP, matched.
* Class-associated prototypes and paths are preserved **by design**; the code does not prove spontaneous memory consolidation.
* A reference to an earlier branch is not itself proof of beneficial transfer. Ablations show within-model dependence but do not establish cross-task causal reuse.
* CIFAR-10 CNN-to-graph means come from a two-seed aggregate under a **different** protocol. The original implementation/logs are still needed for full independent reproduction of that table. The included official-data CIFAR-10 runner cannot be substituted for them.
* No numerical results have been invented for unexecuted experiments. Metadata and scientific claims should be reviewed before journal submission.
