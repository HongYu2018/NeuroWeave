$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$py = Join-Path $root '.venv\Scripts\python.exe'
Push-Location (Join-Path $root 'experiments\protected_core')
try {
 & $py -m neuro_weave.assemblies_v21_run --dataset coil100 --seed 11 --source-classes 24 --novel-classes 12 --increment 4 --initial-shots 4 --new-shots 4 --max-val 18 --image-size 16 --neurons 32 --epochs 30 --steps 20 --branch-fanin 8 --temperature 12 --branch-gain 0.35 --reuse 3 --accept-threshold 0.01 --data-root data --output results/coil_seed11
 if ($LASTEXITCODE -ne 0) { throw 'COIL experiment failed' }
} finally { Pop-Location }
