"""Check numerical claims directly against archived CSVs. Uses only pandas/numpy."""
from pathlib import Path
import pandas as pd
import numpy as np
D=Path(__file__).resolve().parents[1]/'results'/'archived'
coil=pd.read_csv(D/'COIL_v21_seed11/summary.csv')
digits=pd.concat([pd.read_csv(D/f'digits_seed{i}/summary.csv') for i in range(11,16)],ignore_index=True)
audit=pd.read_csv(D/'COIL_v166_audit_continual_metrics.csv')
comp=pd.read_csv(D/'COIL_v166_audit_old_new_competition.csv')

cases=[
('2.1 COIL fixed dendritic',coil,'dendritic_prototype',3,'accuracy_all',.837963),
('2.1 COIL fixed point',coil,'point_prototype',3,'accuracy_all',.851080),
('2.1 COIL adapted point matched',coil,'point_budget_adaptive_linear',3,'accuracy_all',.862654),
('Audit frozen dendritic old',audit,'frozen_prototype',3,'old_test_accuracy',.825521),
('Audit frozen point old',audit,'point_frozen_prototype',3,'old_test_accuracy',.870660),
('Audit frozen graph old',audit,'fixed_head_only',3,'old_test_accuracy',.053819),
]
for label,d,key,stage,col,expected in cases:
    vals=d.loc[(d.method==key)&(d.stage==stage),col]
    assert len(vals)==1,(label,len(vals))
    actual=float(vals.iloc[0]); assert abs(actual-expected)<0.0003,(label,actual,expected)
    print(f'{label}: {actual*100:.2f}%')
for method,expected in [('dendritic_prototype',.734583),('point_budget_prototype',.76125)]:
    vals=digits[(digits.method==method)&(digits.stage==2)]
    assert len(vals)==5
    mean=vals.accuracy_all.mean();assert abs(mean-expected)<0.0006,(method,mean)
    print(f'Digits {method}, five seeds: {100*mean:.2f}% mean, {100*vals.accuracy_all.std(ddof=1):.2f}% SD')
# verify no claims are being taken from actual test sets for candidate selection
assert len(coil[coil.stage==3])==8
print('Validated headline values and archived seed counts.')
