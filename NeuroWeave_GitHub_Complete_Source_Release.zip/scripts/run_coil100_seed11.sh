#!/usr/bin/env bash
# Run from the NeuroWeave_2_1 source directory, with the official COIL-100 dataset accessible.
set -euo pipefail
python -m neuro_weave.assemblies_v21_run \
  --dataset coil100 --data-root data --output results/v21_coil_seed11 \
  --seed 11 --source-classes 24 --novel-classes 12 --increment 4 \
  --initial-shots 4 --new-shots 4 --max-val 12 --image-size 16 \
  --neurons 32 --epochs 30 --lr .015 --steps 20 --plastic-lr .05 \
  --branch-fanin 8 --temperature 12 --branch-gain .35 \
  --reuse 3 --accept-threshold .01
