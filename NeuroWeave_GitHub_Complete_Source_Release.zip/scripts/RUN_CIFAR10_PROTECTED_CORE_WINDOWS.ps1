$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$py = Join-Path $root '.venv\Scripts\python.exe'
Push-Location (Join-Path $root 'experiments\protected_core')
try {
 & $py -m neuro_weave.assemblies_v21_run --dataset cifar10 --source-classes 6 --novel-classes 4 --increment 2 --initial-shots 4 --new-shots 4 --max-val 12 --image-size 16 --neurons 32 --epochs 30 --steps 20 --seed 11 --data-root data --output results/cifar10_protected_core_seed11
 if ($LASTEXITCODE -ne 0) { throw 'CIFAR-10 experiment failed' }
} finally { Pop-Location }
