$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$py = Join-Path $root '.venv\Scripts\python.exe'
Push-Location (Join-Path $root 'experiments\protected_core')
try {
  foreach ($seed in 11..15) {
    & $py -m neuro_weave.assemblies_v21_run --dataset digits --seed $seed --source-classes 6 --novel-classes 4 --increment 2 --initial-shots 4 --new-shots 4 --max-val 12 --image-size 16 --neurons 32 --epochs 30 --steps 20 --branch-fanin 8 --temperature 12 --branch-gain 0.35 --reuse 3 --accept-threshold 0.01 --data-root data --output "results/digits_seed$seed"
    if ($LASTEXITCODE -ne 0) { throw "Digit run failed for seed $seed" }
  }
} finally { Pop-Location }
