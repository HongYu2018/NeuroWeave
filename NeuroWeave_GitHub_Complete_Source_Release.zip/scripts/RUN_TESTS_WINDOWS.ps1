$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$python = Join-Path $root '.venv\Scripts\python.exe'
if (!(Test-Path $python)) { throw 'Create .venv first using py -3.11 -m venv .venv' }
Push-Location (Join-Path $root 'experiments\protected_core')
try { & $python -m pytest -q tests; if ($LASTEXITCODE -ne 0) { throw 'Protected-core tests failed' } }
finally { Pop-Location }
Push-Location (Join-Path $root 'experiments\readout_audit')
try { & $python -m pytest -q tests; if ($LASTEXITCODE -ne 0) { throw 'Readout-audit tests failed' } }
finally { Pop-Location }
& $python (Join-Path $root 'scripts\verify_recorded_results.py')
if ($LASTEXITCODE -ne 0) { throw 'Archived-result verification failed' }
