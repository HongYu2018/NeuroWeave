# Citation metadata to complete before publication

After the team confirms authorship and the repository URL, create a valid `CITATION.cff`, for example:

```yaml
cff-version: 1.2.0
message: Please cite this software.
title: NeuroWeave: sparse neural graphs and continual visual recognition
type: software
authors:
  - family-names: REPLACE_ME
    given-names: REPLACE_ME
```

Do not claim a DOI or published journal article until the relevant publisher or archive assigns it.
