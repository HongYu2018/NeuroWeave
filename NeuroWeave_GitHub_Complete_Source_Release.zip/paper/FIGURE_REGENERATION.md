# Figure regeneration

From the repository root (with numpy, pandas and matplotlib installed):

```powershell
.\.venv\Scripts\python.exe paper\make_figures.py
```

The source uses `results/archived/` files and saves vector PDFs in `paper/figures/`. `F8_cifar10_graph_protocol.pdf` uses the separately transcribed two-seed CIFAR-10 aggregate. Since raw seed-level CIFAR logs were not included in the available sources, that figure shows no uncertainty bars. The architecture drawing is generated from `paper/figures/generate_architecture.py`, and the protected-core COIL/digit figures use recorded CSVs.
