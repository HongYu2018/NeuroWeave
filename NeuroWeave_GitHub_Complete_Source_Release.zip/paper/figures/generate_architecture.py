"""Regenerate Figure 1 as a journal-ready vector diagram; no external files needed."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch, Rectangle, FancyArrowPatch

OUT=Path(__file__).resolve().parent
INK='#233747'; MUTED='#556D7F'; RULE='#A7B7C2'; CORE='#26718A'; PLASTIC='#A46E38'; MEMORY='#42775B'
plt.rcParams.update({'font.family':'DejaVu Sans','pdf.fonttype':42,'ps.fonttype':42})
fig, ax=plt.subplots(figsize=(12.5,8.25),facecolor='white')
ax.set_xlim(0,12.5); ax.set_ylim(0,8.25); ax.axis('off')

def text(x,y,s,fs=12,weight='normal',ha='center',color=INK,va='center',rotation=0):
    return ax.text(x,y,s,fontsize=fs,fontweight=weight,ha=ha,va=va,color=color,rotation=rotation,linespacing=1.22)
def line(x1,y1,x2,y2,color=MUTED,lw=1.35,style='solid'):
    ax.plot([x1,x2],[y1,y2],color=color,lw=lw,ls=style,solid_capstyle='round')
def arrow(x1,y1,x2,y2,color=MUTED,lw=1.4,style='solid'):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=13,linewidth=lw,linestyle=style,color=color,shrinkA=0,shrinkB=0))
def rounded(x,y,w,h,edge=RULE,fill='white',radius=0.10,lw=1.15):
    p=FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0.0,rounding_size={radius}',edgecolor=edge,facecolor=fill,lw=lw)
    ax.add_patch(p)
    return p
def panel(y,h,letter,title):
    ax.add_patch(Rectangle((0.26,y),12.0,h,edgecolor='#9AAAB6',facecolor='white',lw=1.1))
    text(.50,y+h-.22,letter,14,'bold',ha='left',color=CORE)
    text(.85,y+h-.22,title,13.6,'bold',ha='left')

def node(x,y,edge=CORE,fill='#DDEBF1',radius=.135):
    ax.add_patch(Circle((x,y),radius,facecolor=fill,edgecolor=edge,lw=1.4,zorder=3))

text(6.25,8.02,'NeuroWeave: experimental architecture and class-expansion protocol',16.0,'bold')
text(6.25,7.70,'Fixed somatic population | optional soma-integrated branches | compact class-indexed recognition memory',10.8,color=MUTED)

# ---------------- Panel A: real graph and operator ---------------------
panel(5.10,2.38,'A','Source learning: sparse neural representation')
rounded(.52,5.84,1.55,.91,edge='#B7C8D2',fill='#F6FAFC')
text(1.30,6.39,'Visual input',11.7,'bold')
text(1.30,6.07,'COIL-100 / digits',10.3)
arrow(2.11,6.28,2.55,6.28)
text(2.91,6.57,'Image vector',11.5,'bold')
text(2.91,6.20,'$d = 768$',11,color=MUTED)
arrow(3.35,6.28,3.68,6.28)
# actual sparse dag visible with no cross-label arrow interference
xs=[3.94,4.88,5.90,6.87]
coords=[(3.94,6.77),(3.94,6.30),(3.94,5.83),(4.93,6.56),(4.93,6.03),(5.90,6.77),(5.90,6.30),(5.90,5.83),(6.87,6.30)]
edges=[(0,3),(1,3),(1,4),(2,4),(0,6),(3,5),(3,6),(4,6),(4,7),(5,8),(6,8),(7,8)]
for a,b in edges:
    x1,y1=coords[a];x2,y2=coords[b]
    arrow(x1+.16,y1,x2-.17,y2,color='#859AA8',lw=1.10)
for k,(x,y) in enumerate(coords): node(x,y,edge=CORE,fill='#E1EDF3' if k!=8 else '#D6E7DE')
text(5.35,5.44,'32 nonlinear neurons | sparse, ordered DAG | no prescribed hidden-layer stack',10.25,color=MUTED)
arrow(7.10,6.30,7.47,6.30)
# side-by-side operator inset intentionally no arrows through labels
rounded(7.48,5.72,2.18,1.26,edge='#A19BB5',fill='#F9F7FB',lw=1.05)
text(8.57,6.79,'Dendritic neuron',11.6,'bold',color='#65518A')
# branch circles, soma circle
for xx,yy in [(7.82,6.28),(8.10,6.28),(8.38,6.28),(8.66,6.28)]:
    node(xx,yy,edge='#8E7BAB',fill='#EEE9F5',radius=.09)
    line(xx+.10,yy,9.20,6.28,color='#A796BC',lw=1.05)
node(9.20,6.28,edge='#6E5A91',fill='#E2D8F1',radius=.14)
text(8.56,5.92,'4 branches + soma term',9.0,color='#65518A')
rounded(9.90,5.72,2.08,1.26,edge='#B9A386',fill='#FBF9F6',lw=1.05)
text(10.94,6.79,'Point-neuron control',11.0,'bold',color='#805B34')
node(10.48,6.28,edge='#A67E53',fill='#F1E2D3',radius=.14)
arrow(10.65,6.28,11.08,6.28,color='#9B7A57',lw=1.1)
text(11.51,6.28,r'$\tanh$',11.3,color='#805B34')
text(10.93,5.92,'single nonlinear soma',10,color='#805B34')
text(6.21,5.24,'Graph weights are frozen after source training and throughout class enrolment.',9.8,color=MUTED)

# ---------------- Panel B: genuine enrollment protocol ------------------
panel(2.66,2.28,'B','Expansion: four labelled supports per unfamiliar class, no old-image replay')
rounded(.54,3.21,1.69,1.00,edge='#C1A37C',fill='#FFF9F0')
text(1.38,3.90,'New category',11.1,'bold')
text(1.38,3.56,'4 labelled supports',10.4)
arrow(2.25,3.72,2.65,3.72)
rounded(2.65,3.38,1.86,.72,edge='#C1A37C',fill='#FFF9F0')
text(3.58,3.86,'Candidate fit',11.5,'bold')
text(3.58,3.60,'2 supports',10.1)
arrow(4.53,3.72,4.91,3.72)
# split existing path or novel
rounded(4.91,3.78,1.72,.43,edge='#9BAEBB',fill='#F4F8FA')
text(5.77,3.995,'Reuse stored path',10.5)
rounded(4.91,3.23,1.72,.43,edge='#9BAEBB',fill='#F4F8FA')
text(5.77,3.445,'New soma branch',10.4)
line(4.70,3.72,4.70,3.45,color=CORE,lw=1)
arrow(4.70,3.45,4.89,3.45,color=CORE)
# validation on two other supports, then accept
arrow(6.65,3.99,7.03,3.99)
arrow(6.65,3.45,7.03,3.45)
rounded(7.03,3.30,2.02,.88,edge='#C1A37C',fill='#FFF9F0')
text(8.04,3.88,'Accept / reject',11.6,'bold')
text(8.04,3.57,'other 2 supports',10.3)
arrow(9.08,3.72,9.46,3.72)
rounded(9.46,3.21,2.48,1.00,edge=MEMORY,fill='#F1F8F3')
text(10.70,3.90,'Protected class trace',10.7,'bold',color=MEMORY)
text(10.70,3.59,'prototype + selected path',10.2)
text(6.25,2.90,'Only current-class support images guide fitting and selection; earlier prototypes remain available as compact memory.',10.2,color=MUTED)

# ---------------- Panel C: inference and diagnostics -------------------
panel(.39,2.10,'C','Inference and diagnostic comparisons')
rounded(.54,1.12,1.44,.75,edge='#A3B5C2',fill='#F7FAFC')
text(1.26,1.61,'Query image',10.7,'bold')
text(1.26,1.31,'unknown class',9.9)
arrow(2.00,1.50,2.36,1.50)
rounded(2.36,1.12,2.00,.75,edge=CORE,fill='#EEF5F8')
text(3.36,1.60,'Shared graph',11.8,'bold')
text(3.36,1.31,'with class path $P_c$',10.0)
arrow(4.38,1.50,4.75,1.50)
# prototype bank shown as matrix rather than box
text(5.77,1.99,'Class prototype bank',10.4,'bold',color=MEMORY)
for i in range(4):
    for j in range(6):
        ax.add_patch(Rectangle((4.95+.26*j,1.26+.15*i),.20,.105,facecolor=['#D7E9DD','#B9D6C4','#7BA88A'][((i+j)%3)],edgecolor='white',lw=.4))
text(5.77,1.05,r'$m_c \in \mathbb{R}^{32}$',10.4,color=MUTED)
arrow(6.75,1.50,7.13,1.50)
rounded(7.13,1.12,1.89,.75,edge='#9CADB6',fill='#F7FAFC')
text(8.07,1.60,'Joint decision',11.7,'bold')
text(8.07,1.31,'$\u005chat y=\u005carg\u005cmax_c s_c(x)$',10.2)
arrow(9.05,1.50,9.42,1.50)
rounded(9.42,1.09,2.52,.84,edge='#A3B5C2',fill='#F7FAFC')
text(10.68,1.71,'Reported outcomes',11.6,'bold')
text(10.68,1.40,'accuracy; old/new balance',10.0)
text(10.68,1.18,'branch ablation; storage',10.0)
text(6.25,.67,'Baseline versus adapted | full versus old-only scores | dendritic versus point neurons | COIL-100 versus digits',10.1,color=MUTED)

for ext in ('pdf','svg','png'):
    fig.savefig(OUT/f'F1_architecture.{ext}',dpi=240 if ext=='png' else None,bbox_inches='tight',pad_inches=.07)
plt.close(fig)
print('Figure 1 vector PDF, SVG and PNG created')
