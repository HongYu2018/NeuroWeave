# Bibliography source audit

**Total unique BibTeX entries:** 46. **Keys cited by the manuscript:** 46. **Identifiable source records located:** 46 (including one bibliographic index and one institution-hosted technical report).

A BibTeX entry compiling without errors does not validate its real-world existence or every metadata field. The table distinguishes publisher/conference/dataset records, a reputable bibliography index and an institution-hosted technical report. All entries have an identifiable source, although source identification is not equivalent to independent verification of every metadata field. Authors should perform a final DOI-click check before submission. The report should not be interpreted as independent validation of every author initial or issue number.

## Concrete corrections in this audit

* iCaRL: corrected CVPR page range from 2001–2010 to **5533–5542**.
* PODNet: corrected DOI to **10.1007/978-3-030-58565-5_6**.
* End-to-End Incremental Learning: matched the CVF-published **233–248** page range and retained the valid LNCS DOI, which may use different book pagination.
* Progressive Neural Networks: completed the arXiv author list.
* Added primary-source URLs for several conference papers and the historical dataset entry.

| Key | Status | Primary work URL |
|---|---|---|
| `zhou2024survey` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/39012754/ |
| `rebuffi2017icarl` | publisher/conference/dataset primary record checked | https://mlanthology.org/cvpr/2017/rebuffi2017cvpr-icarl/ |
| `li2018lwf` | publisher/conference/dataset primary record checked | https://doi.org/10.1109/TPAMI.2017.2773081 |
| `wu2019bias` | publisher/conference/dataset primary record checked | https://openaccess.thecvf.com/content_CVPR_2019/html/Wu_Large_Scale_Incremental_Learning_CVPR_2019_paper.html |
| `kirkpatrick2017ewc` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/28292907/ |
| `zenke2017si` | publisher/conference/dataset primary record checked | https://proceedings.mlr.press/v70/zenke17a.html |
| `dohare2024plasticity` | publisher/conference/dataset primary record checked | https://doi.org/10.1038/s41586-024-07711-7 |
| `fernando2017pathnet` | publisher/conference/dataset primary record checked | https://research.google/pubs/pathnet-evolution-channels-gradient-descent-in-super-neural-networks/ |
| `rusu2016progressive` | publisher/conference/dataset primary record checked | https://arxiv.org/abs/1606.04671 |
| `feillet2025reality` | publisher/conference/dataset primary record checked | https://openaccess.thecvf.com/content/WACV2025/html/Feillet_A_Reality_Check_on_Pre-training_for_Exemplar-free_Class-Incremental_Learning_WACV_2025_paper.html |
| `he2025shift` | publisher/conference/dataset primary record checked | https://proceedings.mlr.press/v267/he25d.html |
| `chavlis2025dendrites` | publisher/conference/dataset primary record checked | https://www.nature.com/articles/s41467-025-56297-9 |
| `nene1996coil` | publisher/conference/dataset primary record checked | https://www.cs.columbia.edu/CAVE/software/softlib/coil-100.php |
| `sklearnDigits` | publisher/conference/dataset primary record checked | https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html |
| `alpaydin1998cascading` | publisher/conference/dataset primary record checked | https://www.kybernetika.cz/content/1998/4/369 |
| `wu2026communication` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/42328205/ |
| `yao2026foundation` | publisher/conference/dataset primary record checked | https://www.nature.com/articles/s41467-026-77929-8 |
| `reed2022gato` | publisher/conference/dataset primary record checked | https://mlanthology.org/tmlr/2022/reed2022tmlr-generalist/ |
| `yang2026survey` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/41183437/ |
| `huang2026agents` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/41489969/ |
| `krizhevsky2009cifar` | technical report indexed at institution | https://www.cs.toronto.edu/~kriz/learning-features-2009-TR.pdf |
| `parisi2019continual` | publisher/conference/dataset primary record checked | https://doi.org/10.1016/j.neunet.2019.01.012 |
| `delange2021continual` | publisher/conference/dataset primary record checked | https://doi.org/10.1109/TPAMI.2021.3057446 |
| `mccloskey1989catastrophic` | publisher/conference/dataset primary record checked | https://www.sciencedirect.com/science/article/pii/S0079742108605368 |
| `french1999catastrophic` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/10322466/ |
| `lopezpaz2017gem` | publisher/conference/dataset primary record checked | https://proceedings.neurips.cc/paper/2017/hash/f87522788a2be2d171666752f97ddebb-Abstract.html |
| `shin2017generative` | publisher/conference/dataset primary record checked | https://proceedings.neurips.cc/paper/2017/hash/0efbe98067c6c73dba1250d2beaa81f9-Abstract.html |
| `castro2018end` | publisher/conference/dataset primary record checked | https://www.ecva.net/papers/eccv_2018/papers_ECCV/html/Francisco_M._Castro_End-to-End_Incremental_Learning_ECCV_2018_paper.php |
| `aljundi2019gradient` | publisher/conference/dataset primary record checked | https://proceedings.neurips.cc/paper/2019/hash/e562cd9c0768d5464b64cf61da7fc6bb-Abstract.html |
| `buzzega2020dark` | publisher/conference/dataset primary record checked | https://papers.nips.cc/paper/2020/hash/b704ea2c39778f07c617f6b7ce480e9e-Abstract.html |
| `douillard2020podnet` | publisher/conference/dataset primary record checked | https://mlanthology.org/eccv/2020/douillard2020eccv-podnet/ |
| `yoon2018den` | publisher/conference/dataset primary record checked | https://mlanthology.org/iclr/2018/yoon2018iclr-lifelong/ |
| `mallya2018packnet` | publisher/conference/dataset primary record checked | https://openaccess.thecvf.com/content_cvpr_2018/html/Mallya_PackNet_Adding_Multiple_CVPR_2018_paper.html |
| `serra2018hat` | publisher/conference/dataset primary record checked | https://proceedings.mlr.press/v80/serra18a.html |
| `aljundi2017expertgate` | publisher/conference/dataset primary record checked | https://openaccess.thecvf.com/content_cvpr_2017/html/Aljundi_Expert_Gate_Lifelong_CVPR_2017_paper.html |
| `stanley2002neat` | publisher/conference/dataset primary record checked | https://doi.org/10.1162/106365602320169811 |
| `mel1994information` | bibliographic index checked; publisher page blocked | https://dblp.org/rec/journals/neco/Mel94 |
| `poirazi2003pyramidal` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/12670427/ |
| `london2005dendritic` | publisher/conference/dataset primary record checked | https://www.annualreviews.org/content/journals/10.1146/annurev.neuro.28.061604.135703 |
| `guerguiev2017segregated` | publisher/conference/dataset primary record checked | https://doi.org/10.7554/eLife.22901 |
| `richards2019deep` | publisher/conference/dataset primary record checked | https://pubmed.ncbi.nlm.nih.gov/31659335/ |
| `lake2017building` | publisher/conference/dataset primary record checked | https://www.cambridge.org/core/journals/behavioral-and-brain-sciences/article/building-machines-that-learn-and-think-like-people/A9535B1D745A0377E16C590E14B94993 |
| `lecun2015deep` | publisher/conference/dataset primary record checked | https://www.nature.com/articles/nature14539 |
| `silver2021reward` | publisher/conference/dataset primary record checked | https://www.sciencedirect.com/science/article/pii/S0004370221000862 |
| `fedus2022switch` | publisher/conference/dataset primary record checked | https://www.jmlr.org/papers/v23/21-0998.html |
| `lepikhin2021gshard` | publisher/conference/dataset primary record checked | https://research.google/pubs/gshard-scaling-giant-models-with-conditional-computation-and-automatic-sharding/ |

### Audit boundary

This report records identifiable publications or dataset/software records for all 46 citations based on primary pages, indexed institutional reports or bibliographic indices; it is **not** a machine-verified certification of every author initial, issue number, page and DOI through a complete live Crossref export. The bibliography retains some standard `and others` abbreviation where full author lists were not compared in detail.
