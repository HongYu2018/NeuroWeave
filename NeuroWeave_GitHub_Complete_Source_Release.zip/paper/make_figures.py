from pathlib import Path
import pandas as pd, numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
D=Path(__file__).parent; F=D/'figures'; F.mkdir(exist_ok=True)
coil=pd.read_csv(D.parent/'results'/'archived'/'COIL_v21_seed11'/'summary.csv'); co=coil[coil.stage==3].copy()
dig=pd.concat([pd.read_csv(D.parent/'results'/'archived'/f'digits_seed{i}'/'summary.csv') for i in range(11,16)]); dd=dig[dig.stage==2]
lab={
'dendritic_prototype':'Dendritic, fixed','dendritic_adaptive_dendritic':'Dendritic, adapted','dendritic_adaptive_novelty_guided':'Dendritic, guided','dendritic_adaptive_linear_control':'Dendritic, linear branch','point_prototype':'Point, fixed','point_adaptive_linear':'Point, adapted','point_budget_prototype':'Point, budget matched','point_budget_adaptive_linear':'Point, budget matched + adapted'}
order=list(lab)
colors=['#087E8B','#087E8B','#087E8B','#087E8B','#B06431','#B06431','#B06431','#B06431']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'savefig.bbox':'tight','savefig.pad_inches':0.15})
# Figure 1 is generated from an independent, editable vector source.
from runpy import run_path
run_path(str(F/'generate_architecture.py'))

def arrow(x1,y1,x2,y2):
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='-|>',lw=1.4,color='#486275'))

# fig 2 cross dataset final accuracy
fig,axs=plt.subplots(1,2,figsize=(12.7,5.25),gridspec_kw={'width_ratios':[1,1.12]})
for a in axs: a.axvline(3.5,color='#D4DDE2',lw=1);a.grid(axis='x',color='#E8EDF0',lw=.6);a.set_axisbelow(True)
a=axs[0];co=co.set_index('method');vals=[100*co.loc[k,'accuracy_all'] for k in order]; y=np.arange(8);a.barh(y,vals,color=colors,alpha=.83,height=.63);a.set_yticks(y, [lab[k] for k in order],fontsize=8.4);a.invert_yaxis();a.set_xlim(65,92);a.set_xlabel('Final joint-class accuracy (%)');a.set_title('(a) COIL-100, 36 classes; seed 11',weight='bold');
for i,v in enumerate(vals): a.text(v+.12,i,f'{v:.1f}',va='center',fontsize=8)
a=axs[1];means=dd.groupby('method')['accuracy_all'].mean();sds=dd.groupby('method')['accuracy_all'].std();vals=np.array([100*means[k] for k in order]); errs=np.array([100*sds[k] for k in order]);a.barh(y,vals,xerr=errs,color=colors,alpha=.83,height=.63,error_kw={'capsize':2,'elinewidth':1,'ecolor':'#333333'});a.set_yticks(y,['']*8);a.invert_yaxis();a.set_xlim(60,85);a.set_xlabel('Final joint-class accuracy (%; mean ± SD)');a.set_title('(b) Handwritten digits, 10 classes; 5 seeds',weight='bold');
for i,v in enumerate(vals):a.text(v+errs[i]+.25,i,f'{v:.1f}',va='center',fontsize=8)
fig.tight_layout(w_pad=1.5);fig.savefig(F/'F2_cross_dataset.pdf');fig.savefig(F/'F2_cross_dataset.png',dpi=150);plt.close(fig)
# fig3 stage trajectories: d core and p budget prototype, d adaptive p adaptive
fig,axs=plt.subplots(1,2,figsize=(11.7,4.6))
styles=[('dendritic_prototype','Dendritic fixed','#087E8B','-'),('dendritic_adaptive_dendritic','Dendritic adapted','#087E8B','--'),('point_budget_prototype','Point matched fixed','#B06431','-'),('point_budget_adaptive_linear','Point matched adapted','#B06431','--')]
for key,name,c,ls in styles:
 a=axs[0];s=coil[coil.method==key].sort_values('stage');a.plot(s.seen_classes,100*s.accuracy_all,marker='o',color=c,ls=ls,label=name,lw=2,ms=4)
 avg=dig[dig.method==key].groupby('seen_classes')['accuracy_all'].agg(['mean','std']).reset_index()
 a=axs[1];a.errorbar(avg.seen_classes,100*avg['mean'],yerr=100*avg['std'],fmt='o',ls=ls,color=c,label=name,lw=1.6,capsize=2,ms=4)
for a,title in zip(axs,['(a) COIL-100: 24 + 4 + 4 + 4','(b) Digits: 6 + 2 + 2']):a.set_title(title,weight='bold');a.set_xlabel('Number of learned classes');a.set_ylabel('Joint-class accuracy (%)');a.grid(alpha=.24)
axs[0].legend(loc='lower left',fontsize=8);axs[1].legend(loc='lower left',fontsize=8)
fig.tight_layout();fig.savefig(F/'F3_stage_trajectories.pdf');fig.savefig(F/'F3_stage_trajectories.png',dpi=150);plt.close(fig)
# fig4 readout
old=pd.read_csv(D.parent/'results'/'archived'/'COIL_v166_audit_old_new_competition.csv')
print('competition headings:',old.columns.tolist())
print(old[old.stage==3].head().to_string(index=False)[:1200])
# fig 4 ablation all; paired method vs its own intervention (not no-branch)
fig,axs=plt.subplots(1,2,figsize=(11.8,4.9))
keys=['dendritic_adaptive_dendritic','dendritic_adaptive_novelty_guided','dendritic_adaptive_linear_control','point_adaptive_linear','point_budget_adaptive_linear'];
short=['Dendritic\nstochastic','Dendritic\nguided','Dendritic\nlinear','Point\nlinear','Point matched\nlinear']
cv=[100*co.loc[k,'fixed_prototype_ablation_delta'] for k in keys]
dv=[100*dd[dd.method==k].fixed_prototype_ablation_delta.mean() for k in keys]
de=[100*dd[dd.method==k].fixed_prototype_ablation_delta.std() for k in keys]
for a,v,e,title in [(axs[0],cv,[0]*5,'(a) COIL-100, one seed'),(axs[1],dv,de,'(b) Digits, mean ± SD of 5 seeds')]:
 x=np.arange(len(keys));a.axhline(0,color='#566574',lw=1);a.bar(x,v,yerr=e if title.startswith('(b)') else None,capsize=3,color=['#087E8B']*3+['#B06431']*2,alpha=.85);a.set_xticks(x,short,fontsize=8);a.set_ylabel('Accuracy active minus all-branches-ablated (pp)');a.set_title(title,weight='bold');a.grid(axis='y',alpha=.2)
fig.tight_layout();fig.savefig(F/'F4_branch_ablation.pdf');fig.savefig(F/'F4_branch_ablation.png',dpi=150);plt.close(fig)
# fig5 readout interference numbers from original existing v166 source graph
import pathlib
p=D.parent/'results'/'archived'/'COIL_v166_audit_continual_metrics.csv';f=pd.read_csv(p)
print('v165 data columns:',f.columns.tolist())
# fig6 architecture decisions conceptual: from results > policy
fig,ax=plt.subplots(figsize=(11,3.7));ax.set(xlim=(0,12),ylim=(0,3.7));ax.axis('off')
block=[(0.2,'Preserve a compact\nshared representation','Frozen core / stable unit count','#DCEAF2'),(3.15,'Store class-level\nrecognition traces','Prototypes: zero image replay','#E5EFE5'),(6.1,'Test local plasticity\nonly where necessary','Soma branch + learned path','#F1E6D9'),(9.05,'Audit every extra\ncomputation','Ablation, memory and cost','#F1E5F1')]
for x,title,sub,col in block:
 ax.add_patch(FancyBboxPatch((x,1.15),2.65,1.6,boxstyle='round,pad=.07',fc=col,ec='#71808C',lw=1))
 ax.text(x+1.32,2.13,title,ha='center',va='center',fontweight='bold',fontsize=10,color='#22374E');ax.text(x+1.32,1.48,sub,ha='center',va='center',fontsize=8,color='#384A5D')
for x in [2.92,5.87,8.82]:arrow(x,1.95,x+.2,1.95)
ax.text(6,3.32,'Design inference from measured failures and controlled alternatives',ha='center',fontsize=13,weight='bold');ax.text(6,.4,'An engineering implication, not a validated universal architecture for language or multimodal reasoning',ha='center',fontsize=9,color='#526678')
fig.savefig(F/'F6_design_guidance.pdf');fig.savefig(F/'F6_design_guidance.png',dpi=150);plt.close(fig)
# export exact table dataset for supplementary
(D/'reproduced').mkdir(exist_ok=True); coil.to_csv(D/'reproduced'/'coil_v21_seed11.csv',index=False)
dig.to_csv(D/'reproduced'/'digits_v21_all_5seeds.csv',index=False)
print('Saved figures',sorted(x.name for x in F.iterdir()))
# Figure 5 decomposition from the audited COIL v1.6.6 seed; NOT an independent dataset
subset=old[(old.stage==3)&old.method.isin(['fixed_head_only','selective_plasticity','dendritic_prototype','point_prototype'])].copy()
print('Figure5 methods in audit:',old[old.stage==3].method.tolist())
keys=['fixed_head_only','selective_plasticity','frozen_dendritic_prototype','frozen_point_prototype']
# Rows' exact spelling in the audited logs can differ; use search on 'prototype'
rows=old[old.stage==3]
def getrow(terms):
 for term in terms:
  w=rows[rows.method.str.contains(term,case=False,regex=False)]
  if len(w):return w.iloc[0]
 return None
items=[('Frozen graph, trainable head',getrow(['fixed_head_only'])),('Selective plasticity',getrow(['selective_plasticity'])),('Dendritic fixed prototypes',getrow(['dendritic_prototype','frozen_prototype','frozen_dendritic','dendritic_frozen'])),('Point fixed prototypes',getrow(['point_prototype','frozen_point','point_frozen']))]
print([(l, None if r is None else r.method) for l,r in items])
if all(r is not None for l,r in items):
 fig,ax=plt.subplots(figsize=(9.7,4.8));x=np.arange(4);v1=np.array([100*float(r.old_only_accuracy) for l,r in items]);v2=np.array([100*float(r.old_full_accuracy) for l,r in items]);w=.35
 ax.bar(x-w/2,v1,width=w,label='Old-only discrimination',color='#087E8B');ax.bar(x+w/2,v2,width=w,label='Old-class accuracy under all-class competition',color='#C38A47');ax.set_xticks(x,[l.replace(', ','\n') for l,r in items]);ax.set_ylabel('Accuracy on old-class query images (%)');ax.set_ylim(0,103);ax.grid(axis='y',alpha=.2);ax.legend(loc='upper left',frameon=False,fontsize=9);ax.set_title('Representation versus readout: audit of 36-class COIL-100, seed 11',fontsize=12,weight='bold')
 for i in range(4):
  ax.text(i-w/2,v1[i]+1,f'{v1[i]:.1f}',fontsize=8,ha='center');ax.text(i+w/2,v2[i]+1,f'{v2[i]:.1f}',fontsize=8,ha='center')
 fig.tight_layout();fig.savefig(F/'F5_readout_interference.pdf');fig.savefig(F/'F5_readout_interference.png',dpi=150);plt.close(fig)
# CIFAR-10: a separate CNN-to-graph experiment. These are recorded two-seed
# aggregate values; original per-seed logs were not available in the archive.
cif=pd.read_csv(D.parent/'results'/'archived'/'cifar10_graph_protocol_two_seed_means.csv')
fig,ax=plt.subplots(figsize=(10.7,4.7))
x=np.arange(len(cif));w=0.25
c=('animals_mean_accuracy_pct','vehicles_mean_accuracy_pct','ten_class_mean_accuracy_pct')
for j,(key,name,color) in enumerate(zip(c,('Animals','Vehicles','All 10 classes'),('#6D9BA8','#C08B4C','#597B5E'))):
    ax.bar(x+(j-1)*w,cif[key],width=w,color=color,alpha=0.88,label=name)
ax.set_xticks(x,['Guided graph','Random graph','Linear probe','MLP teacher','Teacher + graph'],fontsize=8.5)
ax.set_ylabel('Mean test accuracy across two seeds (%)')
ax.set_ylim(0,90)
ax.set_title('CIFAR-10: task-specific readouts with a frozen CNN feature encoder',fontsize=11,weight='bold')
ax.grid(axis='y',alpha=0.18);ax.set_axisbelow(True)
ax.legend(frameon=False,loc='upper right',ncol=3,fontsize=8)
fig.tight_layout()
fig.savefig(F/'F8_cifar10_graph_protocol.pdf');fig.savefig(F/'F8_cifar10_graph_protocol.png',dpi=180);plt.close(fig)
print('Saved CIFAR-10 panel from separately labelled two-seed aggregate')
