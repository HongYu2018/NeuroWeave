$ErrorActionPreference = 'Stop'
$env:OMP_NUM_THREADS='1'
$env:MKL_NUM_THREADS='1'
foreach ($seed in @(11,12,13,14,15)) {
    Write-Host "Running scikit-learn digits replication for seed $seed"
    python -m neuro_weave.assemblies_v21_run --dataset digits --seed $seed --source-classes 6 --novel-classes 4 --increment 2 --initial-shots 4 --new-shots 4 --max-val 12 --image-size 16 --neurons 32 --epochs 30 --steps 20 --branch-fanin 8 --temperature 12 --branch-gain 0.35 --reuse 3 --accept-threshold 0.01 --output "results/digits_seed$seed"
    if ($LASTEXITCODE -ne 0) { throw "Seed $seed failed with exit code $LASTEXITCODE" }
}
Write-Host 'Completed all five seeds.'
