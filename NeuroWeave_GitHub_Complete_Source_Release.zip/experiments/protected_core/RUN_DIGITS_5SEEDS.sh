#!/usr/bin/env bash
set -euo pipefail
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
for seed in 11 12 13 14 15; do
  python -m neuro_weave.assemblies_v21_run --dataset digits --seed "$seed" --source-classes 6 --novel-classes 4 --increment 2 --initial-shots 4 --new-shots 4 --max-val 12 --image-size 16 --neurons 32 --epochs 30 --steps 20 --branch-fanin 8 --temperature 12 --branch-gain .35 --reuse 3 --accept-threshold .01 --output "results/digits_seed${seed}" --cpu
done
