"""Offline integration check of the actual CIFAR-10 pickle/tar layout.

Uses synthetic pixels & labels with OFFICIAL batch dimensions; not a CIFAR experiment.
Tests archive parser, class splits, support/test counts and checksum checking.
"""
from pathlib import Path
import tempfile,io,tarfile,pickle,hashlib
import numpy as np
from neuro_weave import data


def main():
    with tempfile.TemporaryDirectory() as temp:
        target=Path(temp)/'fixture.tar.gz'
        x=np.zeros((10000,3072),dtype=np.uint8)
        labels=np.arange(10000,dtype=np.int32)%10
        with tarfile.open(target,'w:gz') as archive:
            for name in [*(f'data_batch_{i}' for i in range(1,6)),'test_batch']:
                # Mark the synthetic test partition differently so our check catches split mixing.
                synthetic=x.copy()
                if name=='test_batch':synthetic[:,0]=100
                bs=pickle.dumps({b'data':synthetic,b'labels':labels.tolist()},protocol=4)
                info=tarfile.TarInfo(f'cifar-10-batches-py/{name}');info.size=len(bs)
                archive.addfile(info,io.BytesIO(bs))
        # Patch only within this test process; production checksum remains official MD5.
        digest=hashlib.md5(target.read_bytes()).hexdigest()
        prior_download=data.download;prior_md5=data.CIFAR10_MD5
        try:
            data.download=lambda url,dest:target
            data.CIFAR10_MD5=digest
            records=data._make_cifar10(Path(temp),11)
            assert len(records)==10
            assert all((len(r['train']),len(r['val']),len(r['query']))==(64,28,48) for r in records.values())
            a=np.asarray(records[4]['train'][0])
            b=np.asarray(records[4]['query'][0])
            assert int(a[0,0,0])==0 and int(b[0,0,0])==100
            bundle=data.build_data('cifar10',Path(temp),seed=11,size=16,source_classes=6,novel_classes=4,max_train=4,max_val=12)
            assert bundle.source_train_x.shape==(24,768)
            assert bundle.source_test_x.shape==(288,768)
            assert len(bundle.novel)==4
            print('PASS synthetic official-layout CIFAR archive: checksum, train/test separation, class counts and 4-shot preprocessing')
        finally:
            data.download=prior_download;data.CIFAR10_MD5=prior_md5
if __name__=='__main__':main()
