"""Sparse, append-only graph of multicompartment artificial neurons.

Initial neurons connect directly to sensory features; later units can reuse the
outputs of any earlier units. The graph has an emergent topological depth, but
no prescribed hidden-layer stack. Acyclicity is a pragmatic modelling choice.
"""
from __future__ import annotations
import math
import random
from typing import Optional
import torch
from torch import nn
import torch.nn.functional as F


class CompartmentNeuron(nn.Module):
    def __init__(self, source_ids: list[list[int]], kind: str = 'dendritic'):
        super().__init__()
        if kind not in ('dendritic', 'point'):
            raise ValueError(kind)
        if len({len(v) for v in source_ids}) != 1:
            raise ValueError('Branches must have the same fan-in')
        self.kind = kind
        self.register_buffer('source_ids', torch.tensor(source_ids, dtype=torch.long))
        self.register_buffer('synapse_mask', torch.ones(len(source_ids), len(source_ids[0])))
        self.register_buffer('branch_mask', torch.ones(len(source_ids)))
        k, f = len(source_ids), len(source_ids[0])
        self.weights = nn.Parameter(torch.randn(k, f) / math.sqrt(max(1,f)))
        self.soma_weights = nn.Parameter(torch.randn(k) / math.sqrt(max(1,k))) if kind=='dendritic' else None
        self.branch_bias = nn.Parameter(torch.zeros(k)) if kind=='dendritic' else None
        self.coincidence = nn.Parameter(torch.tensor(0.1)) if kind=='dendritic' else None
        self.bias = nn.Parameter(torch.zeros(()))
        self.alive = True

    def forward(self, sources: torch.Tensor) -> torch.Tensor:
        v = sources[:, self.source_ids]  # [batch, branches, fanin]
        pre = (v * self.weights * self.synapse_mask).sum(-1)
        if self.kind == 'dendritic':
            branch = torch.tanh(pre + self.branch_bias) * self.branch_mask
            nonlinear = self.coincidence * branch[:,0] * branch[:,1] if branch.shape[1] > 1 else 0.
            y = torch.tanh((branch * self.soma_weights).sum(-1) + nonlinear + self.bias)
        else:
            # Same sampled sensory/graph inputs, but with one point-wise nonlinearity.
            y = torch.tanh((pre * self.branch_mask).sum(-1) + self.bias)
        return y

    @torch.no_grad()
    def add_branch(self, proposed_sources: list[int]) -> None:
        """Append a dendritic compartment; preserve device/dtype and old parameters."""
        if self.kind != 'dendritic':
            raise ValueError('Only dendritic neurons can grow compartments')
        if len(proposed_sources) != self.weights.shape[1]:
            raise ValueError('New compartment has incorrect fan-in')
        device, dtype = self.weights.device, self.weights.dtype
        k, fanin = self.weights.shape
        new_w = torch.randn(1, fanin, device=device, dtype=dtype) / math.sqrt(fanin)
        self.weights = nn.Parameter(torch.cat([self.weights.detach().clone(), new_w], dim=0))
        self.branch_bias = nn.Parameter(torch.cat([self.branch_bias.detach().clone(), torch.zeros(1,device=device,dtype=dtype)]))
        self.soma_weights = nn.Parameter(torch.cat([self.soma_weights.detach().clone(), torch.tensor([1/math.sqrt(k+1)],device=device,dtype=dtype)]))
        self.source_ids = torch.cat([self.source_ids,torch.tensor([proposed_sources],device=device,dtype=torch.long)],dim=0)
        self.synapse_mask = torch.cat([self.synapse_mask,torch.ones(1,fanin,device=device,dtype=dtype)],dim=0)
        self.branch_mask = torch.cat([self.branch_mask,torch.ones(1,device=device,dtype=dtype)],dim=0)

    @torch.no_grad()
    def prune_weak_synapses(self, fraction: float = 0.10) -> int:
        assert 0 <= fraction < 1
        available = self.synapse_mask > 0
        vals = self.weights.abs()[available]
        n = int(len(vals) * fraction)
        if n == 0: return 0
        threshold = torch.topk(vals, n, largest=False).values.max()
        indices = (self.weights.abs() <= threshold) & available
        self.synapse_mask[indices] = 0
        return int(indices.sum().item())


class DendriticGraph(nn.Module):
    def __init__(self, input_dim:int, initial_neurons:int=32, branches:int=4,
                 fanin:int=16, kind:str='dendritic', seed:int=11,
                 initial_wiring_probability:float=.45,
                 initial_synapse_fraction:float=1.0, spatial_sensory:bool=False):
        super().__init__()
        self.input_dim=input_dim
        self.branches=branches
        self.fanin=fanin
        self.kind=kind
        self.initial_synapse_fraction=initial_synapse_fraction
        self.spatial_sensory=spatial_sensory
        self.random = random.Random(seed)
        self.units=nn.ModuleList()
        self.depths:list[int]=[]
        self._initializing=True
        for i in range(initial_neurons):
            # Founding neurons can already connect to previously constructed neurons.
            # New connections remain acyclic; depth is not specified in advance.
            allow=(i>=4 and self.random.random()<initial_wiring_probability)
            self.add_neuron(allow_existing=allow)
        self._initializing=False

    def _sample_sensory(self, number:int) -> list[int]:
        """Optional spatially local pixel wiring; retains channel-wise RGB indexing."""
        side = math.isqrt(self.input_dim//3)
        if not self.spatial_sensory or side*side*3 != self.input_dim:
            return [self.random.randrange(self.input_dim) for _ in range(number)]
        radius=max(1, side//8)
        cy=self.random.randrange(side); cx=self.random.randrange(side)
        out=[]
        for _ in range(number):
            yy=min(side-1,max(0,cy+self.random.randint(-radius,radius)))
            xx=min(side-1,max(0,cx+self.random.randint(-radius,radius)))
            channel=self.random.randrange(3)
            out.append(channel*side*side+yy*side+xx)
        return out

    def _propose(self, allow_existing:bool) -> list[list[int]]:
        n=len(self.units)
        ids=[]
        # Early sensory connections remain available even for deep composite neurons.
        for b in range(self.branches):
            n_prior = min(self.fanin//3, 3) if n and allow_existing else 0
            # Every branch contains both sensory inputs and existing circuit responses.
            prior = [self.input_dim+self.random.randrange(n) for _ in range(n_prior)]
            sensed = self._sample_sensory(self.fanin-n_prior)
            self.random.shuffle(prior)
            self.random.shuffle(sensed)
            ids.append(prior+sensed)
        return ids

    def add_neuron(self, allow_existing:bool=True, source_ids: Optional[list[list[int]]]=None) -> int:
        source_ids=source_ids if source_ids is not None else self._propose(allow_existing)
        for branch in source_ids:
            for i in branch:
                if i < 0 or i >= self.input_dim + len(self.units):
                    raise ValueError('Illegal non-causal edge / invalid source')
        depths=[0 if src < self.input_dim else self.depths[src-self.input_dim] for br in source_ids for src in br]
        depth=1+max(depths,default=0)
        # A neuron appended after model.to('cuda') is initially created on CPU.
        # ModuleList does not automatically move newly appended children.
        # Inherit the existing graph's device and floating-point dtype so both
        # selected and unconditional/random structural growth work on CUDA.
        new_unit = CompartmentNeuron(source_ids, self.kind)
        if len(self.units) > 0:
            reference_weight = self.units[0].weights
            new_unit = new_unit.to(device=reference_weight.device,
                                   dtype=reference_weight.dtype)
        if self.initial_synapse_fraction < 1.0 and getattr(self, '_initializing', False):
            # Initial immature circuit: many synaptic slots are latent rather than active.
            # Keep at least one active connection per branch so each branch can respond.
            with torch.no_grad():
                for b in range(self.branches):
                    indices=list(range(self.fanin)); self.random.shuffle(indices)
                    active=max(1,round(self.fanin*self.initial_synapse_fraction))
                    for j in indices[active:]:new_unit.synapse_mask[b,j]=0
        self.units.append(new_unit)
        self.depths.append(depth)
        return len(self.units)-1

    def freeze_old(self, keep_last_trainable:bool=False) -> None:
        for i,u in enumerate(self.units):
            for p in u.parameters(): p.requires_grad_(keep_last_trainable and i==len(self.units)-1)

    def unfreeze(self):
        for u in self.units:
            for p in u.parameters(): p.requires_grad_(True)

    def forward(self,x:torch.Tensor, silence:Optional[int]=None) -> torch.Tensor:
        if x.ndim !=2 or x.size(1)!=self.input_dim: raise ValueError('Input dimension mismatch')
        sources=x
        activations=[]
        for i,u in enumerate(self.units):
            if not u.alive or i==silence:
                y=x.new_zeros(x.size(0))
            else:
                y=u(sources)
            activations.append(y)
            sources=torch.cat((sources, y[:,None]),dim=1)
        return torch.stack(activations,dim=-1)

    def topology(self):
        nodes=[]; edges=[]
        for i,u in enumerate(self.units):
            unit=f'N{i:03d}'
            nodes.append({'id':unit, 'depth':self.depths[i], 'type':u.kind,
                          'alive':u.alive, 'branches':len(u.source_ids),
                          'synapses':int(u.synapse_mask.sum().item())})
            for branch in range(len(u.source_ids)):
                for j,src in enumerate(u.source_ids[branch].tolist()):
                    if int(u.synapse_mask[branch,j].item())==0: continue
                    from_node=f'PIX{src:03d}' if src < self.input_dim else f'N{src-self.input_dim:03d}'
                    edges.append({'source':from_node,'target':unit,'branch':branch})
        return {'input_dim':self.input_dim,'nodes':nodes,'edges':edges,
                'mean_depth':sum(self.depths)/len(self.depths), 'max_depth':max(self.depths),
                'alive_synapses':len(edges)}


class GraphClassifier(nn.Module):
    def __init__(self, graph:DendriticGraph, nclasses:int):
        super().__init__()
        self.graph=graph
        self.head=nn.Linear(len(graph.units),nclasses)

    def expand(self) -> None:
        old=self.head
        new=nn.Linear(old.in_features+1,old.out_features).to(device=old.weight.device,dtype=old.weight.dtype)
        with torch.no_grad():
            new.weight[:,:-1].copy_(old.weight)
            new.weight[:,-1].zero_()
            new.bias.copy_(old.bias)
        self.head=new

    def forward(self,x,silence=None):
        return self.head(self.graph(x,silence=silence))

    def representations(self,x): return self.graph(x)


class MLPClassifier(nn.Module):
    def __init__(self, input_dim:int, nclasses:int, hidden:int=128):
        super().__init__()
        self.hidden=nn.Sequential(nn.Linear(input_dim,hidden),nn.ReLU())
        self.head=nn.Linear(hidden,nclasses)

    def representations(self,x):return self.hidden(x)
    def forward(self,x): return self.head(self.representations(x))


def parameter_count(model:nn.Module)->int:
    return sum(p.numel() for p in model.parameters())


def matched_mlp_width(input_dim,nclasses,target_parameters):
    # For one hidden layer: (d+1)*h + (h+1)*nclasses
    return max(1,round((target_parameters-nclasses)/(input_dim+nclasses+1)))
