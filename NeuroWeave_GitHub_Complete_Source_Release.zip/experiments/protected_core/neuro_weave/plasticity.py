"""v1.6.4: experience-dependent developmental operations and controlled trials.

Actions are genuine graph edits: synaptic recruitment from a silent slot, replacement
of one existing contact, new branch on an existing soma, or entirely new neuron.
A strictly acyclic graph is retained for numerical and experimental tractability.
This is NOT a simulated biological brain or neuron-local plasticity rule.
"""
from __future__ import annotations
import copy
import random
import time
import torch
from .learning import fit, evaluate
from .model import GraphClassifier, parameter_count

ACTIONS=('synapse', 'rewire', 'branch', 'neuron')


def refresh_depths(graph):
    """Depth depends only on active synapses, not their original proposal slots."""
    depths=[]
    for unit in graph.units:
        srcs=unit.source_ids[unit.synapse_mask.bool()].tolist()
        depths.append(1+max([depths[int(k)-graph.input_dim] for k in srcs if k>=graph.input_dim], default=0))
    graph.depths=depths


def choose_source(graph,target:int,rng:random.Random, prefer_neuron:bool=True):
    if target>0 and prefer_neuron and rng.random()<0.85:
        return graph.input_dim+rng.randrange(target)
    return graph._sample_sensory(1)[0]


def propose_action(model:GraphClassifier, action:str, rng:random.Random):
    """Mutate a *trial clone*, returning a diagnostic for the proposed action.

    Does not alter an original reference model. The caller must create the clone.
    """
    graph=model.graph
    if action not in ACTIONS:raise ValueError(action)
    if action=='neuron':
        n=graph.add_neuron(allow_existing=True)
        model.expand()
        # New neurons are connected to previous neurons and spatial sensory inputs.
        # Head starts at zero weight so growth cannot change predictions until trained.
        refresh_depths(graph)
        return {'action':action, 'target':n, 'branch':-1, 'slot':-1,
                'old_source':-1, 'new_source':-1, 'depth':graph.depths[n]}
    if action=='branch':
        if graph.kind!='dendritic':raise ValueError('Dendritic branch requested for point unit')
        target=rng.randrange(len(graph.units))
        srcs=[]
        for j in range(graph.fanin):
            srcs.append(choose_source(graph,target,rng,prefer_neuron=(j < graph.fanin//2)))
        graph.units[target].add_branch(srcs)
        refresh_depths(graph)
        return {'action':action,'target':target,'branch':len(graph.units[target].source_ids)-1,
                'slot':-1,'old_source':-1,'new_source':-1,'depth':graph.depths[target]}
    options=[]
    for i,unit in enumerate(graph.units):
        if action=='synapse':
            slots=torch.nonzero(unit.synapse_mask==0,as_tuple=False).tolist()
        else:
            slots=torch.nonzero(unit.synapse_mask>0,as_tuple=False).tolist()
        if slots:options.append((i,slots))
    if not options:
        return None
    target,slots=rng.choice(options)
    b,slot=rng.choice(slots)
    unit=graph.units[target]
    old=int(unit.source_ids[b,slot].item())
    new=choose_source(graph,target,rng)
    if action=='rewire' and new==old:
        new=choose_source(graph,target,rng,prefer_neuron=False)
        if new==old:new=(old+1)%graph.input_dim
    with torch.no_grad():
        unit.source_ids[b,slot]=new
        unit.synapse_mask[b,slot]=1
        if action=='synapse':
            # Activate a new synaptic contact, starting near zero strength.
            unit.weights[b,slot] = 0.02 if rng.random()<.5 else -0.02
    refresh_depths(graph)
    return {'action':action,'target':target,'branch':b,'slot':slot,
            'old_source':old,'new_source':new,'depth':graph.depths[target]}


def set_trainability(model, target:int|None):
    model.graph.freeze_old()
    if target is not None:
        for p in model.graph.units[target].parameters():p.requires_grad_(True)
    for p in model.head.parameters():p.requires_grad_(True)


def _trial_pair(base,x,y,vx,vy,action,rng,epochs,lr,step,penalty,min_gain,prune):
    """Compare a structural change with the *same unit* trained without change."""
    ref=copy.deepcopy(base)
    trial=copy.deepcopy(base)
    details=propose_action(trial,action,rng)
    if details is None:
        return ref, {'action':action,'accepted':0,'skipped':'no eligible masked slot'}, 0.
    target=details['target'] if action!='neuron' else None
    set_trainability(ref,target)
    set_trainability(trial,details['target'])
    # Fixed data order across arms, despite different parameter initialisations.
    train_seed=73_001+step
    torch.manual_seed(train_seed)
    secs=fit(ref,x,y,epochs,lr)
    torch.manual_seed(train_seed)
    secs+=fit(trial,x,y,epochs,lr)
    perf_ref=evaluate(ref,vx,vy)
    perf_trial=evaluate(trial,vx,vy)
    cost=parameter_count(trial)-parameter_count(base)
    score=perf_ref['loss']-perf_trial['loss']-penalty*cost
    accepted=score > min_gain
    pruned=0
    if accepted and action in ('branch','neuron') and prune>0:
        unit=trial.graph.units[details['target']]
        # Prune only the newly formed compartment(s); never silently erase
        # pre-existing contacts as a consequence of unrelated growth.
        with torch.no_grad():
            b=details['branch']
            rows=[b] if action=='branch' else list(range(len(unit.source_ids)))
            for row in rows:
                indices=torch.nonzero(unit.synapse_mask[row]>0,as_tuple=False).flatten()
                n=min(len(indices)-1,int(len(indices)*prune))
                if n>0:
                    low=indices[unit.weights[row,indices].abs().argsort()[:n]]
                    unit.synapse_mask[row,low]=0
                    pruned+=n
        after=evaluate(trial,vx,vy)
        if after['loss']>=perf_ref['loss']-min_gain:
            accepted=False;pruned=0
    selected=trial if accepted else ref
    # Stochastic exploration consumes random state even on rejection.
    selected.graph.random.setstate(trial.graph.random.getstate())
    refresh_depths(selected.graph)
    selected.graph.unfreeze()
    effective=evaluate(selected,vx,vy)
    topology=selected.graph.topology()
    event={'graph_units_after':len(selected.graph.units),
           'graph_depth_after':topology['max_depth'],
           'active_synapses_after':topology['alive_synapses'],
           'selected_val_loss_after':effective['loss'],
           'selected_val_accuracy_after':effective['accuracy'],
           'step':step,'accepted':int(accepted),**details,
           'reference_val_loss':perf_ref['loss'],'candidate_val_loss':perf_trial['loss'],
           'gain_minus_penalty':score,'added_parameters':cost,
           'pruned_synapses':pruned,'candidate_sources':repr(trial.graph.units[details['target']].source_ids.tolist())}
    return selected,event,secs


def development_selected(base,x,y,vx,vy,steps=12,trial_epochs=3,lr=.012,
                         min_gain=.001,penalty=0.,seed=11,prune=.1,action_schedule=None):
    """Source-validation-selected development, no use of test or novel labels."""
    rng=random.Random(seed+7007)
    model=copy.deepcopy(base)
    events=[];seconds=0.
    for i in range(steps):
        action=action_schedule[i] if action_schedule is not None else ACTIONS[i%len(ACTIONS)]
        model,event,spent=_trial_pair(model,x,y,vx,vy,action,rng,trial_epochs,lr,i,penalty,min_gain,prune)
        seconds+=spent
        events.append(event)
    return model,events,seconds


def development_random(base,x,y,steps=12,trial_epochs=3,lr=.012,
                       seed=11,prune=.1, action_schedule=None):
    """Unconditional stochastic development; no validation-dependent selection."""
    rng=random.Random(seed+8008)
    model=copy.deepcopy(base)
    events=[];seconds=0.
    for i in range(steps):
        action=action_schedule[i] if action_schedule is not None else ACTIONS[i%len(ACTIONS)]
        details=propose_action(model,action,rng)
        if details is None:
            events.append({'step':i,'action':action,'accepted':0,'skipped':'no eligible slot'})
            continue
        set_trainability(model,details['target'])
        torch.manual_seed(73_001+i)
        seconds+=fit(model,x,y,trial_epochs,lr)
        unit=model.graph.units[details['target']]
        npruned=0
        if action in ('branch','neuron'):
            # Use same branch-local pruning policy as selected trials.
            # No validation information may enter this path.
            target_rows=([details['branch']] if action=='branch'
                         else list(range(len(unit.source_ids))))
            with torch.no_grad():
                for b in target_rows:
                    indices=torch.nonzero(unit.synapse_mask[b]>0,as_tuple=False).flatten()
                    n=min(len(indices)-1,int(len(indices)*prune))
                    if n>0:
                        low=indices[unit.weights[b,indices].abs().argsort()[:n]]
                        unit.synapse_mask[b,low]=0;npruned+=n
        refresh_depths(model.graph)
        events.append({'step':i,'accepted':1,**details,'pruned_synapses':npruned,
                       'candidate_sources':repr(unit.source_ids.tolist())})
    model.graph.unfreeze()
    return model,events,seconds


def branch_dependency(model,x,y,unit_ids=None,max_units=8):
    """Post-training branch ablations on untouched source TEST (diagnostic only)."""
    baseline=evaluate(model,x,y)
    if unit_ids is None: unit_ids=list(range(len(model.graph.units)))
    rows=[]
    for i in unit_ids[:max_units]:
        unit=model.graph.units[i]
        for b in range(len(unit.source_ids)):
            prior=float(unit.branch_mask[b].item())
            with torch.no_grad():unit.branch_mask[b]=0
            alt=evaluate(model,x,y)
            with torch.no_grad():unit.branch_mask[b]=prior
            rows.append({'neuron':i,'branch':b,'depth':model.graph.depths[i],
                         'delta_test_loss':alt['loss']-baseline['loss'],
                         'delta_test_accuracy':baseline['accuracy']-alt['accuracy'],
                         'number_active_synapses':int(unit.synapse_mask[b].sum().item())})
    return rows
