"""NeuroWeave 2.0-alpha real-data / synthetic mechanism pilot.

It is a *research prototype*. No claims of learning superiority are implied.
"""
from __future__ import annotations
import argparse,csv,json,random
from pathlib import Path
import torch
from .data import build_data
from .continual import build_stream,collect,train_stage
from .model import DendriticGraph,GraphClassifier,parameter_count
from .engram_v20 import StableDendriticAssemblies,accuracy_breakdown

def run(args):
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    device=torch.device('cuda:0' if torch.cuda.is_available() and not args.cpu else 'cpu')
    b=build_data(args.dataset,Path(args.data_root),seed=args.seed,size=args.image_size,
                 source_classes=args.source_classes,novel_classes=args.novel_classes,
                 max_train=args.initial_shots,max_val=args.max_val)
    stream=build_stream(b,increment=args.increment,shots=args.new_shots)
    Path(args.output).mkdir(parents=True,exist_ok=True)
    output=[];events=[]
    for kind in ('dendritic','point'):
        torch.manual_seed(args.seed)
        g=DendriticGraph(stream.input_dim,initial_neurons=args.neurons,branches=4,
                        fanin=16,kind=kind,seed=args.seed,
                        initial_wiring_probability=.20,
                        initial_synapse_fraction=.60,
                        spatial_sensory=True)
        base=GraphClassifier(g,args.source_classes).to(device)
        sx,sy=collect(stream.train,stream.stage_groups[0],device)
        t=train_stage(base,sx,sy,args.epochs,args.lr,64,args.seed)
        print(kind,'base trained',round(t,2),'s', 'parameters',parameter_count(base),flush=True)
        for beta in (0.,args.branch_bonus):
            # Identical shared frozen representation; only fast-branch readout differs.
            memory=StableDendriticAssemblies(base.graph,total_capacity=args.source_classes+args.novel_classes,
                                            fanin=args.branch_fanin,beta=beta,seed=args.seed+177).to(device)
            seen=[]
            for s,classes in enumerate(stream.stage_groups):
                xx,yy=collect(stream.train,classes,device)
                prior_count=len(memory.prototypes)
                if prior_count:
                    old_x,_=collect(stream.test,seen,device)
                    with torch.no_grad():old_logit_snapshot=memory(old_x).detach().clone()
                memory.enroll(xx,yy,form_branches=(beta>0))
                if prior_count:
                    with torch.no_grad():
                        prior_logit_drift=float((memory(old_x)[:,:prior_count]-old_logit_snapshot).abs().max().item())
                else:prior_logit_drift=0.0
                seen+=classes
                results=accuracy_breakdown(memory,stream.test,seen,classes,device)
                ablated=accuracy_breakdown_ablated(memory,stream.test,seen,classes,device)
                row={'method':f'{kind}_assembly_beta_{beta:g}', 'stage':s,
                     'seen_classes':len(seen),'n_new':len(classes),
                     'base_parameters':parameter_count(base),
                     'num_fast_branches':len(memory.fast_branches),
                     'max_old_score_drift':prior_logit_drift,
                     'memory_bytes':memory.memory_bytes(),
                     'test_all':results['all'],'test_old':results['old'],
                     'test_new':results['new'], 'ablated_test_all':ablated['all'],
                     'ablated_test_new':ablated['new']}
                output.append(row)
                print(row['method'],'stage',s,'all',round(results['all'],3),'old',results['old'],
                      'new',round(results['new'],3),'branches',row['num_fast_branches'],flush=True)
                events.append({'method':row['method'],'stage':s,'new_class_ids':classes,
                               'active_fast_branches':len(memory.fast_branches),
                               'branches':[{'target_neuron':int(m.target_neuron),
                                            'source_neuron_ids':m.input_indices.tolist()}
                                            for m in memory.fast_branches],
                               'protected_core':True,'stored_old_images':0})
    path=Path(args.output)
    with (path/'summary.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(output[0]));writer.writeheader();writer.writerows(output)
    (path/'events.json').write_text(json.dumps(events,indent=2))
    (path/'configuration.json').write_text(json.dumps(vars(args),indent=2))
    print('Saved to',path)

def accuracy_breakdown_ablated(model,bank,seen,last,device):
    x=torch.cat([bank[c] for c in seen]).to(device)
    y=torch.cat([torch.full((len(bank[c]),),c,dtype=torch.long,device=device) for c in seen])
    with torch.no_grad():pred=model(x,ablate_fast=True).argmax(-1)
    def score(labels):
        m=torch.zeros_like(y,dtype=torch.bool)
        for c in labels:m|=y==c
        return float((pred[m]==y[m]).float().mean()) if m.any() else None
    return {'all':score(seen),'new':score(last)}

def parse():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',choices=['synthetic','coil100','pets'],default='synthetic')
    p.add_argument('--data-root',default='data')
    p.add_argument('--output',default='results/v20_mechanism')
    p.add_argument('--seed',type=int,default=11)
    p.add_argument('--source-classes',type=int,default=6)
    p.add_argument('--novel-classes',type=int,default=6)
    p.add_argument('--increment',type=int,default=2)
    p.add_argument('--initial-shots',type=int,default=8)
    p.add_argument('--new-shots',type=int,default=4)
    p.add_argument('--max-val',type=int,default=12)
    p.add_argument('--image-size',type=int,default=16)
    p.add_argument('--neurons',type=int,default=32)
    p.add_argument('--epochs',type=int,default=25)
    p.add_argument('--lr',type=float,default=.015)
    p.add_argument('--branch-fanin',type=int,default=8)
    p.add_argument('--branch-bonus',type=float,default=.15)
    p.add_argument('--cpu',action='store_true')
    return p.parse_args()
if __name__=='__main__':run(parse())
