"""NeuroWeave 2.1: genuinely soma-integrated, class-conditioned dendritic engrams.

Every class competes during prediction; class labels are NOT supplied at inference.
The original graph and already enrolled class paths are immutable. New sparse
branches are learned exclusively from support examples of the current class.
Each new branch alters the target neuron's pre-soma drive; downstream neurons
observe the changed response. Stored prototypes are compact feature memories.

LIMITATION: class-conditioned full graph passes can be slower than one global
forward pass; protection of old scores is by architectural isolation, not by
biological consolidation or general zero-memory continual learning.
"""
from __future__ import annotations
import math
import random
from dataclasses import dataclass
from typing import Optional
import torch
from torch import nn
import torch.nn.functional as F


class SomaCompartment(nn.Module):
    """Local gated (dendritic) or linear (point-control) branch before soma."""
    def __init__(self, target: int, sources: list[int], kind: str, gain: float = 0.35):
        super().__init__()
        if kind not in ('dendritic', 'linear') or len(sources)<2:raise ValueError('bad branch')
        self.target = int(target)
        self.kind = kind
        self.register_buffer('sources', torch.tensor(sources, dtype=torch.long))
        k=len(sources)
        self.w_exc=nn.Parameter(torch.randn(k)/math.sqrt(k))
        self.w_gate=nn.Parameter(torch.randn(k)/math.sqrt(k))
        self.bias_exc=nn.Parameter(torch.zeros(()))
        self.bias_gate=nn.Parameter(torch.zeros(()))
        self.gain=nn.Parameter(torch.tensor(float(gain)))

    def forward(self, all_inputs:torch.Tensor):
        v=all_inputs.index_select(1,self.sources)
        e=v@self.w_exc+self.bias_exc
        g=v@self.w_gate+self.bias_gate
        if self.kind=='dendritic':
            # A two-subcompartment product followed by a target-soma nonlinearity.
            drive=torch.tanh(e)*torch.sigmoid(g)
        else:
            # Equal learned parameter budget, but no branch-local product.
            drive=(e+g)/2
        return self.gain.tanh()*drive


def forward_with_soma_branches(graph:nn.Module,x:torch.Tensor,branches:list[SomaCompartment]):
    """Return original soma outputs, with selected branches injected pre-activation.

    Uses exactly the original graph's base-neuron operations, including its
    coincidence term, and preserves the DAG source ordering. For an empty set,
    call the original implementation exactly to avoid numerical drift.
    """
    if not branches:return graph(x)
    if x.ndim!=2 or x.size(1)!=graph.input_dim:raise ValueError('input shape')
    per_target={}
    for b in branches:
        if b.target<0 or b.target>=len(graph.units):raise ValueError('target outside graph')
        if bool(torch.any(b.sources >= graph.input_dim+b.target)) or bool(torch.any(b.sources<0)):
            raise ValueError('branch contains a forward/cyclic source')
        per_target.setdefault(b.target,[]).append(b)
    sources=x
    outputs=[]
    for i,u in enumerate(graph.units):
        additions=per_target.get(i,[])
        if not additions:
            out=u(sources)
        else:
            v=sources[:,u.source_ids]
            pre=(v*u.weights*u.synapse_mask).sum(-1)
            if u.kind=='dendritic':
                p=torch.tanh(pre+u.branch_bias)*u.branch_mask
                val=(p*u.soma_weights).sum(-1)+u.bias
                if p.shape[1]>1:val=val+u.coincidence*p[:,0]*p[:,1]
            else:
                val=(pre*u.branch_mask).sum(-1)+u.bias
            val=val+torch.stack([b(sources) for b in additions],dim=0).sum(0)
            out=torch.tanh(val)
        outputs.append(out)
        sources=torch.cat([sources,out[:,None]],dim=1)
    return torch.stack(outputs,dim=1)


@dataclass
class EnrollmentReport:
    class_id:int
    accepted:bool
    reused:int
    new_branch_id:int
    target:int
    support_ce_before:float
    support_ce_after:float
    soma_delta:float
    candidate_kind:str


class NeuroWeaveAssemblies(nn.Module):
    """Frozen core, trainable soma-integrated new branches, per-class fixed paths.

    Stores only class prototypes and branch parameters (no previous class images).
    Old class *scores* never change upon enrolling a new class. Overall old
    recognition accuracy may still decrease owing to novel-class competition.
    """
    def __init__(self,graph:nn.Module,seed:int=11,branch_kind='dendritic',
                 temperature:float=12.,initial_gain:float=.35):
        super().__init__()
        if branch_kind not in ('dendritic','linear'):raise ValueError(branch_kind)
        self.graph=graph
        for p in self.graph.parameters():p.requires_grad_(False)
        self.graph.eval()
        self.branches=nn.ModuleList()
        self.paths:list[list[int]]=[]
        self.register_buffer('prototypes',torch.empty(0,len(graph.units)))
        self.rng=random.Random(seed)
        self.param_rng=torch.Generator(device='cpu').manual_seed(int(seed)+9319)
        self.branch_kind=branch_kind
        self.temperature=float(temperature)
        self.initial_gain=float(initial_gain)

    def train(self,mode=True):
        super().train(mode)
        self.graph.eval()
        return self

    def _rep(self,x,path:list[int]):
        chosen=[self.branches[j] for j in path]
        return F.normalize(forward_with_soma_branches(self.graph,x,chosen),dim=-1,eps=1e-7)

    def _score_one(self,x,cls:int,path:Optional[list[int]]=None,prototype:Optional[torch.Tensor]=None):
        if path is None:path=self.paths[cls]
        if prototype is None:prototype=self.prototypes[cls]
        return (self._rep(x,path)*prototype).sum(-1)*self.temperature

    def forward(self,x,ablate_branches=False,ablate_class:Optional[int]=None):
        if len(self.paths)==0:raise RuntimeError('Enroll initial classes first')
        # Group identical paths to avoid unnecessary re-running the graph.
        grouping:dict[tuple,list[int]]={}
        for c,path in enumerate(self.paths):
            effective=[] if ablate_branches or (ablate_class is not None and c==ablate_class) else path
            grouping.setdefault(tuple(effective),[]).append(c)
        out=x.new_empty(x.shape[0],len(self.paths))
        for path,classes in grouping.items():
            reps=self._rep(x,list(path))
            out[:,classes]=self.temperature*(reps @ self.prototypes[classes].T)
        return out

    @torch.no_grad()
    def enroll_initial(self,x,y):
        if len(self.paths):raise RuntimeError('initial classes already enrolled')
        labels=sorted(set(y.detach().cpu().tolist()))
        if labels!=list(range(len(labels))):raise ValueError('initial labels must start from zero and be contiguous')
        if x.device!=self.prototypes.device:raise ValueError('different devices')
        base=self._rep(x,[])
        proto=[]
        for c in labels:
            q=base[y==c]
            if len(q)==0:raise ValueError('empty initial class')
            proto.append(F.normalize(q.mean(0),dim=0))
        self.prototypes=torch.stack(proto,dim=0)
        self.paths=[[] for _ in labels]

    def _fresh_branch(self,fanin:int,proposal:str,support:Optional[torch.Tensor]=None):
        n=len(self.graph.units)
        earliest=min(6,n-1)
        if proposal=='stochastic':
            t=self.rng.randint(earliest,n-1)
        elif proposal=='novelty':
            # Candidate target uses only current labelled supports and stored
            # historical class prototypes. No previous images or query labels.
            if support is None:raise ValueError('novelty target requires support')
            with torch.no_grad():
                current=self._rep(support,[]).mean(0)
                historical=self.prototypes.mean(0)
                t=int((current-historical).abs()[earliest:].argmax())+earliest
        elif proposal=='early':
            t=earliest
        else:raise ValueError(proposal)
        k=min(fanin,self.graph.input_dim+t)
        nprev=min(k//2,t)
        prior=self.rng.sample(range(t),nprev) if nprev else []
        pix=[self.rng.randrange(self.graph.input_dim) for _ in range(k-nprev)]
        sources=[self.graph.input_dim+i for i in prior]+pix
        self.rng.shuffle(sources)
        branch=SomaCompartment(t,sources,self.branch_kind,self.initial_gain)
        # Model-owned RNG makes resumed training bitwise reproducible even when
        # unrelated code consumes global torch random numbers.
        with torch.no_grad():
            for weight in (branch.w_exc,branch.w_gate):
                weight.copy_(torch.randn(weight.shape,generator=self.param_rng)/math.sqrt(k))
        return branch.to(device=self.prototypes.device,dtype=self.prototypes.dtype)

    def _candidate_objective(self,train_x,val_x,base_path,cand,prior_prototypes=None):
        # Use ONLY the current class's labelled examples and previous *stored* prototypes.
        # Old-score paths are frozen. Two held-out supports provide the selection criterion.
        z_train=self._rep(train_x,base_path)
        mu=F.normalize(z_train.mean(0),dim=0)
        z_val=self._rep(val_x,base_path)
        own=(z_val@mu)*self.temperature
        # Competitors are evaluated on present support, never historical images.
        with torch.no_grad():
            if len(self.paths):
                competition=self.forward(val_x).detach()
            else:competition=own.new_zeros(len(own),0)
        logits=torch.cat((competition,own[:,None]),dim=1)
        target=torch.full((len(val_x),),logits.shape[1]-1,dtype=torch.long,device=val_x.device)
        return F.cross_entropy(logits,target)

    def enroll_one(self,x, y:int,fanin=8,steps=20,lr=.05,
                   proposal='stochastic',reuse_candidates=3,improve_threshold=.01,
                   allow_new=True) -> EnrollmentReport:
        """Enroll exactly one new class; no old samples or test data consulted.

        2/2 support split for fitting/acceptance in standard 4-shot experiments.
        We do not use the evaluation/query data to choose mechanisms.
        """
        if y!=len(self.paths):raise ValueError('classes must arrive sequentially')
        if x.ndim!=2 or len(x)<3:raise ValueError('require >=3 class support images')
        if x.device!=self.prototypes.device:raise ValueError('device mismatch')
        ntrain=max(2,len(x)//2)
        if ntrain>=len(x):ntrain=len(x)-1
        train_x=x[:ntrain];val_x=x[ntrain:]
        # Proposal: first see whether a previously consolidated pathway is useful.
        base_path=[]
        with torch.no_grad():base_loss=float(self._candidate_objective(train_x,val_x,base_path,None))
        reuse=0
        if reuse_candidates>0 and len(self.branches):
            options=list(range(len(self.branches)))
            self.rng.shuffle(options)
            for idx in options[:reuse_candidates]:
                with torch.no_grad():loss=float(self._candidate_objective(train_x,val_x,[idx],None))
                if loss < base_loss-improve_threshold:
                    base_loss=loss;base_path=[idx];reuse=1
        before=base_loss
        chosen_path=base_path[:]
        acc=False;branch_id=-1;target=-1
        if allow_new and steps>0:
            branch=self._fresh_branch(fanin,proposal,train_x)
            self.branches.append(branch)
            branch_id=len(self.branches)-1
            target=branch.target
            candidate_path=base_path+[branch_id]
            opt=torch.optim.Adam(branch.parameters(),lr=lr)
            for _ in range(steps):
                # Current-class training supports only. Competition from stored
                # old class models is detached; no historical image replay.
                loss=self._candidate_objective(train_x,train_x,candidate_path,branch)
                regularity=.0005*(branch.w_exc.square().mean()+branch.w_gate.square().mean())
                opt.zero_grad(set_to_none=True)
                (loss+regularity).backward()
                opt.step()
            with torch.no_grad():new_loss=float(self._candidate_objective(train_x,val_x,candidate_path,branch))
            if math.isfinite(new_loss) and new_loss<base_loss-improve_threshold:
                chosen_path=candidate_path;acc=True;after=new_loss
                for p in branch.parameters():p.requires_grad_(False)
            else:
                # Never leave an unselected branch active, nor consume memory.
                self.branches.pop(-1);branch_id=-1;target=-1;after=base_loss
        else:after=base_loss
        with torch.no_grad():
            prototype=F.normalize(self._rep(x,chosen_path).mean(0),dim=0)
            if len(chosen_path):
                delta=float((self._rep(x,chosen_path)-self._rep(x,[])).square().mean().sqrt())
            else:delta=0.
            self.prototypes=torch.cat((self.prototypes,prototype[None,:]),dim=0)
            self.paths.append(chosen_path)
        return EnrollmentReport(y,acc,reuse,branch_id,target,before,after,delta,self.branch_kind)

    def memory_bytes(self):
        # Representation memory excludes the frozen pre-trained graph.
        return sum(t.numel()*t.element_size() for k,t in self.state_dict().items()
                   if k=='prototypes' or k.startswith('branches.'))

    def topology(self):
        return [{'branch_id':i,'target_neuron':b.target,
                 'source_ids':b.sources.detach().cpu().tolist(),
                 'kind':b.kind,'used_by_classes':[c for c,p in enumerate(self.paths) if i in p]}
                for i,b in enumerate(self.branches)]


def save_model(model:NeuroWeaveAssemblies,path):
    """Save tensor state plus primitive metadata, suitable for weights_only loading."""
    m={'input_dim':model.graph.input_dim,'kind':model.graph.kind,
       'graph_branches':model.graph.branches,'fanin':model.graph.fanin,
       'connectivity':[u.source_ids.detach().cpu().tolist() for u in model.graph.units],
       'branch_kind':model.branch_kind,'temperature':model.temperature,
       'initial_gain':model.initial_gain,'paths':[list(p) for p in model.paths],
       'branch_info':[{'target':b.target,'sources':b.sources.cpu().tolist(),
                       'kind':b.kind} for b in model.branches],
       'rng_state':model.rng.getstate(),
       'param_rng_state':model.param_rng.get_state()}
    state={k:v.detach().cpu() for k,v in model.state_dict().items()}
    torch.save({'format':'neuro_weave_v21_soma_1','manifest':m,'state':state},path)


def load_model(path,device='cpu'):
    from .model import DendriticGraph
    payload=torch.load(path,map_location='cpu',weights_only=True)
    if payload.get('format')!='neuro_weave_v21_soma_1':raise ValueError('unknown checkpoint format')
    m=payload['manifest'];sd=payload['state']
    graph=DendriticGraph(m['input_dim'],0,m['graph_branches'],m['fanin'],m['kind'],seed=0)
    for sources in m['connectivity']:graph.add_neuron(source_ids=sources)
    model=NeuroWeaveAssemblies(graph,seed=0,branch_kind=m['branch_kind'],
                               temperature=m['temperature'],initial_gain=m['initial_gain'])
    model.prototypes=torch.empty_like(sd['prototypes'])
    model.paths=[list(p) for p in m['paths']]
    for info in m['branch_info']:
        b=SomaCompartment(info['target'],info['sources'],info['kind'],model.initial_gain)
        for p in b.parameters():p.requires_grad_(False)
        model.branches.append(b)
    model.load_state_dict(sd,strict=True)
    model.rng.setstate(m['rng_state'])
    model.param_rng.set_state(m['param_rng_state'])
    return model.to(device)
