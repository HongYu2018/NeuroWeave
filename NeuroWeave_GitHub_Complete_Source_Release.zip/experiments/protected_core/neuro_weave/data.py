"""Source-vs-novel object-class split with no novel-class training leakage."""
from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
import io, os, random, re, tarfile, urllib.request, zipfile, hashlib, pickle
from pathlib import Path
from PIL import Image, ImageDraw
import numpy as np
import torch

COIL_URL='https://www.cs.columbia.edu/CAVE/databases/SLAM_coil-20_coil-100/coil-100/coil-100.zip'
PETS_IMAGES='https://www.robots.ox.ac.uk/~vgg/data/pets/data/images.tar.gz'
PETS_ANNOT='https://www.robots.ox.ac.uk/~vgg/data/pets/data/annotations.tar.gz'
CIFAR10_URL='https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz'
CIFAR10_MD5='c58f30108f718f92721af3b95e74349a'


def download(url:str, dest:Path)->Path:
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists() and dest.stat().st_size > 200000: return dest
    tmp=dest.with_suffix(dest.suffix+'.part')
    req=urllib.request.Request(url,headers={'User-Agent':'NeuroWeave-Research/1.6'})
    with urllib.request.urlopen(req,timeout=90) as r, tmp.open('wb') as f:
        import shutil
        shutil.copyfileobj(r,f)
    tmp.replace(dest)
    return dest


def safe_tar_extract(archive:tarfile.TarFile, root:Path)->None:
    root=root.resolve()
    for m in archive.getmembers():
        target=(root/m.name).resolve()
        if not target.is_relative_to(root) or m.issym() or m.islnk() or m.isdev():
            raise RuntimeError(f'Unsafe archive member: {m.name}')
    archive.extractall(root,filter='data')


def prepare_coil(root:Path)->Path:
    root=Path(root); images=root/'coil100'/'images'
    if len(list(images.rglob('obj*__*.png')))>=7000:return images
    archive=download(COIL_URL,root/'downloads'/'coil-100.zip')
    images.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as f:
        for member in f.infolist():
            if member.is_dir() or not re.search(r'obj\d+__\d+\.png$',member.filename,re.I):continue
            basename=Path(member.filename).name
            with f.open(member) as src, (images/basename).open('wb') as dst:
                import shutil
                shutil.copyfileobj(src,dst)
    if len(list(images.glob('obj*__*.png')))<7000:raise RuntimeError('Incomplete COIL-100 archive')
    return images


def prepare_pets(root:Path)->Path:
    root=Path(root); base=root/'pets'; base.mkdir(parents=True,exist_ok=True)
    for name,url,check in [('images.tar.gz',PETS_IMAGES,'images'),('annotations.tar.gz',PETS_ANNOT,'annotations')]:
        target=base/check
        if target.exists() and (list(target.glob('*.jpg')) if check=='images' else (target/'trainval.txt').exists()):
            continue
        f=download(url,root/'downloads'/name)
        with tarfile.open(f,'r:gz') as arc: safe_tar_extract(arc,base)
    if not (base/'annotations'/'trainval.txt').exists():raise RuntimeError('Oxford annotations missing')
    return base


def pixels(image:Image.Image, size:int=16)->torch.Tensor:
    with image.convert('RGB') as rgb:
        arr=np.asarray(rgb.resize((size,size),Image.Resampling.BILINEAR),dtype=np.float32).copy()/255.
    return torch.from_numpy(np.transpose(arr,(2,0,1)).reshape(-1))

@dataclass
class DataBundle:
    source_train_x:torch.Tensor
    source_train_y:torch.Tensor
    source_val_x:torch.Tensor
    source_val_y:torch.Tensor
    source_test_x:torch.Tensor
    source_test_y:torch.Tensor
    novel:dict[int,dict[str,torch.Tensor]]
    source_classes:list[int]
    novel_classes:list[int]
    image_size:int
    dataset_name:str


def make_synthetic_image(category:int, rng:random.Random,size:int=64)->Image.Image:
    im=Image.new('RGB',(size,size),(18,20,25))
    draw=ImageDraw.Draw(im)
    shape=category%6
    hue=category//6
    x=rng.randint(10,17);y=rng.randint(10,17)
    bounds=(x,y,x+35,y+35)
    color=(min(255,100+rng.randint(-30,30)),75+90*hue,65+30*shape)
    if shape==0:draw.ellipse(bounds,fill=color)
    elif shape==1:draw.rectangle(bounds,fill=color)
    elif shape==2:draw.polygon([(x+17,y),(x+35,y+35),(x,y+35)],fill=color)
    elif shape==3:draw.polygon([(x+17,y),(x+35,y+17),(x+17,y+35),(x,y+17)],fill=color)
    elif shape==4:
        draw.ellipse(bounds,outline=color,width=6)
    else:
        draw.rectangle(bounds,outline=color,width=6)
        draw.line((x,y,x+35,y+35),fill=color,width=4)
    return im


def _make_synthetic(seed:int):
    records=defaultdict(lambda:{'train':[],'val':[],'query':[]})
    for cat in range(12):
        rng=random.Random(1009+cat*31)
        for split,count in [('train',22),('val',8),('query',24)]:
            records[cat][split]=[make_synthetic_image(cat,rng) for _ in range(count)]
    return records


def _make_coil(root:Path):
    images=prepare_coil(root)
    records=defaultdict(lambda:{'train':[],'val':[],'query':[]})
    for path in images.glob('obj*__*.png'):
        match=re.fullmatch(r'obj(\d+)__(\d+)\.png',path.name,re.I)
        if not match:continue
        obj,ang=map(int,match.groups())
        if ang%20==0:partition='train'
        elif ang%20==10:partition='val'
        else:partition='query'
        records[obj][partition].append(path)
    return records


def _make_pets(root:Path,seed:int):
    base=prepare_pets(root)
    records=defaultdict(lambda:{'train':[],'val':[],'query':[]})
    rr=random.Random(seed+880)
    for file,split in [('trainval.txt','train'),('test.txt','query')]:
        lines=(base/'annotations'/file).read_text().splitlines()
        groups=defaultdict(list)
        for line in lines:
            if not line.strip() or line.startswith('#'):continue
            parts=line.split(); name=parts[0];label=int(parts[1])-1
            path=base/'images'/f'{name}.jpg'
            if path.exists():groups[label].append(path)
        for cls,paths in groups.items():
            rr.shuffle(paths)
            if split=='train':
                nval=max(2,int(len(paths)*0.2))
                records[cls]['val']=paths[:nval]
                records[cls]['train']=paths[nval:]
            else:records[cls]['query']=paths
    return records


def _make_digits(seed:int):
    """Independent UCI handwritten digits dataset distributed via sklearn.

    Disjoint, class-stratified item split: 64 train, 28 validation, 48 query
    per class. Learning uses only first max_train source or 4 novel train
    examples. Validation/query do not enter branch choice.
    """
    from sklearn.datasets import load_digits
    raw=load_digits()
    records=defaultdict(lambda:{'train':[],'val':[],'query':[]})
    for cls in range(10):
        inds=np.flatnonzero(raw.target==cls).tolist()
        rng=random.Random(10701+seed*1009+cls*79)
        rng.shuffle(inds)
        assert len(inds)>=140, 'Unexpected digits class support count'
        for part,sub in [('train',inds[:64]),('val',inds[64:92]),('query',inds[92:140])]:
            for i in sub:
                im=np.uint8(raw.images[i] * (255./16.))
                records[cls][part].append(Image.fromarray(im,mode='L'))
    return records



def _make_cifar10(root:Path, seed:int):
    """Official CIFAR-10 training/test split; 4-shot enrollment happens in build_data.

    Per class sample 64 fit-pool + 28 separate training-derived validation +
    48 held-out official-test images. The test labels never enter optimization.
    Input pixels are bilinearly resized to 16x16 by the shared pixels() method.
    This is intentionally challenging 4-shot recognition, not a standard full-data CIFAR-10 benchmark.
    """
    archive=download(CIFAR10_URL,Path(root)/'downloads'/'cifar-10-python.tar.gz')
    md5=hashlib.md5()
    with archive.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''): md5.update(part)
    if md5.hexdigest()!=CIFAR10_MD5:
        raise RuntimeError('CIFAR-10 checksum mismatch: do not use a corrupted or unofficial archive')
    groups=defaultdict(lambda:{'train':[],'val':[],'query':[]})
    with tarfile.open(archive,'r:gz') as tf:
        def get_batch(name):
            path=f'cifar-10-batches-py/{name}'
            try:member=tf.getmember(path)
            except KeyError as exc:raise RuntimeError(f'CIFAR-10 member missing: {path}') from exc
            source=tf.extractfile(member)
            if source is None:raise RuntimeError('Missing batch contents')
            batch=pickle.load(source,encoding='bytes')
            raw=np.asarray(batch[b'data'],dtype=np.uint8).reshape(-1,3,32,32).transpose(0,2,3,1)
            labels=np.asarray(batch[b'labels'],dtype=int)
            return raw,labels
        trainparts=[get_batch(f'data_batch_{i}') for i in range(1,6)]
        train_x=np.concatenate([a for a,b in trainparts],axis=0)
        train_y=np.concatenate([b for a,b in trainparts])
        test_x,test_y=get_batch('test_batch')
    if len(train_y)!=50000 or len(test_y)!=10000:
        raise RuntimeError('Official CIFAR-10 split count mismatch')
    for cls in range(10):
        rng=random.Random(10701+seed*1009+cls*79)
        fit_inds=np.flatnonzero(train_y==cls).tolist()
        query_inds=np.flatnonzero(test_y==cls).tolist()
        rng.shuffle(fit_inds);rng.shuffle(query_inds)
        if len(fit_inds)<92 or len(query_inds)<48:raise RuntimeError('CIFAR-10 class count mismatch')
        for part,arr,inds in [('train',train_x,fit_inds[:64]),('val',train_x,fit_inds[64:92]),('query',test_x,query_inds[:48])]:
            groups[cls][part]=[Image.fromarray(arr[i],mode='RGB') for i in inds]
    return groups

def build_data(dataset:str,root:Path,seed:int=11,size:int=16,
               source_classes:int=8,novel_classes:int=4,max_train:int=32,max_val:int=16)->DataBundle:
    if dataset=='synthetic':records=_make_synthetic(seed)
    elif dataset=='coil100':records=_make_coil(Path(root))
    elif dataset=='pets':records=_make_pets(Path(root),seed)
    elif dataset=='digits':records=_make_digits(seed)
    elif dataset=='cifar10':records=_make_cifar10(Path(root),seed)
    else:raise ValueError(dataset)
    classes=sorted([c for c,r in records.items() if r['train'] and r['val'] and r['query']])
    rr=random.Random(seed);rr.shuffle(classes)
    needed=source_classes+novel_classes
    if len(classes)<needed:raise ValueError(f'Need {needed} classes, have {len(classes)}')
    source=classes[:source_classes];novel=classes[source_classes:needed]
    sx=[];sy=[];vx=[];vy=[];tx=[];ty=[];novel_bank={}
    def convert(items):
        data=[]
        for obj in items:
            try:
                if isinstance(obj,Image.Image):data.append(pixels(obj,size))
                else:
                    with Image.open(obj) as im:data.append(pixels(im,size))
            except (OSError,ValueError) as exc:raise RuntimeError(f'Invalid image {obj}') from exc
        return torch.stack(data) if data else torch.empty(0,size*size*3)
    for idx,cls in enumerate(source):
        r=records[cls]; rr.shuffle(r['train']);rr.shuffle(r['val'])
        a=convert(r['train'][:max_train]);b=convert(r['val'][:max_val])
        sx.append(a);sy.append(torch.full((len(a),),idx,dtype=torch.long))
        vx.append(b);vy.append(torch.full((len(b),),idx,dtype=torch.long))
        c=convert(r['query'][:48]);tx.append(c);ty.append(torch.full((len(c),),idx,dtype=torch.long))
    for cls in novel:
        r=records[cls];rr.shuffle(r['train']);rr.shuffle(r['query'])
        novel_bank[cls]={'support':convert(r['train']), 'validation':convert(r['val'][:max_val]), 'query':convert(r['query'][:48])}
    return DataBundle(torch.cat(sx),torch.cat(sy),torch.cat(vx),torch.cat(vy),
                      torch.cat(tx),torch.cat(ty),novel_bank,source,novel,size,dataset)
