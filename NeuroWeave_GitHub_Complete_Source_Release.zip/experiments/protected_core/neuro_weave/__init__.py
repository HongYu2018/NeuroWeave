"""NeuroWeave v1.6: exploratory self-organising dendritic circuit research."""
__version__ = '1.6.0'
