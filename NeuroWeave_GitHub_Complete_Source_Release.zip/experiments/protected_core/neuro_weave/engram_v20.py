"""Research prototype: protected dendritic assemblies and local fast plasticity.

A frozen 32-soma sparse graph forms a *stable* long-term feature substrate.
Class memories are class means of its feature codes (not old images).
For a new category, a stochastic fan-in fast compartment is physically attached
by metadata to an existing soma; its Hebbian contrastive weights are formed
from new labelled supports versus PREVIOUS CLASS PROTOTYPES (not old images).
Old core parameters and class prototypes are invariant by construction.

This is a testable engineering hypothesis, not a validated biological model.
It does not modify original graph somas: the new compartment contributes to
class-assembly recognition downstream, so the output is a branch-specific trace.
"""
from __future__ import annotations
import random
import math
import torch
from torch import nn
import torch.nn.functional as F

class FastCompartment(nn.Module):
    """Fixed-fan-in Hebbian 'fast dendrite' fed by old neuronal responses."""
    def __init__(self, neuron_index:int, input_indices:torch.Tensor,
                 weights:torch.Tensor, midpoint:torch.Tensor, scale:float):
        super().__init__()
        self.register_buffer('target_neuron',torch.tensor(int(neuron_index),dtype=torch.long,device=weights.device))
        self.register_buffer('input_indices',input_indices.long().clone())
        self.register_buffer('weights',F.normalize(weights.detach().clone(),dim=0))
        self.register_buffer('midpoint',midpoint.detach().clone())
        self.scale=float(scale)

    def forward(self,z):
        delta=z.index_select(1,self.input_indices)-self.midpoint
        return torch.tanh(self.scale*(delta*self.weights).sum(-1))

class StableDendriticAssemblies(nn.Module):
    """One task-agnostic nearest-class readout plus branch-local engrams.

    The old prototypes remain *bitwise unchanged* on every expansion.
    New branches are separately ablatable; no task or stage ID at inference.
    """
    def __init__(self, graph:nn.Module, total_capacity:int=64, fanin:int=8,
                 beta:float=.15, branch_scale:float=6., seed:int=11):
        super().__init__()
        if fanin<2 or total_capacity<1 or beta<0:raise ValueError('Invalid capacity/fanin/beta')
        self.graph=graph
        for p in self.graph.parameters():p.requires_grad_(False)
        self.graph.eval()
        self.total_capacity=int(total_capacity)
        self.fanin=int(fanin)
        self.beta=float(beta)
        self.branch_scale=float(branch_scale)
        self.rng=random.Random(seed)
        self.register_buffer('prototypes',torch.empty(0,len(graph.units)))
        self.fast_branches=nn.ModuleList()
        self.register_buffer('class_branch_ids',torch.empty(0,dtype=torch.long))  # -1=none
        self.protected_origin_classes=0

    def train(self,mode=True):
        super().train(mode)
        self.graph.eval()  # never change original long-term pathways
        return self

    @torch.no_grad()
    def representation(self,x):
        return F.normalize(self.graph(x),dim=-1,eps=1e-7)

    @torch.no_grad()
    def enroll(self,x,y,form_branches:bool=True):
        """Append all new labels; use only current support training data.

        The first enrollment defines the initial consolidated repertoire. Every
        subsequent enrollment adds potentially plastic dendritic compartments.
        """
        if x.device!=self.prototypes.device:raise ValueError('Move inputs to model device')
        z=self.representation(x)
        first=len(self.prototypes)
        labels=sorted(set(int(t) for t in y.tolist()))
        if not labels or labels!=list(range(first,first+len(labels))):
            raise ValueError('New classes must be contiguous and never enrolled twice')
        if first+len(labels)>self.total_capacity:raise ValueError('Class capacity exceeded')
        old=self.prototypes.detach().clone()
        new=[]
        for c in labels:
            group=z[y==c]
            if not len(group):raise ValueError('No support for class')
            mu=F.normalize(group.mean(0),dim=0)
            new.append(mu)
            index=-1
            if first>0 and form_branches:
                # Exploration is STOCHASTIC under an explicit capacity constraint;
                # Hebbian weights use new-class representations and OLD prototypes.
                n=z.shape[1]
                k=min(n,self.fanin)
                ids=torch.tensor(self.rng.sample(range(n),k),device=z.device,dtype=torch.long)
                old_mean=F.normalize(old.mean(0),dim=0)
                difference=mu.index_select(0,ids)-old_mean.index_select(0,ids)
                # Stochastic candidate can be weak; do not fake utility.
                if difference.norm()>1e-7:
                    midpoint=.5*(mu.index_select(0,ids)+old_mean.index_select(0,ids))
                    branch=FastCompartment(self.rng.randrange(n),ids,difference,midpoint,self.branch_scale)
                    self.fast_branches.append(branch)
                    index=len(self.fast_branches)-1
            self.class_branch_ids=torch.cat([self.class_branch_ids,torch.tensor([index],device=z.device,dtype=torch.long)])
        self.prototypes=torch.cat((self.prototypes,torch.stack(new,0)),dim=0)
        if first==0:self.protected_origin_classes=len(self.prototypes)
        # Enrolment never mutates old class signature, neurons, or old branches.
        if first and not torch.equal(self.prototypes[:first],old):
            raise RuntimeError('Old class prototype changed during enrollment')
        return len(new)

    def forward(self,x,ablate_fast:bool=False):
        if not len(self.prototypes):raise RuntimeError('Enroll classes first')
        z=self.representation(x)
        # Shared angular distance, not a retrained old/new softmax head.
        base=-((z[:,None,:]-self.prototypes[None,:,:])**2).sum(-1)
        if self.beta>0 and not ablate_fast:
            # Each class-specific branch is expressed on the *same* common scale.
            additions=[]
            for branch_id in self.class_branch_ids.tolist():
                if branch_id<0:
                    additions.append(z.new_zeros(z.shape[0]))
                else:
                    additions.append(self.fast_branches[branch_id](z)*self.beta)
            base=base+torch.stack(additions,dim=1)
        return base

    def memory_bytes(self):
        state=self.state_dict()
        return sum(t.numel()*t.element_size() for k,t in state.items()
                   if k.startswith('prototypes') or k.startswith('fast_branches'))

@torch.no_grad()
def accuracy_breakdown(model, bank:dict[int,torch.Tensor],seen:list[int],last:list[int],device):
    x=torch.cat([bank[c] for c in seen]).to(device)
    y=torch.cat([torch.full((len(bank[c]),),c,dtype=torch.long,device=device) for c in seen])
    pred=model(x).argmax(-1)
    old=[c for c in seen if c not in last]
    def acc(labels):
        mask=torch.zeros_like(y,dtype=torch.bool)
        for c in labels:mask|=y==c
        return float((pred[mask]==y[mask]).float().mean().item()) if mask.any() else None
    return {'all':acc(seen),'old':acc(old),'new':acc(last),
            'n':int(len(y))}


def save_assemblies(model:StableDendriticAssemblies,path):
    """Safe tensor+manifest checkpoint. Does not pickle executable model classes."""
    manifest={
        'input_dim':model.graph.input_dim,
        'branches':model.graph.branches,
        'fanin':model.graph.fanin,
        'kind':model.graph.kind,
        'core_connectivity':[u.source_ids.detach().cpu().tolist() for u in model.graph.units],
        'total_capacity':model.total_capacity,'fast_fanin':model.fanin,
        'beta':model.beta,'branch_scale':model.branch_scale,
        'fast_scales':[b.scale for b in model.fast_branches],
        'protected_origin_classes':model.protected_origin_classes,
        'rng_state':model.rng.getstate()
    }
    torch.save({'format':'neuro_weave_v2_alpha_1','manifest':manifest,
                'state':{k:t.detach().cpu() for k,t in model.state_dict().items()}},path)


def load_assemblies(path,device='cpu') -> StableDendriticAssemblies:
    """Reconstruct exact dynamic graph/branch shapes, then restore all tensors."""
    from .model import DendriticGraph
    try:
        payload=torch.load(path,map_location='cpu',weights_only=True)
    except TypeError as e:
        raise RuntimeError('PyTorch version with weights_only loading is required') from e
    if payload.get('format')!='neuro_weave_v2_alpha_1':
        raise ValueError('Unknown checkpoint format')
    m=payload['manifest'];sd=payload['state']
    graph=DendriticGraph(int(m['input_dim']),initial_neurons=0,
                         branches=int(m['branches']),fanin=int(m['fanin']),
                         kind=m['kind'],seed=0)
    for unit_sources in m['core_connectivity']:
        graph.add_neuron(source_ids=unit_sources)
    result=StableDendriticAssemblies(graph,int(m['total_capacity']),
                                    int(m['fast_fanin']),float(m['beta']),
                                    float(m['branch_scale']),seed=0)
    result.prototypes=torch.empty_like(sd['prototypes'])
    result.class_branch_ids=torch.empty_like(sd['class_branch_ids'])
    for i,scale in enumerate(m['fast_scales']):
        prefix=f'fast_branches.{i}.'
        module=FastCompartment(int(sd[prefix+'target_neuron']),
                               sd[prefix+'input_indices'],sd[prefix+'weights'],
                               sd[prefix+'midpoint'],float(scale))
        result.fast_branches.append(module)
    result.load_state_dict(sd,strict=True)
    result.rng.setstate(m['rng_state'])
    result.protected_origin_classes=int(m['protected_origin_classes'])
    return result.to(device)
