"""Auditable class-incremental research driver; never uses query images for selection."""
from __future__ import annotations
import argparse,csv,json,random,time,copy
from pathlib import Path
import numpy as np
import torch
from .model import DendriticGraph,GraphClassifier,parameter_count
from .data import build_data
from .continual import build_stream,collect,train_stage
from .assemblies_v21 import NeuroWeaveAssemblies,save_model


def accuracy(model,bank,classes,latest,device,batch=96,ablate=False):
    model.eval()
    preds=[];ys=[];old_preds=[]
    with torch.no_grad():
        for c in classes:
            data=bank[c]
            for xx in data.split(batch):
                scores=model(xx.to(device),ablate_branches=ablate)
                pred=scores.argmax(1)
                preds.append(pred.cpu())
                if len(classes)>len(latest):
                    old_preds.append(scores[:,:len(classes)-len(latest)].argmax(1).cpu())
                ys.append(torch.full((len(xx),),c,dtype=torch.long))
    pred=torch.cat(preds);y=torch.cat(ys)
    old=[c for c in classes if c not in latest]
    def acc(ids):
        mask=torch.isin(y,torch.tensor(ids,dtype=torch.long))
        return float((pred[mask]==y[mask]).float().mean()) if mask.any() else None
    old_mask=torch.isin(y,torch.tensor(old,dtype=torch.long))
    new_mask=~old_mask
    return {'all':acc(classes),'old':acc(old),'new':acc(latest),
            'old_only':float((torch.cat(old_preds)[old_mask]==y[old_mask]).float().mean()) if old_mask.any() else None,
            'old_to_new':float(torch.isin(pred[old_mask],torch.tensor(latest,dtype=torch.long)).float().mean()) if old_mask.any() else None,
            'new_to_old':float(torch.isin(pred[new_mask],torch.tensor(old,dtype=torch.long)).float().mean()) if new_mask.any() else None,
            'per_class':{str(c):float((pred[y==c]==y[y==c]).float().mean()) for c in classes}}


def score_drift(model,bank,old_classes,previous_scores,device):
    # Evaluation-only use of old test examples; NO scores pass to the optimizer.
    if not old_classes:return 0.
    with torch.no_grad():
        now=torch.cat([model(bank[c][:2].to(device))[:,:len(old_classes)].cpu() for c in old_classes])
    return float((now-previous_scores).abs().max())


def run(args):
    if args.new_shots<4:raise ValueError('This alpha protocol requires >=4 supports per new class')
    if args.increment<1:raise ValueError('increment must be positive')
    torch.manual_seed(args.seed);random.seed(args.seed);np.random.seed(args.seed)
    if torch.cuda.is_available() and not args.cpu:device=torch.device('cuda:0')
    else:device=torch.device('cpu')
    bundle=build_data(args.dataset,Path(args.data_root),seed=args.seed,size=args.image_size,
            source_classes=args.source_classes,novel_classes=args.novel_classes,
            max_train=args.initial_shots,max_val=args.max_val)
    stream=build_stream(bundle,increment=args.increment,shots=args.new_shots)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    rows=[];events=[];timing=[];class_matrix=[]
    # Independent point controls: same input fan-in, and roughly parameter-matched.
    settings=[('dendritic',16),('point',16),('point_budget',18)]
    for base_kind,fanin in settings:
        graph_kind='point' if base_kind.startswith('point') else 'dendritic'
        torch.manual_seed(args.seed)
        graph=DendriticGraph(stream.input_dim,initial_neurons=args.neurons,branches=4,fanin=fanin,
                            kind=graph_kind,seed=args.seed,initial_wiring_probability=.2,
                            initial_synapse_fraction=.6,spatial_sensory=True)
        base=GraphClassifier(graph,args.source_classes).to(device)
        sx,sy=collect(stream.train,stream.stage_groups[0],device)
        start=time.perf_counter()
        train_stage(base,sx,sy,args.epochs,args.lr,64,args.seed)
        base_time=time.perf_counter()-start
        print(base_kind,'source trained','params',parameter_count(base),'seconds',round(base_time,2),flush=True)
        specs=[('prototype','dendritic',False)]
        if base_kind=='dendritic':
            specs += [('adaptive_dendritic','dendritic',True),
                      ('adaptive_novelty_guided','dendritic',True),
                      ('adaptive_linear_control','linear',True)]
        else:
            specs += [('adaptive_linear','linear',True)]
        for name,comp_kind,adapt in specs:
            torch.manual_seed(args.seed+21)
            method=f'{base_kind}_{name}'
            memory=NeuroWeaveAssemblies(copy.deepcopy(base.graph),seed=args.seed+177,
                       branch_kind=comp_kind,temperature=args.temperature,
                       initial_gain=args.branch_gain).to(device)
            # No old images are cached anywhere by the enrolment algorithm.
            memory.enroll_initial(sx,sy)
            seen=stream.stage_groups[0][:]
            for stage,classes in enumerate(stream.stage_groups):
                past=seen[:] if stage>0 else []
                snap=None
                if past:
                    with torch.no_grad():
                        snap=torch.cat([memory(stream.test[c][:2].to(device))[:,:len(past)].cpu() for c in past])
                elapsed=0.
                if stage:
                    for c in classes:
                        start=time.perf_counter()
                        # The only inputs provided for learning are CURRENT class train supports.
                        report=memory.enroll_one(stream.train[c].to(device),c,
                                    fanin=args.branch_fanin,steps=args.steps if adapt else 0,
                                    lr=args.plastic_lr,proposal=('novelty' if name=='adaptive_novelty_guided' else 'stochastic'),
                                    reuse_candidates=args.reuse if adapt else 0,
                                    improve_threshold=args.accept_threshold,allow_new=adapt)
                        elapsed+=time.perf_counter()-start
                        events.append({'method':method,'stage':stage,**vars(report)})
                    seen+=classes
                t0=time.perf_counter()
                metric=accuracy(memory,stream.test,seen,classes,device,ablate=False)
                ablated=accuracy(memory,stream.test,seen,classes,device,ablate=True)
                eval_time=time.perf_counter()-t0
                drift=score_drift(memory,stream.test,past,snap,device) if past else 0.
                accepted=sum(1 for e in events if e['method']==method and e['accepted'])
                reused=sum(e['reused'] for e in events if e['method']==method)
                row={'seed':args.seed,'method':method,'stage':stage,
                    'seen_classes':len(seen),'new_classes':len(classes),
                    'accuracy_all':metric['all'],'accuracy_old':metric['old'],
                    'accuracy_new':metric['new'],
                    'old_only_accuracy':metric['old_only'],
                    'old_to_latest_class_rate':metric['old_to_new'],
                    'latest_to_old_class_rate':metric['new_to_old'],
                    'ablated_all':ablated['all'],
                    'ablated_new':ablated['new'],
                    'fixed_prototype_ablation_delta':metric['all']-ablated['all'],
                    'accepted_branches':accepted,'branch_reuse_events':reused,
                    'old_score_drift':drift,'memory_bytes':memory.memory_bytes(),
                    'base_parameters':parameter_count(base),
                    'incremental_train_sec':elapsed,'evaluation_sec':eval_time}
                rows.append(row)
                class_matrix += [{'seed':args.seed,'method':method,'stage':stage,
                                  'class_id':int(c),'accuracy':value}
                                 for c,value in metric['per_class'].items()]
                print(f'{method} stage {stage} all={metric["all"]:.3f} old={metric["old"]} new={metric["new"]:.3f} accepted={accepted} reused={reused} ablate_delta={row["fixed_prototype_ablation_delta"]:+.3f}',flush=True)
            # Save one reproducible checkpoint per method.
            save_model(memory,out/f'{method}.pt')
            (out/f'{method}_topology.json').write_text(json.dumps(memory.topology(),indent=2))
            timing.append({'method':method,'base_fit_seconds':base_time})
    with (out/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    with (out/'development_events.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=events[0].keys() if events else ['method','stage']);w.writeheader();w.writerows(events)
    with (out/'per_class_accuracy.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=class_matrix[0].keys());w.writeheader();w.writerows(class_matrix)
    (out/'configuration.json').write_text(json.dumps({**vars(args),'device':str(device),'data_class_ids':stream.names},indent=2))
    (out/'training_summary.json').write_text(json.dumps(timing,indent=2))
    print('Completed v2.1 pilot; outputs:',out,flush=True)


def parse():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',choices=['synthetic','coil100','pets','digits','cifar10'],default='synthetic')
    p.add_argument('--data-root',default='data')
    p.add_argument('--output',default='results/v21_synthetic')
    p.add_argument('--seed',type=int,default=11)
    p.add_argument('--source-classes',type=int,default=6)
    p.add_argument('--novel-classes',type=int,default=6)
    p.add_argument('--increment',type=int,default=2)
    p.add_argument('--initial-shots',type=int,default=8)
    p.add_argument('--new-shots',type=int,default=4)
    p.add_argument('--max-val',type=int,default=12)
    p.add_argument('--image-size',type=int,default=16)
    p.add_argument('--neurons',type=int,default=32)
    p.add_argument('--epochs',type=int,default=30)
    p.add_argument('--lr',type=float,default=.015)
    p.add_argument('--steps',type=int,default=20)
    p.add_argument('--plastic-lr',type=float,default=.05)
    p.add_argument('--branch-fanin',type=int,default=8)
    p.add_argument('--temperature',type=float,default=12.)
    p.add_argument('--branch-gain',type=float,default=.35)
    p.add_argument('--reuse',type=int,default=3)
    p.add_argument('--accept-threshold',type=float,default=.01)
    p.add_argument('--cpu',action='store_true')
    return p.parse_args()
if __name__=='__main__':run(parse())
