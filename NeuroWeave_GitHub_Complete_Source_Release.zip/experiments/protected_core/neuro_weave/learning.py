"""Training, held-out structural selection, and independent novel-class episodes."""
from __future__ import annotations
import copy, math, random, time
from pathlib import Path
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from .model import DendriticGraph, GraphClassifier, MLPClassifier, parameter_count, matched_mlp_width


def fit(model, x, y, epochs:int, lr:float=.012, batch_size:int=128, train_graph:bool=True):
    t0=time.perf_counter(); model.train()
    params=[p for p in model.parameters() if p.requires_grad]
    opt=torch.optim.Adam(params,lr=lr)
    for epoch in range(epochs):
        perm=torch.randperm(len(x),device=x.device)
        for b in perm.split(batch_size):
            logits=model(x[b]); loss=F.cross_entropy(logits,y[b]);opt.zero_grad();loss.backward();opt.step()
    return time.perf_counter()-t0

@torch.no_grad()
def evaluate(model,x,y):
    model.eval();logits=model(x)
    return {'loss':float(F.cross_entropy(logits,y).item()),
            'accuracy':float((logits.argmax(-1)==y).float().mean().item())}


def structural_growth(model:GraphClassifier, x,y,vx,vy,
                      proposals:int=8,max_accept:int=4,trial_epochs:int=3,
                      lr:float=.012,min_gain:float=.001,
                      parameter_penalty:float=0., prune_fraction:float=.10):
    """Select candidates by SOURCE validation loss only, never novel query labels.

    At each proposal, HEAD-ONLY training is a reference control with identical
    optimization steps. Earlier neurons are frozen for both arms. Candidate
    neuron and new classifier head can train in the candidate arm.
    """
    events=[]; total_train=0.
    for proposal_id in range(proposals):
        if sum(e['accepted'] for e in events)>=max_accept:break
        ref=copy.deepcopy(model)
        ref.graph.freeze_old()
        for p in ref.head.parameters():p.requires_grad_(True)
        total_train+=fit(ref,x,y,trial_epochs,lr)
        ref_perf=evaluate(ref,vx,vy)
        trial=copy.deepcopy(model)
        idx=trial.graph.add_neuron(allow_existing=True)
        trial.expand()
        trial.graph.freeze_old(keep_last_trainable=True)
        total_train+=fit(trial,x,y,trial_epochs,lr)
        candidate_perf=evaluate(trial,vx,vy)
        extra_params=parameter_count(trial)-parameter_count(model)
        gain=ref_perf['loss']-candidate_perf['loss']-parameter_penalty*extra_params
        accepted=gain>min_gain
        source_ids=trial.graph.units[-1].source_ids.tolist()
        pruned=0
        if accepted:
            pruned=trial.graph.units[-1].prune_weak_synapses(prune_fraction)
            # Reject pruning if it cancels the genuine held-out loss advantage.
            after=evaluate(trial,vx,vy)
            if after['loss'] >= ref_perf['loss']-min_gain:
                accepted=False;pruned=0
        selected=trial if accepted else ref
        # CRITICAL: a rejected candidate must still consume its proposed random
        # wiring. Otherwise deepcopy(ref) restores the identical RNG state and
        # every rejected proposal repeats the same source links indefinitely.
        # This advances stochastic exploration without accepting the candidate.
        selected.graph.random.setstate(trial.graph.random.getstate())
        model=selected
        events.append({'proposal':proposal_id,'accepted':int(accepted),
                       'ref_validation_loss':ref_perf['loss'],
                       'candidate_validation_loss':candidate_perf['loss'],
                       'validation_gain_minus_penalty':gain,
                       'new_unit':idx,'new_depth':trial.graph.depths[-1],
                       'parameter_cost':extra_params,'pruned_synapses':pruned,
                       'source_indices':str(source_ids)})
    model.graph.unfreeze()
    return model,events,total_train


def unconditional_growth(model:GraphClassifier,x,y,num_additions:int,epochs:int=3,lr:float=.012,prune_fraction:float=.10):
    """Capacity-matched stochastic growth, no candidate acceptance by validation."""
    events=[];seconds=0.
    for i in range(num_additions):
        idx=model.graph.add_neuron(allow_existing=True)
        model.expand();model.graph.freeze_old(keep_last_trainable=True)
        seconds+=fit(model,x,y,epochs,lr)
        removed=model.graph.units[-1].prune_weak_synapses(prune_fraction)
        events.append({'proposal':i,'accepted':1,'new_unit':idx,
                       'new_depth':model.graph.depths[-1], 'pruned_synapses':removed,
                       'source_indices':str(model.graph.units[-1].source_ids.tolist())})
    model.graph.unfreeze()
    return model,events,seconds


def _ridge_predict(support:torch.Tensor,query:torch.Tensor,sy:torch.Tensor,nclasses:int,reg:float=.05):
    # Solve in sample space: stable for 1-shot and many hidden features.
    S=F.normalize(support,dim=1)
    Q=F.normalize(query,dim=1)
    # constant bias feature
    S=torch.cat((S,torch.ones(len(S),1,device=S.device)*.25),dim=1)
    Q=torch.cat((Q,torch.ones(len(Q),1,device=Q.device)*.25),dim=1)
    labels=F.one_hot(sy,nclasses).float()
    A=S@S.T + reg*torch.eye(len(S),device=S.device)
    weights=torch.linalg.solve(A,labels)
    return (Q@S.T@weights).argmax(-1)

@torch.no_grad()
def few_shot(model, novel:dict, shots:list[int], ways:int=3, episodes:int=20,seed:int=11,device='cpu'):
    """Novel categories are absent from SOURCE training and structural selection.
    Support examples come from novel train pool; query from disjoint partition.
    Identical episodes are used across models by providing the same seed.
    """
    model.eval(); rng=random.Random(seed); classes=sorted(novel)
    if len(classes)<ways:raise ValueError('Insufficient novel classes')
    rows=[]
    for k in shots:
        for episode in range(episodes):
            chosen=rng.sample(classes,ways)
            supports=[];queries=[];sy=[];qy=[]
            for label,cls in enumerate(chosen):
                bank=novel[cls]
                if len(bank['support'])<k or len(bank['query'])<1:raise ValueError('Insufficient support / query examples')
                picked=rng.sample(range(len(bank['support'])),k)
                supports.append(bank['support'][picked]);queries.append(bank['query'][:min(12,len(bank['query']))])
                sy.extend([label]*k);qy.extend([label]*min(12,len(bank['query'])))
            xs=torch.cat(supports).to(device);xq=torch.cat(queries).to(device)
            fs=model.representations(xs);fq=model.representations(xq)
            preds=_ridge_predict(fs,fq,torch.tensor(sy,device=device),ways)
            acc=float((preds==torch.tensor(qy,device=device)).float().mean().item())
            rows.append({'shot':k,'episode':episode,'ways':ways,
                         'accuracy':acc, 'classes':','.join(map(str,chosen))})
    return rows


def matched_random_schedule(model:GraphClassifier,x,y,proposals:int,accepted:int,epochs:int=3,
                            lr:float=.012,prune_fraction:float=.10,seed:int=11):
    """Same proposal opportunities and number of added units as selected-growth arm.

    Growth times are random; no validation information is used by this control.
    """
    rng=random.Random(seed)
    moments=set(rng.sample(range(proposals),min(proposals,accepted)))
    events=[];seconds=0.
    for step in range(proposals):
        grow=step in moments
        if grow:
            idx=model.graph.add_neuron(allow_existing=True)
            model.expand()
        model.graph.freeze_old(keep_last_trainable=grow)
        seconds+=fit(model,x,y,epochs,lr)
        if grow:
            removed=model.graph.units[-1].prune_weak_synapses(prune_fraction)
            events.append({'proposal':step,'accepted':1,'new_unit':idx,
                           'new_depth':model.graph.depths[-1], 'pruned_synapses':removed,
                           'source_indices':str(model.graph.units[-1].source_ids.tolist())})
        else:
            events.append({'proposal':step,'accepted':0})
    model.graph.unfreeze()
    return model,events,seconds
