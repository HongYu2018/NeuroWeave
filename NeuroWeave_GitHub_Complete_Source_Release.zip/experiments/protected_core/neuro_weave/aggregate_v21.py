"""Aggregate v2.1 seed results with paired, stage-matched comparisons."""
from __future__ import annotations
import argparse,csv,statistics
from collections import defaultdict
from pathlib import Path


def run(paths,output):
    by_key=defaultdict(list);by_seed=defaultdict(dict)
    for filename in paths:
        with open(filename,newline='') as f:
            for row in csv.DictReader(f):
                seed=int(row['seed']); stage=int(row['stage']);method=row['method']
                key=(stage,method)
                metric=float(row['accuracy_all']); by_key[key].append(metric)
                if method in by_seed[(seed,stage)]:raise ValueError('Duplicate method/seed/stage')
                by_seed[(seed,stage)][method]=metric
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    with (out/'mean_sd.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['stage','method','seeds','accuracy_mean','accuracy_sample_sd'])
        for (stage,method),v in sorted(by_key.items()):
            w.writerow([stage,method,len(v),statistics.mean(v),statistics.stdev(v) if len(v)>1 else 0.])
    pairs=[('dendritic_adaptive_dendritic','dendritic_prototype'),
           ('dendritic_adaptive_novelty_guided','dendritic_adaptive_dendritic'),
           ('dendritic_adaptive_dendritic','dendritic_adaptive_linear_control'),
           ('dendritic_adaptive_dendritic','point_budget_adaptive_linear')]
    with (out/'paired_differences.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['stage','method_a','method_b','seeds','mean_pp','sample_sd_pp'])
        for stage in sorted({s for _,s in by_seed}):
            for a,b in pairs:
                values=[100*(rows[a]-rows[b]) for (seed,s),rows in by_seed.items()
                        if s==stage and a in rows and b in rows]
                if values:
                    w.writerow([stage,a,b,len(values),statistics.mean(values),
                                statistics.stdev(values) if len(values)>1 else 0.])
    print('Saved aggregated results to',out)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('files',nargs='+');p.add_argument('--output',required=True)
    x=p.parse_args();run(x.files,x.output)
