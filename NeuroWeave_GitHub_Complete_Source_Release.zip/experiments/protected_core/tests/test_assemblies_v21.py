"""Release-gate tests for actual pre-soma plasticity and replay-free selection."""
import copy
import math
import pytest
import torch
from neuro_weave.model import DendriticGraph
from neuro_weave.assemblies_v21 import (
    SomaCompartment,forward_with_soma_branches,NeuroWeaveAssemblies,
    save_model,load_model,
)


def make_graph(kind='dendritic',neurons=9,input_dim=18):
    torch.manual_seed(9)
    return DendriticGraph(input_dim,neurons,4,4,kind,seed=3,
                          initial_wiring_probability=.5)


def initial_model(kind='dendritic',branch_kind='dendritic'):
    m=NeuroWeaveAssemblies(make_graph(kind),seed=9,branch_kind=branch_kind)
    torch.manual_seed(12)
    xx=torch.randn(12,18)
    m.enroll_initial(xx,torch.tensor([0]*4+[1]*4+[2]*4))
    return m


def test_no_injection_exactly_original_graph():
    g=make_graph();x=torch.randn(5,18)
    assert torch.equal(g(x),forward_with_soma_branches(g,x,[]))


@pytest.mark.parametrize('kind', ['dendritic','point'])
def test_branch_physically_changes_target_soma(kind):
    g=make_graph(kind)
    t=5
    b=SomaCompartment(t,[0,1,18,19],'dendritic')
    with torch.no_grad():
        b.w_exc.fill_(1.);b.w_gate.fill_(1.);b.gain.fill_(1.)
    x=torch.randn(7,18)
    old=g(x);new=forward_with_soma_branches(g,x,[b])
    assert torch.allclose(old[:,:t],new[:,:t],atol=1e-7)
    assert (old[:,t]-new[:,t]).abs().max()>1e-4


def test_branch_propagates_into_actual_downstream_neuron():
    # Deterministically wire neuron 1 to neuron 0, not merely a readout trace.
    g=DendriticGraph(8,initial_neurons=0,branches=2,fanin=3,seed=4)
    g.add_neuron(source_ids=[[0,1,2],[3,4,5]])
    g.add_neuron(source_ids=[[8,1,2],[8,3,4]])
    with torch.no_grad():
        g.units[1].weights.fill_(2.)
        g.units[1].soma_weights.fill_(2.)
    b=SomaCompartment(0,[0,1,2],'dendritic',gain=2.)
    with torch.no_grad():
        b.w_exc.fill_(1.);b.w_gate.fill_(1.);b.gain.fill_(2.)
    x=torch.rand(5,8)
    old=g(x);new=forward_with_soma_branches(g,x,[b])
    assert not torch.allclose(new[:,0],old[:,0],atol=1e-4)
    assert not torch.allclose(new[:,1],old[:,1],atol=1e-4)


def test_no_forward_or_self_edge_ever_accepted():
    g=make_graph()
    x=torch.randn(3,18)
    b=SomaCompartment(2,[18+3,1],'dendritic')
    with pytest.raises(ValueError,match='cyclic'):
        forward_with_soma_branches(g,x,[b])


def test_branch_has_gradient_and_base_is_frozen():
    m=initial_model()
    b=m._fresh_branch(5,'stochastic',torch.randn(4,18))
    y=forward_with_soma_branches(m.graph,torch.randn(5,18),[b]).square().mean()
    y.backward()
    assert b.w_exc.grad is not None and b.w_exc.grad.abs().sum()>0
    assert all(p.grad is None for p in m.graph.parameters())


def test_new_class_does_not_mutate_old_signatures_or_old_scores():
    m=initial_model()
    old_proto=m.prototypes.detach().clone()
    old_state={k:v.detach().clone() for k,v in m.graph.state_dict().items()}
    test=torch.randn(9,18)
    old=m(test).detach().clone()
    r=m.enroll_one(torch.randn(4,18),3,steps=4,fanin=4,reuse_candidates=0)
    assert r.class_id==3
    assert torch.equal(old,m(test)[:,:3])
    assert torch.equal(old_proto,m.prototypes[:3])
    assert all(torch.equal(v,m.graph.state_dict()[k]) for k,v in old_state.items())


def test_prototype_only_matches_fixed_baseline():
    m=initial_model()
    m.enroll_one(torch.randn(4,18),3,steps=0,allow_new=False,reuse_candidates=0)
    assert all(not p for p in m.paths)
    assert len(m.branches)==0
    x=torch.randn(3,18)
    expected=m.temperature*(m._rep(x,[])@m.prototypes.T)
    assert torch.allclose(m(x),expected,atol=1e-6)


def test_rejected_branch_is_physically_removed():
    m=initial_model()
    r=m.enroll_one(torch.randn(4,18),3,steps=1,improve_threshold=1e10)
    assert not r.accepted and len(m.branches)==0 and m.paths[3]==[]


def test_acceptance_and_reuse_are_real_path_dependencies():
    m=initial_model()
    r=m.enroll_one(torch.randn(4,18),3,steps=2,improve_threshold=-1e10)
    assert r.accepted and r.new_branch_id==0 and m.paths[3]==[0]
    with torch.no_grad():
        x=torch.randn(8,18)
        branch=m._rep(x,[0]);stable=m._rep(x,[])
    assert (branch-stable).abs().max()>0
    next_support=torch.randn(4,18)
    # Force support-only reuse via threshold comparison; an existing branch can
    # become a functional component of a LATER class.
    m.enroll_one(next_support,4,steps=0,reuse_candidates=1,improve_threshold=-1e10,allow_new=False)
    assert m.paths[4]==[0]
    assert m.topology()[0]['used_by_classes']==[3,4]


def test_dendritic_local_product_differs_from_linear_control():
    a=SomaCompartment(5,[0,1,2,3],'dendritic')
    b=SomaCompartment(5,[0,1,2,3],'linear')
    b.load_state_dict(a.state_dict())
    x=torch.randn(12,18)
    assert not torch.allclose(a(x),b(x),atol=1e-5)
    assert sum(p.numel() for p in a.parameters())==sum(p.numel() for p in b.parameters())


def test_calibrated_scores_compete_over_all_classes():
    m=initial_model();m.enroll_one(torch.randn(4,18),3,steps=0)
    assert m(torch.randn(4,18)).shape==(4,4)
    assert all(math.isfinite(v) for v in m(torch.randn(4,18)).flatten().tolist())


def test_novelty_target_uses_only_support_and_stored_prototypes():
    m=initial_model()
    b=m._fresh_branch(4,'novelty',torch.randn(4,18))
    assert b.target>=6 and all(0<=int(src)<18+b.target for src in b.sources)


def test_checkpoint_exact_roundtrip_and_future_enrollment(tmp_path):
    m=initial_model()
    m.enroll_one(torch.randn(4,18),3,steps=2,improve_threshold=-1e10)
    x=torch.randn(6,18)
    old=m(x).detach().clone()
    file=tmp_path/'safe_tensor_checkpoint.pt';save_model(m,file)
    recovered=load_model(file)
    assert torch.equal(old,recovered(x))
    assert m.paths==recovered.paths
    for k,v in m.state_dict().items():assert torch.equal(v,recovered.state_dict()[k])
    next_x=torch.randn(4,18)
    r=m.enroll_one(next_x,4,steps=2,improve_threshold=-1e10)
    rr=recovered.enroll_one(next_x,4,steps=2,improve_threshold=-1e10)
    assert rr.accepted==r.accepted and rr.target==r.target
    assert torch.allclose(m(x),recovered(x),atol=1e-6)


def test_bad_labels_and_supports_rejected():
    m=initial_model()
    with pytest.raises(ValueError):m.enroll_one(torch.randn(4,18),9)
    with pytest.raises(ValueError):m.enroll_one(torch.randn(2,18),3)
    with pytest.raises(RuntimeError):m.enroll_initial(torch.randn(4,18),torch.zeros(4,dtype=torch.long))


@pytest.mark.skipif(not torch.cuda.is_available(),reason='CUDA unavailable on test host')
def test_cuda_branch_gradient_growth_roundtrip(tmp_path):
    m=initial_model().to('cuda:0')
    support=torch.randn(4,18,device='cuda:0')
    m.enroll_one(support,3,steps=2,improve_threshold=-1e10)
    x=torch.randn(3,18,device='cuda:0')
    scores=m(x).detach().clone()
    save_model(m,tmp_path/'gpu.pt')
    n=load_model(tmp_path/'gpu.pt','cuda:0')
    assert torch.allclose(scores,n(x),atol=1e-6)
    assert all(v.is_cuda for v in n.state_dict().values())
