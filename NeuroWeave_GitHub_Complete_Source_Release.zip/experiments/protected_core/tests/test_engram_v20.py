import pytest
import torch
from neuro_weave.model import DendriticGraph
from neuro_weave.engram_v20 import StableDendriticAssemblies

def setup(kind='dendritic',beta=.15):
    torch.manual_seed(5)
    g=DendriticGraph(12,8,4,4,kind=kind,seed=5,initial_wiring_probability=.2)
    return StableDendriticAssemblies(g,total_capacity=6,fanin=4,beta=beta,seed=5)

def test_expand_preserves_all_old_signatures_and_core():
    model=setup()
    x=torch.randn(12,12); y=torch.tensor([0]*6+[1]*6)
    model.enroll(x,y)
    previous=model.prototypes.clone()
    before=[t.detach().clone() for t in model.graph.state_dict().values()]
    old_logits=model(torch.randn(2,12))
    xx=torch.randn(4,12);yy=torch.tensor([2,2,3,3]);model.enroll(xx,yy)
    assert torch.equal(model.prototypes[:2],previous)
    assert all(torch.equal(a,b) for a,b in zip(before,model.graph.state_dict().values()))
    assert len(model.fast_branches)==2
    assert model(torch.randn(3,12)).shape==(3,4)
    assert torch.isfinite(old_logits).all()

def test_no_task_id_and_additive_old_scores():
    m=setup();x=torch.randn(10,12);m.enroll(x,torch.tensor([0]*5+[1]*5))
    test=torch.randn(5,12);old=m(test).clone()
    m.enroll(torch.randn(6,12),torch.tensor([2]*3+[3]*3))
    assert torch.allclose(m(test)[:,:2],old,atol=1e-7)
    assert torch.isfinite(m(test)).all()

def test_branch_ablation_exactly_equals_prototype_only():
    x=torch.randn(16,12);y=torch.tensor([0]*8+[1]*8)
    a=setup(beta=.3);b=setup(beta=0.)
    a.enroll(x,y);b.enroll(x,y)
    more=torch.randn(8,12);yy=torch.tensor([2]*4+[3]*4)
    a.enroll(more,yy);b.enroll(more,yy)
    assert torch.allclose(a.prototypes,b.prototypes)
    probe=torch.randn(4,12)
    assert torch.allclose(a(probe,ablate_fast=True),b(probe),atol=1e-7)

def test_bad_label_and_budget_rejected():
    m=setup()
    with pytest.raises(ValueError):m.enroll(torch.randn(3,12),torch.tensor([1,1,1]))
    m.enroll(torch.randn(6,12),torch.tensor([0]*3+[1]*3))
    with pytest.raises(ValueError):m.enroll(torch.randn(3,12),torch.tensor([1]*3))

def test_point_control_and_memory():
    m=setup(kind='point');m.enroll(torch.randn(6,12),torch.tensor([0]*3+[1]*3))
    m.enroll(torch.randn(3,12),torch.tensor([2]*3))
    assert m.memory_bytes()>0

@pytest.mark.skipif(not torch.cuda.is_available(),reason='CUDA unavailable')
def test_gpu_branch_added_to_cuda():
    m=setup().to('cuda:0')
    m.enroll(torch.randn(6,12,device='cuda:0'),torch.tensor([0]*3+[1]*3,device='cuda:0'))
    m.enroll(torch.randn(4,12,device='cuda:0'),torch.tensor([2]*4,device='cuda:0'))
    assert all(v.device.type=='cuda' for v in m.state_dict().values())
    assert m(torch.randn(2,12,device='cuda:0')).device.type=='cuda'


def test_state_dict_roundtrip_preserves_fast_paths():
    m=setup(beta=.3)
    x=torch.randn(12,12);y=torch.tensor([0]*6+[1]*6)
    m.enroll(x,y); xx=torch.randn(8,12);yy=torch.tensor([2]*4+[3]*4);m.enroll(xx,yy)
    probe=torch.randn(7,12);out=m(probe).detach().clone()
    n=setup(beta=.3);n.enroll(x,y);n.enroll(xx,yy)
    n.load_state_dict(m.state_dict())
    assert torch.allclose(out,n(probe),atol=1e-7)
    assert torch.equal(n.class_branch_ids,m.class_branch_ids)

def test_source_logits_never_change_after_expand():
    m=setup();xx=torch.randn(12,12);m.enroll(xx,torch.tensor([0]*6+[1]*6))
    probe=torch.randn(11,12);old=m(probe)
    m.enroll(torch.randn(4,12),torch.tensor([2]*4))
    assert torch.equal(m(probe)[:,:2],old)

def test_checkpoint_reload_without_old_images(tmp_path):
    from neuro_weave.engram_v20 import save_assemblies,load_assemblies
    m=setup(beta=.025)
    x=torch.randn(12,12);y=torch.tensor([0]*6+[1]*6)
    m.enroll(x,y)
    new=torch.randn(8,12);labels=torch.tensor([2]*4+[3]*4);m.enroll(new,labels)
    probe=torch.randn(7,12);logits=m(probe).detach().clone()
    filename=tmp_path/'protected_memory.pt';save_assemblies(m,filename)
    recovered=load_assemblies(filename)
    assert torch.equal(m.prototypes,recovered.prototypes)
    assert torch.allclose(logits,recovered(probe),atol=1e-7)
    assert len(recovered.fast_branches)==2
    # The random candidate generator must also resume at the exact next proposal.
    following=torch.randn(5,12);labels=torch.tensor([4]*5)
    m.enroll(following,labels);recovered.enroll(following,labels)
    assert torch.allclose(m(probe),recovered(probe),atol=1e-7)
