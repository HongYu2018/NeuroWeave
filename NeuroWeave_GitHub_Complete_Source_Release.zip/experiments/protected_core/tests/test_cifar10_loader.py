"""CIFAR-10 reader wiring tests (real-image benchmark not executed here)."""
from pathlib import Path
from PIL import Image
import numpy as np
import pytest
from neuro_weave import data

def test_cifar10_registered_and_disjoint(monkeypatch,tmp_path):
    def fake(root,seed):
        from collections import defaultdict
        records=defaultdict(lambda:{'train':[],'val':[],'query':[]})
        for cls in range(10):
            for split,count,value in [('train',7,100),('val',5,130),('query',6,160)]:
                for i in range(count):
                    arr=np.full((32,32,3),value+i+cls,dtype=np.uint8)
                    records[cls][split].append(Image.fromarray(arr))
        return records
    monkeypatch.setattr(data,'_make_cifar10',fake)
    bundle=data.build_data('cifar10',tmp_path,seed=11,source_classes=6,novel_classes=4,max_train=4,max_val=3)
    assert bundle.source_train_x.shape==(24,768)
    assert bundle.source_test_x.shape==(36,768)
    assert len(bundle.novel)==4
    for c in bundle.novel:
        assert len(bundle.novel[c]['support'])==7
        assert len(bundle.novel[c]['query'])==6
    assert not set(bundle.source_classes)&set(bundle.novel_classes)

def test_bad_archive_checksum_rejected(monkeypatch,tmp_path):
    fake=tmp_path/'fake.tar.gz';fake.write_bytes(b'not official cifar10')
    monkeypatch.setattr(data,'download',lambda url,dest:fake)
    with pytest.raises(RuntimeError,match='checksum mismatch'):
        data._make_cifar10(tmp_path,11)
