# NeuroWeave 2.1 — Soma-integrated dendritic assemblies

**Research preview, not a proven improvement.** This new research branch implements
*real pre-somatic branch computation* and class-conditioned stable neuronal
assemblies. It is deliberately separate from the historical v1.6.x and v2.0
packages. It has been CPU-tested and functionally inspected; Windows GPU and
real COIL-100 performance must be established on the research workstation.

## Quick start (Windows + Python + CUDA)

Extract the ZIP, open PowerShell **in the `NeuroWeave_2_1` folder**. Reuse your
existing environment with working `torch` (CUDA), `numpy`, `Pillow`, `pytest`;
`python -m pip install -r requirements_minimal.txt` installs dependencies but
**do not replace a working CUDA PyTorch build unnecessarily**.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_24_V21_SMOKE.ps1
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_25_V21_COIL_PILOT.ps1
```

COIL-100 data are read from `data/coil100/images` or downloaded when absent;
you can copy `data` from your v2.0 installation. For later replication:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\RUN_26_V21_COIL_5SEEDS.ps1
```

A separate Oxford-IIIT Pet pilot is `RUN_27_V21_PETS_PILOT.ps1`, but do not
interpret a single-seed run as a validated natural-image generalisation result.

## What changed from v2.0-alpha?

In v2.0 the fast branch acted only on a class score. In v2.1 each recruited
branch computes from sampled inputs and earlier neuronal activations **before
its assigned neuron's soma activation**, and downstream neurons see this
changed activation through the existing sparse DAG. Both a local multiplicative
(`dendritic`) branch and an equal-parameter linear-sum (`linear`) branch are
implemented.

Prior class pathways, prototypes and core neuron parameters are frozen.
When a new class arrives, two of its four labelled supports fit candidate
branches and two support images select them. Reuse of already consolidated
branches is tested. No old images or previous class validation/query images
are consumed by this mechanism. All class-specific pathways are evaluated as
candidates at inference, so no true task ID is required. This is nevertheless
class-conditioned inference and **more expensive** than a single global
forward pass. The last-stage overall old-class accuracy can decline because
new class scores compete, despite unchanged old class scores.

## Main experimental outputs

- `summary.csv`: stage-wise all/old/latest-new accuracy, old-only accuracy,
  old-to-new misclassification rates; fixed-prototype branch ablations, old-score
  drift, memory and evaluation costs.
- `per_class_accuracy.csv`: previously acquired class recognition over stages.
- `development_events.csv`: support-only branch acceptance or rejection,
  candidate target, reuse, measured soma-representation change.
- `<method>_topology.json`: source IDs, target soma, classes reusing a branch.
- `<method>.pt`: `weights_only=True` compatible checkpoint + metadata.
- `configuration.json`: all protocol and class-order settings.

**Ablation caveat:** removing a branch while keeping the original prototype
fixed changes the encoding/prototype consistency. A positive ablation delta
shows causal involvement in that readout, *not* superiority to a newly fitted
no-branch baseline. The matched `dendritic_prototype` method addresses the
latter comparison.

## Reproducibility rules

- Seed each run; class order held constant across methods within a seed.
- No older images are retained by the incremental learner, but compact
  **class prototypes and all recruited branch parameters are stored**.
- Source graph is pretrained once per base architecture using its initial
  training images, then cloned for the method ablations.
- Source classes and novel classes have separate train/validation/query
  splits; **candidate selection sees only present-class training support**.
- New classes are enrolled individually in order, and all seen classes
  compete in one score vector at evaluation.
- A fresh random and a novelty-target-guided version are compared without
  assuming either must win. Both select branches using current supports.
- Point controls include equal input fan-in and near-equal parameter counts;
  no exact FLOP or wall-clock matching is claimed.

See `RESEARCH_PROTOCOL_V21.md` for the three scientific questions, equations,
known confounds and acceptance criteria. `RESULTS_SYNTHETIC_V21.md` contains
actual local *synthetic* evidence, not claims about COIL-100.
