$ErrorActionPreference = 'Stop'
foreach ($seed in 11..15) {
  python -m neuro_weave.assemblies_v21_run --dataset cifar10 --source-classes 6 --novel-classes 4 --increment 2 --initial-shots 4 --new-shots 4 --max-val 12 --image-size 16 --neurons 32 --epochs 30 --steps 20 --seed $seed --data-root data --output "results/cifar10_v21_seed$seed"
  if ($LASTEXITCODE -ne 0) { throw "CIFAR-10 experiment failed for seed $seed" }
}
python -m neuro_weave.aggregate_v21 results/cifar10_v21_seed11/summary.csv results/cifar10_v21_seed12/summary.csv results/cifar10_v21_seed13/summary.csv results/cifar10_v21_seed14/summary.csv results/cifar10_v21_seed15/summary.csv --output results/cifar10_v21_aggregate
if ($LASTEXITCODE -ne 0) { throw 'Aggregation failed' }
