$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# Ablation: no stored old image examples; compare against limited memory.
python -m neuro_weave.continual --dataset coil100 --seed 11 --source-classes 24 --novel-classes 12 --increment 4 --fewshot 4 --max-train 4 --max-val 18 --memory 0 --neurons 32 --branches 4 --fanin 16 --epochs 20 --adapt-epochs 22 --branch-trial-epochs 3 --output results/coil_continual_zero_replay_seed11
exit $LASTEXITCODE
