$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# Harder, separate controlled experiment: fewer training angles per source object.
# Does NOT modify the original COIL pilot or its result directory.
python -m neuro_weave.run --dataset coil100 --seed 11 --source-classes 24 --novel-classes 12 --max-train 4 --max-val 18 --epochs 20 --proposals 12 --max-accept 4 --trial-epochs 4 --episodes 30 --output results/coil_difficult_seed11
exit $LASTEXITCODE
