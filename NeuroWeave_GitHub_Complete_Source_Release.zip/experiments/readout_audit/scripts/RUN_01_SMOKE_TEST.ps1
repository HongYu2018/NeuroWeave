$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m pytest -q tests
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m neuro_weave.run --dataset synthetic --source-classes 6 --novel-classes 4 --epochs 3 --proposals 2 --trial-epochs 1 --episodes 4 --output results/smoke
exit $LASTEXITCODE
