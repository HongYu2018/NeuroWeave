$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m neuro_weave.aggregate results
exit $LASTEXITCODE
