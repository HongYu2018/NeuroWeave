$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m pytest -q tests
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m neuro_weave.continual_v166 --dataset synthetic --source-classes 4 --novel-classes 4 --increment 2 --image-size 8 --neurons 5 --branches 2 --fanin 5 --max-train 4 --max-val 4 --fewshot 2 --memory 0 --epochs 2 --adapt-epochs 2 --branch-trial-epochs 1 --output results/v166_audit_smoke
exit $LASTEXITCODE
