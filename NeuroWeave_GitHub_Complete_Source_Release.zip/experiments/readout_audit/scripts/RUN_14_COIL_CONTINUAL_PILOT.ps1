$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# One evolving 32-soma graph: 24 base objects + 4 + 4 + 4 novel objects.
# COIL downloads automatically if data/coil100/images is missing.
python -m neuro_weave.continual --dataset coil100 --seed 11 --source-classes 24 --novel-classes 12 --increment 4 --fewshot 4 --max-train 4 --max-val 18 --memory 2 --neurons 32 --branches 4 --fanin 16 --initial-synapses 0.55 --epochs 20 --adapt-epochs 22 --branch-trial-epochs 3 --output results/coil_continual_seed11
exit $LASTEXITCODE
