$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m neuro_weave.run --dataset pets --source-classes 20 --novel-classes 12 --max-train 50 --max-val 15 --epochs 16 --proposals 6 --max-accept 4 --trial-epochs 2 --episodes 20 --output results/pets_seed11
exit $LASTEXITCODE
