$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
foreach ($seed in 11,12,13,14,15) {
    python -m neuro_weave.develop --dataset pets --seed $seed --source-classes 20 --novel-classes 12 --max-train 24 --max-val 16 --neurons 32 --initial-synapses 0.55 --epochs 20 --steps 16 --trial-epochs 4 --episodes 30 --output "results/pets_development_seed$seed"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
python -m neuro_weave.aggregate_development --results results --prefix pets_development_seed --output results/pets_development_aggregate
exit $LASTEXITCODE
