$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# Natural images / novel unseen breeds, not cat-to-tiger transfer.
python -m neuro_weave.develop --dataset pets --seed 11 --source-classes 20 --novel-classes 12 --max-train 24 --max-val 16 --neurons 32 --initial-synapses 0.55 --epochs 20 --steps 16 --trial-epochs 4 --episodes 30 --output results/pets_development_seed11
exit $LASTEXITCODE
