$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
foreach ($seed in @(11,17,23,29,31)) {
  python -m neuro_weave.run --dataset coil100 --seed $seed --source-classes 40 --novel-classes 30 --max-train 18 --max-val 18 --epochs 30 --proposals 12 --max-accept 8 --trial-epochs 3 --episodes 50 --output "results/coil_seed$seed"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
