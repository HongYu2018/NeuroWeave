$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
foreach ($seed in @(11, 12, 13, 14, 15)) {
  Write-Host "Running audited seed $seed"
  python -m neuro_weave.continual_v166 --dataset coil100 --seed $seed --source-classes 24 --novel-classes 12 --increment 4 --fewshot 4 --max-train 4 --max-val 18 --memory 0 --neurons 32 --branches 4 --fanin 16 --initial-synapses 0.55 --epochs 20 --adapt-epochs 22 --branch-trial-epochs 3 --output "results/coil_v166_audit_seed$seed"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
python -m neuro_weave.aggregate_continual --results results --prefix coil_v166_audit_seed --output results/coil_v166_audit_aggregate
exit $LASTEXITCODE
