$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m neuro_weave.run --dataset coil100 --download-only
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m neuro_weave.run --dataset pets --download-only
exit $LASTEXITCODE
