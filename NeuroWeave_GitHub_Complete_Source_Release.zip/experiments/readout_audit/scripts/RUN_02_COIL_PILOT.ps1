$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m neuro_weave.run --dataset coil100 --source-classes 24 --novel-classes 12 --max-train 18 --max-val 18 --epochs 14 --proposals 6 --max-accept 4 --trial-epochs 2 --episodes 20 --output results/coil_seed11
exit $LASTEXITCODE
