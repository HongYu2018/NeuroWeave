$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m pytest -q tests
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m neuro_weave.develop --dataset synthetic --source-classes 6 --novel-classes 4 --max-train 12 --max-val 6 --epochs 3 --steps 4 --trial-epochs 1 --episodes 3 --output results/v164_smoke
exit $LASTEXITCODE
