$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
python -m neuro_weave.aggregate_continual --results results --prefix coil_v166_audit_seed --output results/coil_v166_audit_aggregate
exit $LASTEXITCODE
