$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
foreach ($seed in @(11,17,23,29,31)) {
  python -m neuro_weave.run --dataset pets --seed $seed --source-classes 24 --novel-classes 13 --max-train 100 --max-val 30 --epochs 30 --proposals 12 --max-accept 8 --trial-epochs 3 --episodes 50 --output "results/pets_seed$seed"
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
