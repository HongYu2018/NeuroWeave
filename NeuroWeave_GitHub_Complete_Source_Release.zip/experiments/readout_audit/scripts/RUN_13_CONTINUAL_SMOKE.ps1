$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# Test on the Python/PyTorch interpreter active in your current environment.
python -m pytest -q tests
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
python -m neuro_weave.continual --dataset synthetic --source-classes 6 --novel-classes 6 --increment 2 --neurons 8 --branches 3 --fanin 8 --image-size 8 --max-train 4 --max-val 5 --fewshot 4 --memory 2 --epochs 5 --adapt-epochs 6 --branch-trial-epochs 1 --output results/v165_smoke
exit $LASTEXITCODE
