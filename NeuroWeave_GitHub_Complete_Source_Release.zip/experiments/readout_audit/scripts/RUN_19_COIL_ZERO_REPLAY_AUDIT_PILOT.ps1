$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# No old training images; histories are stored as IMPORTANCE STATS or FEATURE PROTOTYPES.
python -m neuro_weave.continual_v166 --dataset coil100 --seed 11 --source-classes 24 --novel-classes 12 --increment 4 --fewshot 4 --max-train 4 --max-val 18 --memory 0 --neurons 32 --branches 4 --fanin 16 --initial-synapses 0.55 --epochs 20 --adapt-epochs 22 --branch-trial-epochs 3 --output results/coil_v166_audit_seed11
exit $LASTEXITCODE
