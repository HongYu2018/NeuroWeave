$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# Independent real-image validation; Oxford Pet breed labels and official query set.
python -m neuro_weave.continual --dataset pets --seed 11 --source-classes 24 --novel-classes 12 --increment 4 --fewshot 4 --max-train 4 --max-val 18 --memory 2 --neurons 32 --branches 4 --fanin 16 --epochs 20 --adapt-epochs 22 --branch-trial-epochs 3 --output results/pets_continual_seed11
exit $LASTEXITCODE
