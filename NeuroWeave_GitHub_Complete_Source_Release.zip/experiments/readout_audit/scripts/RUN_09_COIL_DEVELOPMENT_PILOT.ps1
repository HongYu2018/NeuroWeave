$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
# Developmental mechanism experiment: spatially local sparse starting circuit,
# four types of structural plasticity, untouched held-out source/novel evaluation.
# This does not overwrite your v1.6.3 results.
python -m neuro_weave.develop --dataset coil100 --seed 11 --source-classes 24 --novel-classes 12 --max-train 4 --max-val 18 --neurons 32 --initial-synapses 0.55 --epochs 20 --steps 16 --trial-epochs 4 --episodes 30 --output results/coil_development_seed11
exit $LASTEXITCODE
