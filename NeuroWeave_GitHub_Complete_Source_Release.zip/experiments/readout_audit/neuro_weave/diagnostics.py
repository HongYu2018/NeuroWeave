"""Audit functions: functional ablation, perturbation selectivity, and graph export."""
from __future__ import annotations
import json, math
import torch
import torch.nn.functional as F
from .learning import evaluate


def perturb(x:torch.Tensor,size:int,kind:str)->torch.Tensor:
    z=x.reshape(-1,3,size,size)
    if kind=='brightness':z=torch.clamp(z*1.2,0,1)
    elif kind=='contrast':z=torch.clamp((z-.5)*1.3+.5,0,1)
    elif kind=='red_blue':
        z=z.clone();z[:,0]=torch.clamp(z[:,0]+.12,0,1);z[:,2]=torch.clamp(z[:,2]-.12,0,1)
    elif kind=='blur':z=F.avg_pool2d(F.pad(z,(1,1,1,1),mode='replicate'),3,stride=1)
    else:raise ValueError(kind)
    return z.reshape(x.shape)

@torch.no_grad()
def neuron_diagnostics(model,x,y,size:int):
    model.eval();baseline=evaluate(model,x,y)
    activation=model.graph(x)
    n=activation.shape[-1]
    centered=activation-activation.mean(0,keepdim=True)
    norm=F.normalize(centered.T,p=2,dim=1)
    corr=(norm@norm.T).abs();corr.fill_diagonal_(0)
    sensitivity={}
    for name in ['brightness','contrast','red_blue','blur']:
        altered=model.graph(perturb(x,size,name))
        sensitivity[name]=(altered-activation).abs().mean(0).detach().cpu().tolist()
    rows=[]
    for i,u in enumerate(model.graph.units):
        perf=evaluate_silence(model,x,y,i)
        row={'neuron':i,'depth':model.graph.depths[i],
             'active_synapses':int(u.synapse_mask.sum().item()),
             'incoming_neuron_edges':int((u.source_ids>=model.graph.input_dim).logical_and(u.synapse_mask>0).sum().item()),
             'activation_std':float(activation[:,i].std(unbiased=False).item()),
             'max_correlation_with_other_neuron':float(corr[i].max().item()),
             'ablation_delta_loss':perf['loss']-baseline['loss'],
             'ablation_delta_accuracy':baseline['accuracy']-perf['accuracy']}
        for key,val in sensitivity.items(): row['response_change_'+key]=val[i]
        rows.append(row)
    return rows

@torch.no_grad()
def evaluate_silence(model,x,y,index):
    model.eval(); logits=model(x,silence=index)
    return {'loss':float(F.cross_entropy(logits,y).item()),
            'accuracy':float((logits.argmax(-1)==y).float().mean().item())}


def plot_graph(graph,path):
    """Simplified neuron-to-neuron topology (raw sensory connections omitted)."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    nodes=graph.topology()['nodes'];dims=graph.input_dim
    depths=[node['depth'] for node in nodes]
    layout={}
    for depth in sorted(set(depths)):
        ids=[i for i,d in enumerate(depths) if d==depth]
        for j,i in enumerate(ids):layout[i]=(depth,j-(len(ids)-1)/2)
    fig,ax=plt.subplots(figsize=(max(9,len(set(depths))*1.8),7))
    for i,u in enumerate(graph.units):
        x2,y2=layout[i]
        for src in u.source_ids[u.synapse_mask.bool()].tolist():
            if src<dims:continue
            src_idx=src-dims
            x1,y1=layout[src_idx]
            ax.annotate('',xy=(x2,y2),xytext=(x1,y1),
                        arrowprops=dict(arrowstyle='->',alpha=.23,color='slategray',lw=.65))
    for i,(x,y) in layout.items():
        ax.scatter(x,y,s=170,c='#5D8DB5' if i<32 else '#DE9C54',edgecolors='white',zorder=5)
        ax.text(x,y,str(i),fontsize=6,ha='center',va='center',color='white',zorder=6)
    ax.set_xlabel('Effective graph depth from stochastic wiring (no prescribed hidden stack)')
    ax.set_ylabel('Layout position (no spatial meaning)')
    ax.set_title('NeuroWeave neuronal graph — recurrent links excluded by design')
    ax.grid(alpha=.15);fig.tight_layout();fig.savefig(path,dpi=160);plt.close(fig)
