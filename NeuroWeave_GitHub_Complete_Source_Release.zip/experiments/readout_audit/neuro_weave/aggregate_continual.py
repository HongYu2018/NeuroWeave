"""Summarize paired seed experiments without needing pandas/scipy."""
from __future__ import annotations
import argparse,csv,json,statistics
from pathlib import Path
from collections import defaultdict


def read_rows(parent:Path,prefix:str):
    results=[]
    folders=sorted(p for p in parent.iterdir() if p.is_dir() and p.name.startswith(prefix) and (p/'continual_metrics.csv').is_file())
    for folder in folders:
        info=json.loads((folder/'run_summary.json').read_text(encoding='utf8'))
        with (folder/'continual_metrics.csv').open(newline='',encoding='utf8') as f:
            for row in csv.DictReader(f):
                row['seed']=int(info['seed']); row['folder']=str(folder)
                results.append(row)
    if not folders:raise FileNotFoundError('No completed per-seed incremental experiments matched the supplied prefix')
    seeds=[json.loads((p/'run_summary.json').read_text(encoding='utf8'))['seed'] for p in folders]
    if len(seeds)!=len(set(seeds)):raise ValueError('Repeated seed folders will bias results')
    return results,seeds


def aggregate(rows,seeds,baseline='selective_plasticity'):
    buckets=defaultdict(list)
    for row in rows:
        key=(int(row['stage']),row['method'])
        buckets[key].append(row)
    methods=sorted(set(m for _,m in buckets))
    stages=sorted(set(s for s,_ in buckets))
    if not all((s,m) in buckets and len(buckets[(s,m)])==len(seeds) for s in stages for m in methods):
        raise ValueError('Methods/stages differ between seeds; cannot aggregate paired study')
    metrics=['old_test_accuracy','new_test_accuracy','all_test_accuracy','mean_forgetting','parameters','active_synapses']
    summary=[]
    lookup={(int(r['seed']),int(r['stage']),r['method']):r for r in rows}
    pair=[]
    for (stage,method),bucket in sorted(buckets.items()):
        result={'stage':stage,'method':method,'n_seeds':len(bucket)}
        for key in metrics:
            values=[float(x[key]) for x in bucket if x[key]!='']
            result[key+'_mean']=statistics.mean(values) if values else ''
            result[key+'_sd']=statistics.stdev(values) if len(values)>1 else 0 if values else ''
        summary.append(result)
        if method!=baseline:
            deltas=[]
            for seed in seeds:
                ref=lookup[(seed,stage,baseline)]
                cur=lookup[(seed,stage,method)]
                deltas.append(float(cur['all_test_accuracy'])-float(ref['all_test_accuracy']))
            pair.append({'stage':stage,'method':method,'baseline':baseline,
                         'n_seeds':len(deltas),'accuracy_delta_mean':statistics.mean(deltas),
                         'accuracy_delta_sd':statistics.stdev(deltas) if len(deltas)>1 else 0})
    return summary,pair


def write_csv(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--results',type=Path,default=Path('results'))
    p.add_argument('--prefix',default='coil_continual_seed')
    p.add_argument('--output',type=Path,default=Path('results/coil_continual_aggregate'))
    a=p.parse_args(argv)
    raw,seeds=read_rows(a.results,a.prefix)
    summary,paired=aggregate(raw,seeds)
    a.output.mkdir(parents=True,exist_ok=True)
    write_csv(a.output/'mean_sd.csv',summary)
    write_csv(a.output/'paired_differences.csv',paired)
    (a.output/'aggregate_summary.json').write_text(json.dumps({'seeds':seeds,'n_seeds':len(seeds),'prefix':a.prefix},indent=2))
    print('Aggregated seeds',seeds,'to',a.output)

if __name__=='__main__':main()
