"""Restore exact learned v1.6.4 graph, including grown branches and source IDs."""
from pathlib import Path
import torch
from .model import DendriticGraph,GraphClassifier
from .plasticity import refresh_depths


def load_development_checkpoint(path,device='cpu'):
    """Load only a trusted checkpoint produced by this NeuroWeave package.

    source_ids, synaptic masks and all learned tensors are restored. Returns a
    ready-to-evaluate GraphClassifier. The original class labels are in the
    run_summary.json file alongside the checkpoint.
    """
    saved=torch.load(Path(path),map_location='cpu',weights_only=True)
    opts=saved['configuration']
    d=3*int(opts['image_size'])**2
    graph=DendriticGraph(d,initial_neurons=0,branches=int(opts['branches']),
                         fanin=int(opts['fanin']),kind=saved.get('kind','dendritic'),
                         seed=int(opts['seed']))
    for src in saved['source_ids']:
        graph.add_neuron(source_ids=src)
    model=GraphClassifier(graph,int(opts['source_classes']))
    model.load_state_dict(saved['state_dict'],strict=True)
    refresh_depths(model.graph)
    return model.to(device).eval()
