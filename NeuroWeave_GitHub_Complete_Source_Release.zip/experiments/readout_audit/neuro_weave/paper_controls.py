"""Audited zero-image-replay controls; no novel validation or test image training.

Feature prototypes are a NON-IMAGE MEMORY and must be disclosed as such.
A frozen prototype readout is a diagnostic baseline, not evidence for dendritic
structural plasticity, nor a model that learns novel dendritic capabilities.
"""
from __future__ import annotations
import copy
import torch
import torch.nn.functional as F
from .model import GraphClassifier

class FrozenPrototypeGraph(GraphClassifier):
    """One global class-agnostic prototype readout on a frozen representation.

    Prototypes are saved means of labelled *training* image representations.
    Inference never receives a task ID. Old prototypes and the graph remain frozen.
    """
    def __init__(self,graph,nclasses):
        super().__init__(graph,nclasses)
        self.register_buffer('class_prototypes',torch.empty((0,len(graph.units))))
        for p in self.graph.parameters():p.requires_grad_(False)
        for p in self.head.parameters():p.requires_grad_(False)

    @torch.no_grad()
    def enroll(self,x:torch.Tensor,y:torch.Tensor):
        """Enroll contiguous unseen global class labels from labelled support only."""
        self.eval()
        rep=self.graph(x)
        known=len(self.class_prototypes)
        new=sorted(set(map(int,y.detach().cpu().tolist())))
        if new != list(range(known,known+len(new))):
            raise ValueError('Prototype enrollment must append contiguous new class IDs')
        if known+len(new)>self.head.out_features:
            raise ValueError('Head class count must expand before prototype enrollment')
        protos=torch.stack([rep[y==c].mean(0) for c in new],0)
        self.class_prototypes=torch.cat([self.class_prototypes,protos],0)
        return len(new)

    def forward(self,x,silence=None):
        reps=self.graph(x,silence=silence)
        if len(self.class_prototypes)!=self.head.out_features:
            raise RuntimeError('All prototypes must be enrolled before evaluation')
        # A single, globally shared distance scale avoids old-vs-new per-stage bias.
        return -torch.cdist(reps,self.class_prototypes).square()/max(1,reps.shape[-1])


def current_task_importance(model,x,y,device):
    """Compute diagonal gradient-square statistics on THIS task's labelled training data.

    Stats are retained across tasks, so a subsequent zero-replay experience
    can protect previously learned parameters without accessing old images.
    This is an EWC-like algorithmic baseline, NOT a neuroscience measurement.
    """
    from .continual import importance_from_memory
    groups={int(c):x[y==c].detach() for c in torch.unique(y).tolist()}
    old_requires={n:p.requires_grad for n,p in model.named_parameters()}
    for p in model.parameters():p.requires_grad_(True)
    try:
        stats=importance_from_memory(model,groups,device)
    finally:
        for n,p in model.named_parameters():p.requires_grad_(old_requires[n])
    return {n:v.detach().clone() for n,v in stats.items()}


def consolidate_importance(old:dict,new:dict,retain:float=.9):
    """Online shape-safe importance accumulation as heads and branches grow."""
    if not 0<=retain<=1:raise ValueError('retain should be in [0,1]')
    result={}
    for name,now in new.items():
        value=now.clone()*(1-retain)
        if name in old:
            before=old[name].to(now.device)
            if before.ndim!=now.ndim or any(a>b for a,b in zip(before.shape,now.shape)):
                raise ValueError('Consolidation parameter unexpectedly shrank: '+name)
            selection=tuple(slice(0,s) for s in before.shape)
            value[selection]+=retain*before
        result[name]=value.detach().clamp_(0,10)
    return result


@torch.no_grad()
def old_class_diagnostics(model,previous,stream,old,new,device):
    """Post-training diagnostics on untouched TEST only. Never used to select models."""
    from .continual import collect
    xx,yy=collect(stream.test,old,device)
    model.eval();previous.eval()
    score=model(xx); old_score=previous(xx)
    top_old=(score[:,:len(old)].argmax(1)==yy).float().mean().item()
    full=(score.argmax(1)==yy).float().mean().item()
    predicted_new=(score.argmax(1)>=len(old)).float().mean().item()
    margin=(score[:,:len(old)].amax(1)-score[:,len(old):].amax(1)).mean().item()
    old_score_delta=(score[:,:len(old)]-old_score).abs().mean().item()
    representation_shift=(model.graph(xx)-previous.graph(xx)).square().mean().sqrt().item()
    return {'old_only_accuracy':float(top_old),'old_full_accuracy':float(full),
            'old_predictions_as_new_fraction':float(predicted_new),
            'old_minus_new_mean_margin':float(margin),
            'old_logit_absolute_shift':float(old_score_delta),
            'graph_representation_RMSE':float(representation_shift)}


def zero_replay_growth(model,train_x,train_y,old_model,anchor,importance,
                       lr,batch,epochs,seed,min_gain=.001,penalty=.00001,
                       old_logit_weight=.1,new_floor=.8):
    """Branch-growth trial with NO historical validation or query images.

    Both arms see only the newly labelled training supports. This is optimistic
    proposal selection; final untouched query performance is necessary.
    Old-logit agreement is evaluated only on the same novel support images.
    """
    from .continual import propose_branch,train_stage,neuron_importance
    from .model import parameter_count
    original=model.eval()
    with torch.no_grad():
        current=original(train_x)
        accuracy=(current.argmax(1)==train_y).float().mean().item()
    event={'action':'replay_free_branch_trial','triggered':int(accuracy<new_floor),
           'accepted':0,'selection_uses_historical_images':0,
           'selection_uses_novel_validation_images':0,
           'selection_uses_novel_training_support':1,
           'support_accuracy_before':float(accuracy)}
    if accuracy>=new_floor or epochs<=0:return model,event,0.
    ref=copy.deepcopy(model);candidate=copy.deepcopy(model)
    before=parameter_count(ref)
    proposal=propose_branch(candidate,neuron_importance(importance,len(candidate.graph.units)),seed)
    sec=train_stage(ref,train_x,train_y,epochs,lr,batch,seed+500,
                    prior=old_model,anchor=anchor,importance=importance,anchoring=.5,distillation=.5)
    sec+=train_stage(candidate,train_x,train_y,epochs,lr,batch,seed+500,
                     prior=old_model,anchor=anchor,importance=importance,anchoring=.5,distillation=.5)
    with torch.no_grad():
        old_logits=old_model(train_x)
        n_old=old_model.head.out_features
        def score(m):
            pred=m(train_x)
            ce=F.cross_entropy(pred,train_y)
            preserve=F.mse_loss(pred[:,:n_old],old_logits)
            return float((ce+old_logit_weight*preserve).item())
        ref_score=score(ref);candidate_score=score(candidate)
    gain=ref_score-candidate_score-penalty*(parameter_count(candidate)-before)
    accept=gain>min_gain
    event.update(proposal)
    event.update({'accepted':int(accept),'support_score_reference':ref_score,
                  'support_score_candidate':candidate_score,'net_support_gain':gain,
                  'extra_parameters':parameter_count(candidate)-before})
    return (candidate if accept else ref),event,sec


@torch.no_grad()
def structural_effect_test(model,stream,seen,device,event):
    """Held-out, POST-HOC ablation of one added synapse or dendritic branch.

    Never use these measurements for proposal selection or learning.  Report
    independent model-specific effects, not causal effects of abstract biology.
    """
    from .continual import collect
    action=event.get('action')
    if not int(event.get('accepted',0)):
        return {'test_ablation_applicable':0}
    node=event.get('neuron')
    if node is None or action not in {'recruit','branch','branch_if_needed','replay_free_branch_trial'}:
        return {'test_ablation_applicable':0}
    node=int(node)
    unit=model.graph.units[node]
    xx,yy=collect(stream.test,seen,device)
    model.eval()
    baseline=F.cross_entropy(model(xx),yy)
    pred=model(xx).argmax(1)
    baseline_acc=(pred==yy).float().mean()
    b=int(event.get('branch',len(unit.branch_mask)-1))
    if action=='recruit':
        j=int(event['slot']);saved=unit.synapse_mask[b,j].clone()
        unit.synapse_mask[b,j]=0
    else:
        saved=unit.branch_mask[b].clone()
        unit.branch_mask[b]=0
    try:
        ablated=F.cross_entropy(model(xx),yy)
        abl_acc=(model(xx).argmax(1)==yy).float().mean()
    finally:
        if action=='recruit':unit.synapse_mask[b,j]=saved
        else:unit.branch_mask[b]=saved
    return {'test_ablation_applicable':1,
            'test_loss_increase_when_disabled':float((ablated-baseline).item()),
            'test_accuracy_drop_when_disabled':float((baseline_acc-abl_acc).item())}
