"""Command-line source-learning and novel-class episodic evaluation."""
from __future__ import annotations
import argparse, copy, csv, json, random, time
from collections import defaultdict
from pathlib import Path
import numpy as np
import torch
from .data import prepare_coil,prepare_pets,build_data
from .model import DendriticGraph,GraphClassifier,MLPClassifier,matched_mlp_width,parameter_count
from .learning import fit,evaluate,structural_growth,matched_random_schedule,unconditional_growth,few_shot
from .diagnostics import neuron_diagnostics,plot_graph


def write_csv(path,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,keys);writer.writeheader();writer.writerows(rows)


@torch.no_grad()
def inference_ms_per_image(model,inputs,repeat:int=3):
    model.eval()
    if inputs.is_cuda:torch.cuda.synchronize()
    t0=time.perf_counter()
    for _ in range(repeat):_ = model(inputs)
    if inputs.is_cuda:torch.cuda.synchronize()
    return 1000*(time.perf_counter()-t0)/(repeat*len(inputs))


def run(args):
    torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    torch.set_num_threads(max(1,args.cpu_threads))
    device=torch.device('cuda' if torch.cuda.is_available() and not args.cpu else 'cpu')
    output=Path(args.output); output.mkdir(parents=True,exist_ok=True)
    if args.download_only:
        if args.dataset=='coil100':prepare_coil(args.data_root)
        elif args.dataset=='pets':prepare_pets(args.data_root)
        else:
            prepare_coil(args.data_root);prepare_pets(args.data_root)
        print('Datasets downloaded and verified in',args.data_root)
        return
    dataset=build_data(args.dataset,args.data_root,args.seed,args.image_size,args.source_classes,
                       args.novel_classes,args.max_train,args.max_val)
    x=dataset.source_train_x.to(device);y=dataset.source_train_y.to(device)
    vx=dataset.source_val_x.to(device);vy=dataset.source_val_y.to(device)
    tx=dataset.source_test_x.to(device);ty=dataset.source_test_y.to(device)
    D=x.size(1);classes=args.source_classes
    graph=DendriticGraph(D,args.neurons,args.branches,args.fanin,'dendritic',args.seed)
    base=GraphClassifier(graph,classes).to(device)
    print('Base data:',tuple(x.shape),'source classes:',dataset.source_classes,'novel:',dataset.novel_classes)
    base_time=fit(base,x,y,args.epochs,args.lr,args.batch)
    base_perf=evaluate(base,vx,vy)
    print('Before growth, source-val:',base_perf)
    selected,accepted_events,growth_time=structural_growth(copy.deepcopy(base),x,y,vx,vy,
           args.proposals,args.max_accept,args.trial_epochs,args.lr,args.min_gain,args.parameter_penalty,args.prune)
    accepted=sum(e['accepted'] for e in accepted_events)
    attempted=len(accepted_events)
    random_growth,random_events,random_time=matched_random_schedule(copy.deepcopy(base),x,y,
                         attempted,accepted,args.trial_epochs,args.lr,args.prune,args.seed+51)
    # Unconditional growth is a necessary NON-DEGENERATE control: when accepted=0,
    # neuro_random_matched intentionally adds zero units by design.
    # Here we always add the configured number, irrespective of acceptance.
    unconditional_n=min(args.max_accept,args.proposals)
    random_unconditional,unconditional_events,unconditional_time=unconditional_growth(
        copy.deepcopy(base),x,y,unconditional_n,args.trial_epochs,args.lr,args.prune)
    frozen=copy.deepcopy(base);frozen.graph.freeze_old()
    frozen_time=fit(frozen,x,y,attempted*args.trial_epochs,args.lr,args.batch) if attempted else 0.
    frozen.graph.unfreeze()
    point=GraphClassifier(DendriticGraph(D,args.neurons,args.branches,args.fanin,'point',args.seed),classes).to(device)
    point_time=fit(point,x,y,args.epochs+attempted*args.trial_epochs,args.lr,args.batch)
    # Point-neuron budget control: closest feasible whole-neuron count.
    budget=parameter_count(selected)
    point_candidates=[]
    for n in range(max(2,args.neurons//2),args.neurons*3+1):
        per_neuron=args.branches*args.fanin+1+classes
        estimated=n*per_neuron+classes
        point_candidates.append((abs(estimated-budget),n))
    point_budget_n=min(point_candidates)[1]
    point_budget=GraphClassifier(DendriticGraph(D,point_budget_n,args.branches,args.fanin,'point',args.seed),classes).to(device)
    point_budget_time=fit(point_budget,x,y,args.epochs+attempted*args.trial_epochs,args.lr,args.batch)
    hidden=matched_mlp_width(D,classes,parameter_count(selected))
    mlp_matched=MLPClassifier(D,classes,hidden).to(device)
    mlp_128=MLPClassifier(D,classes,128).to(device)
    mt=fit(mlp_matched,x,y,args.epochs+attempted*args.trial_epochs,args.lr,args.batch)
    mlpt=fit(mlp_128,x,y,args.epochs+attempted*args.trial_epochs,args.lr,args.batch)
    models={'neuro_selected':selected,'neuro_random_matched':random_growth,
            'neuro_random_unconditional':random_unconditional,
            'neuro_fixed':frozen,'point_fixed':point,'point_budget_matched':point_budget,'mlp_matched':mlp_matched,'mlp_128':mlp_128}
    training_times={'neuro_selected':base_time+growth_time,'neuro_random_matched':base_time+random_time,
                    'neuro_random_unconditional':base_time+unconditional_time,
                    'neuro_fixed':base_time+frozen_time,'point_fixed':point_time,
                    'point_budget_matched':point_budget_time,'mlp_matched':mt,'mlp_128':mlpt}
    source_summary=[];few_rows=[]
    for name,model in models.items():
        perf=evaluate(model,vx,vy)
        heldout=evaluate(model,tx,ty)
        params=parameter_count(model)
        source_summary.append({'method':name,'seed':args.seed,'val_accuracy':perf['accuracy'],
                               'val_loss':perf['loss'],'source_test_accuracy':heldout['accuracy'],
                               'source_test_loss':heldout['loss'],'parameters':params,
                               'inference_ms_per_image':inference_ms_per_image(model,tx),'source_train_seconds':training_times[name],
                               'neurons':len(model.graph.units) if isinstance(model,GraphClassifier) else hidden if name=='mlp_matched' else 128,
                               'max_graph_depth':max(model.graph.depths) if isinstance(model,GraphClassifier) else 1,
                               'active_synapses':model.graph.topology()['alive_synapses'] if isinstance(model,GraphClassifier) else None})
        episodes=few_shot(model,dataset.novel,args.shots,args.ways,args.episodes,args.seed+900,device)
        for row in episodes: row.update({'method':name,'seed':args.seed})
        few_rows.extend(episodes)
        print(name, 'val_acc',round(perf['accuracy'],3),'params',params,
              'fewshot', [(k,round(float(np.mean([r['accuracy'] for r in episodes if r['shot']==k])),3)) for k in args.shots])
    write_csv(output/'source_validation.csv',source_summary)
    write_csv(output/'fewshot_episodes.csv',few_rows)
    write_csv(output/'growth_proposals.csv',accepted_events)
    write_csv(output/'random_growth_control.csv',random_events)
    write_csv(output/'random_unconditional_growth.csv',unconditional_events)
    diagnostics=neuron_diagnostics(selected,vx,vy,args.image_size)
    write_csv(output/'neuron_diagnostics.csv',diagnostics)
    with (output/'graph_topology.json').open('w') as f:json.dump(selected.graph.topology(),f,indent=2)
    if not args.no_plot:
        try:plot_graph(selected.graph,output/'graph_topology.png')
        except ImportError:print('matplotlib absent: skipped topology plot')
    summary={'dataset':args.dataset,'seed':args.seed,'device':str(device),
        'source_classes':dataset.source_classes,'novel_classes':dataset.novel_classes,
        'source_train_n':len(x),'source_val_n':len(vx),'source_test_n':len(tx),
        'episodes_per_shot':args.episodes,
        'growth_attempts':attempted,'growth_accepted':accepted,
        'unconditional_random_additions':len(unconditional_events),
        'baseline_parameters':parameter_count(base),'grown_parameters':parameter_count(selected),
        'max_depth':max(selected.graph.depths),'shots':args.shots,
        'notes':['Novel-class query and source-test labels were never used for growth or optimisation.',
                 'Matched random growth adds exactly as many neurons as selected growth; if accepted=0 it is a zero-growth control.',
                 'Unconditional random growth adds neurons regardless of selected acceptance and uses its own training budget.',
                 'Graph has an emergent DAG depth but no prescribed hidden layer stack.',
                 'These experiments test computational learning, not biological equivalence.',
                 'Source validation is repeatedly consulted for structural selection; confirm on untouched novel classes.']}
    (output/'run_summary.json').write_text(json.dumps(summary,indent=2))
    torch.save({'model':selected.state_dict(),'topology':selected.graph.topology(),
                'configuration':vars(args)}, output/'selected_weights.pt')
    print('Saved results to',output)


def parse_args(argv=None):
    p=argparse.ArgumentParser(description='NeuroWeave 1.6 mechanism discovery + few-shot evaluation')
    p.add_argument('--dataset',choices=['synthetic','coil100','pets'],default='synthetic')
    p.add_argument('--data-root',type=Path,default=Path('data'))
    p.add_argument('--output',default='results/smoke')
    p.add_argument('--download-only',action='store_true')
    p.add_argument('--cpu',action='store_true');p.add_argument('--cpu-threads',type=int,default=2)
    p.add_argument('--seed',type=int,default=11);p.add_argument('--neurons',type=int,default=32)
    p.add_argument('--branches',type=int,default=4);p.add_argument('--fanin',type=int,default=16)
    p.add_argument('--image-size',type=int,default=16);p.add_argument('--source-classes',type=int,default=6)
    p.add_argument('--novel-classes',type=int,default=4);p.add_argument('--max-train',type=int,default=24)
    p.add_argument('--max-val',type=int,default=12);p.add_argument('--epochs',type=int,default=8)
    p.add_argument('--lr',type=float,default=.012);p.add_argument('--batch',type=int,default=128)
    p.add_argument('--proposals',type=int,default=4);p.add_argument('--max-accept',type=int,default=3)
    p.add_argument('--trial-epochs',type=int,default=2);p.add_argument('--min-gain',type=float,default=.001)
    p.add_argument('--parameter-penalty',type=float,default=0.0);p.add_argument('--prune',type=float,default=.1)
    p.add_argument('--ways',type=int,default=3);p.add_argument('--shots',type=int,nargs='+',default=[1,5,10])
    p.add_argument('--episodes',type=int,default=10);p.add_argument('--no-plot',action='store_true')
    return p.parse_args(argv)

if __name__=='__main__':run(parse_args())
