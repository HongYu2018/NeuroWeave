"""CLI for NeuroWeave v1.6.4 developmental architecture experiment.

Existing v1.6.3 runner is retained as neuro_weave.run for comparison.
"""
from __future__ import annotations
import argparse,copy,csv,json,random,time
from pathlib import Path
import numpy as np
import torch
from .data import build_data, prepare_coil, prepare_pets
from .model import DendriticGraph,GraphClassifier,MLPClassifier,matched_mlp_width,parameter_count
from .learning import fit,evaluate,few_shot
from .plasticity import development_selected,development_random,branch_dependency,refresh_depths
from .diagnostics import neuron_diagnostics,plot_graph


def csv_write(path,rows,empty_headers=None):
    if not rows:
        if empty_headers:Path(path).write_text(','.join(empty_headers)+'\n',encoding='utf8')
        return
    headers=list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=headers);w.writeheader();w.writerows(rows)


def run(args):
    random.seed(args.seed);np.random.seed(args.seed);torch.manual_seed(args.seed)
    torch.set_num_threads(max(1,args.cpu_threads))
    device=torch.device('cuda' if torch.cuda.is_available() and not args.cpu else 'cpu')
    output=Path(args.output);output.mkdir(parents=True,exist_ok=True)
    if args.download_only:
        if args.dataset=='coil100':prepare_coil(args.data_root)
        elif args.dataset=='pets':prepare_pets(args.data_root)
        else:
            prepare_coil(args.data_root); prepare_pets(args.data_root)
        return
    bundle=build_data(args.dataset,args.data_root,args.seed,args.image_size,
                      args.source_classes,args.novel_classes,args.max_train,args.max_val)
    x=bundle.source_train_x.to(device);y=bundle.source_train_y.to(device)
    vx=bundle.source_val_x.to(device);vy=bundle.source_val_y.to(device)
    tx=bundle.source_test_x.to(device);ty=bundle.source_test_y.to(device)
    graph=DendriticGraph(x.shape[1],args.neurons,args.branches,args.fanin,'dendritic',args.seed,
                        initial_wiring_probability=0.,initial_synapse_fraction=args.initial_synapses,
                        spatial_sensory=not args.global_sensory)
    base=GraphClassifier(graph,args.source_classes).to(device)
    initial_graph=base.graph.topology()
    (output/'topology_before.json').write_text(json.dumps(initial_graph,indent=2))
    print('Device',device,'source train',len(x),'source val',len(vx),'source test',len(tx))
    print('Initial graph',len(graph.units),'units; depth',max(graph.depths),'active synapses',initial_graph['alive_synapses'])
    t0=time.perf_counter()
    fit(base,x,y,args.epochs,args.lr,args.batch)
    initial_seconds=time.perf_counter()-t0
    initial_val=evaluate(base,vx,vy)
    print('Before development:',initial_val)
    selected,decisions,selected_time=development_selected(base,x,y,vx,vy,
          steps=args.steps,trial_epochs=args.trial_epochs,lr=args.lr,
          min_gain=args.min_gain,penalty=args.parameter_penalty,seed=args.seed,prune=args.prune)
    # Independent random wiring, with the same structural action *types* and
    # opportunities; no source-val information enters random development.
    random_model,random_events,random_time=development_random(base,x,y,args.steps,
          args.trial_epochs,args.lr,seed=args.seed+31,prune=args.prune)
    # Also compare with random changes restricted to types accepted by selection:
    accepted_schedule=[e['action'] for e in decisions if e.get('accepted')]
    random_matched,matched_events,matched_time=development_random(base,x,y,
          len(accepted_schedule),args.trial_epochs,args.lr,seed=args.seed+97,
          prune=args.prune,action_schedule=accepted_schedule)
    frozen=copy.deepcopy(base)
    frozen.graph.freeze_old()
    t0=time.perf_counter()
    if args.steps: fit(frozen,x,y,args.steps*args.trial_epochs,args.lr,args.batch)
    frozen_time=time.perf_counter()-t0
    frozen.graph.unfreeze()
    # Stronger unchanged-topology baseline: permit all original graph weights
    # to continue learning rather than forcing only a new decision head.
    finetune=copy.deepcopy(base)
    finetune.graph.unfreeze()
    t0=time.perf_counter()
    if args.steps:fit(finetune,x,y,args.steps*args.trial_epochs,args.lr,args.batch)
    finetune_time=time.perf_counter()-t0
    point=GraphClassifier(DendriticGraph(x.shape[1],args.neurons,args.branches,args.fanin,
            'point',args.seed,initial_wiring_probability=0.,
            initial_synapse_fraction=args.initial_synapses,
            spatial_sensory=not args.global_sensory),args.source_classes).to(device)
    t0=time.perf_counter()
    fit(point,x,y,args.epochs+args.steps*args.trial_epochs,args.lr,args.batch)
    point_seconds=time.perf_counter()-t0
    target=parameter_count(selected)
    candidates=[]
    for n in range(1, max(args.neurons*4,120)+1):
        # Conventional point graph has k*fanin weights, one soma bias + head.
        estimated=n*(args.branches*args.fanin+1+args.source_classes)+args.source_classes
        candidates.append((abs(estimated-target),n))
    point_size=min(candidates)[1]
    point_matched=GraphClassifier(DendriticGraph(x.shape[1],point_size,args.branches,args.fanin,
                      'point',args.seed,initial_wiring_probability=0.,
                      initial_synapse_fraction=args.initial_synapses,
                      spatial_sensory=not args.global_sensory),args.source_classes).to(device)
    t0=time.perf_counter()
    fit(point_matched,x,y,args.epochs+args.steps*args.trial_epochs,args.lr,args.batch)
    point_matched_seconds=time.perf_counter()-t0
    width=matched_mlp_width(x.shape[1],args.source_classes,target)
    mlp=MLPClassifier(x.shape[1],args.source_classes,width).to(device)
    t0=time.perf_counter()
    fit(mlp,x,y,args.epochs+args.steps*args.trial_epochs,args.lr,args.batch)
    mlp_seconds=time.perf_counter()-t0
    methods={'development_selected':selected,'development_random_unconditional':random_model,
             'development_random_accept_matched':random_matched,'development_fixed':frozen,'development_finetune_no_growth':finetune,
             'point_fixed':point,'point_budget_matched':point_matched,'mlp_budget_matched':mlp}
    times={'development_selected':initial_seconds+selected_time,
           'development_random_unconditional':initial_seconds+random_time,
           'development_random_accept_matched':initial_seconds+matched_time,
           'development_fixed':initial_seconds+frozen_time,
           'development_finetune_no_growth':initial_seconds+finetune_time,
           'point_fixed':point_seconds,
           'point_budget_matched':point_matched_seconds,'mlp_budget_matched':mlp_seconds}
    source_rows=[];episode_rows=[]
    for name,model in methods.items():
        val=evaluate(model,vx,vy);test=evaluate(model,tx,ty)
        topo=model.graph.topology() if isinstance(model,GraphClassifier) else None
        source_rows.append({'method':name,'seed':args.seed,'val_loss':val['loss'],
                 'val_accuracy':val['accuracy'],'source_test_loss':test['loss'],
                 'source_test_accuracy':test['accuracy'],'parameters':parameter_count(model),
                 'neurons':len(model.graph.units) if topo else width,
                 'max_depth':max(model.graph.depths) if topo else 1,
                 'synapses':topo['alive_synapses'] if topo else '',
                 'training_and_search_seconds':times[name]})
        episodes=few_shot(model,bundle.novel,args.shots,args.ways,args.episodes,args.seed+900,device)
        for r in episodes:r.update({'method':name,'seed':args.seed})
        episode_rows.extend(episodes)
        print(name,'test_accuracy',round(test['accuracy'],4),'params',parameter_count(model),
              'fewshot',[(k,round(float(np.mean([r['accuracy'] for r in episodes if r['shot']==k])),3))
                          for k in args.shots])
    csv_write(output/'source_validation.csv',source_rows)
    csv_write(output/'fewshot_episodes.csv',episode_rows)
    csv_write(output/'development_decisions.csv',decisions)
    csv_write(output/'random_unconditional.csv',random_events)
    csv_write(output/'random_accepted_matched.csv',matched_events,
              empty_headers=['step','accepted','action','target','branch','slot','depth'])
    with (output/'topology_after.json').open('w') as f:json.dump(selected.graph.topology(),f,indent=2)
    last_ids=list(dict.fromkeys([e['target'] for e in decisions if e.get('accepted')]))
    diagnostic_ids=list(dict.fromkeys(last_ids+list(range(min(4,args.neurons)))))[:args.diagnostic_units]
    bdiag=branch_dependency(selected,tx,ty,diagnostic_ids,max_units=args.diagnostic_units)
    csv_write(output/'branch_dependency.csv',bdiag)
    ndiag=neuron_diagnostics(selected,vx,vy,args.image_size)
    csv_write(output/'neuron_diagnostics.csv',ndiag)
    if not args.no_plot:
        try:
            plot_graph(selected.graph,output/'topology_after.png')
        except ImportError: print('matplotlib unavailable: plot skipped')
    summary={'version':'1.6.4','dataset':args.dataset,'seed':args.seed,'device':str(device),
        'source_classes':bundle.source_classes,'novel_classes':bundle.novel_classes,
        'source_train_n':len(x),'source_val_n':len(vx),'source_test_n':len(tx),
        'initial_neurons':args.neurons,'initial_graph_depth':initial_graph['max_depth'],
        'final_neurons':len(selected.graph.units),'final_graph_depth':max(selected.graph.depths),
        'initial_synapses':initial_graph['alive_synapses'],
        'final_synapses':selected.graph.topology()['alive_synapses'],
        'accepted_proposals':sum(int(e.get('accepted',0)) for e in decisions),
        'development_attempts':len(decisions),'initial_validation':initial_val,
        'random_control_independent_rng':True,'episodes_per_shot':args.episodes,
        'limitations':['Post hoc branch ablation does not prove causal contribution to learning.',
         'Dendritic weights learned by Adam; local biological plasticity is not implemented.',
         'No recurrent connections and initial sensory organisation is spatially constrained.',
         'Repeated validation selection can overfit; test held-out labels remain unused for development.',
         'Matched random acceptance control matches action type/count, not exact computational search cost.',
         'One seed/short pilot cannot establish biological emergence or a statistically reliable advantage.']}
    (output/'run_summary.json').write_text(json.dumps(summary,indent=2))
    torch.save({'state_dict':selected.state_dict(),
                'source_ids':[u.source_ids.cpu().tolist() for u in selected.graph.units],
                'synapse_masks':[u.synapse_mask.cpu().tolist() for u in selected.graph.units],
                'kind':selected.graph.kind,
                'configuration':{k:str(v) if isinstance(v,Path) else v
                                  for k,v in vars(args).items()}},output/'selected_weights.pt')
    print('Saved results to',output)


def parse_args(argv=None):
    p=argparse.ArgumentParser(description='NeuroWeave v1.6.4 development mechanisms')
    p.add_argument('--dataset',choices=['synthetic','coil100','pets'],default='synthetic')
    p.add_argument('--data-root',type=Path,default=Path('data'))
    p.add_argument('--output',default='results/v164_smoke')
    p.add_argument('--download-only',action='store_true')
    p.add_argument('--cpu',action='store_true')
    p.add_argument('--cpu-threads',type=int,default=2)
    p.add_argument('--seed',type=int,default=11)
    p.add_argument('--neurons',type=int,default=32)
    p.add_argument('--branches',type=int,default=4)
    p.add_argument('--fanin',type=int,default=16)
    p.add_argument('--initial-synapses',type=float,default=.55)
    p.add_argument('--global-sensory',action='store_true',help='Disable local input sampling')
    p.add_argument('--image-size',type=int,default=16)
    p.add_argument('--source-classes',type=int,default=6)
    p.add_argument('--novel-classes',type=int,default=4)
    p.add_argument('--max-train',type=int,default=24)
    p.add_argument('--max-val',type=int,default=12)
    p.add_argument('--epochs',type=int,default=8)
    p.add_argument('--lr',type=float,default=.012)
    p.add_argument('--batch',type=int,default=128)
    p.add_argument('--steps',type=int,default=8)
    p.add_argument('--trial-epochs',type=int,default=2)
    p.add_argument('--min-gain',type=float,default=.001)
    p.add_argument('--parameter-penalty',type=float,default=0.)
    p.add_argument('--prune',type=float,default=.1)
    p.add_argument('--ways',type=int,default=3)
    p.add_argument('--shots',type=int,nargs='+',default=[1,5,10])
    p.add_argument('--episodes',type=int,default=10)
    p.add_argument('--diagnostic-units',type=int,default=8)
    p.add_argument('--no-plot',action='store_true')
    return p.parse_args(argv)

if __name__=='__main__':run(parse_args())
