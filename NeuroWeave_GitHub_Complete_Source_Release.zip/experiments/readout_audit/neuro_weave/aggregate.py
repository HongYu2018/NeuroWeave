"""Aggregate five seeds correctly: episodes are repeated measures within a seed."""
from __future__ import annotations
import argparse,csv, math
from collections import defaultdict
from pathlib import Path
import numpy as np


def read_rows(paths):
    for path in paths:
        with Path(path).open(newline='') as f:
            yield from csv.DictReader(f)


def save(path,rows):
    if not rows:return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)


def aggregate(root:Path):
    files=list(root.glob('*/fewshot_episodes.csv'))
    if not files:raise ValueError('No seed folders found')
    seed_values=defaultdict(list)
    for row in read_rows(files):
        key=(row['method'],int(row['shot']),int(row['seed']))
        seed_values[key].append(float(row['accuracy']))
    by_seed=[{'method':m,'shot':k,'seed':s,'episodes':len(scores),'mean_accuracy':float(np.mean(scores))}
            for (m,k,s),scores in sorted(seed_values.items())]
    save(root/'fewshot_by_seed.csv',by_seed)
    grouped=defaultdict(dict)
    for row in by_seed:grouped[(row['method'],row['shot'])][row['seed']]=row['mean_accuracy']
    # Student 95% t-critical for n=2..10, no SciPy dependency.
    tcrit={2:12.706,3:4.303,4:3.182,5:2.776,6:2.571,7:2.447,8:2.365,9:2.306,10:2.262}
    results=[]
    for (method,shot),seed_scores in sorted(grouped.items()):
        values=np.array(list(seed_scores.values()));n=len(values)
        mean=float(values.mean());sd=float(values.std(ddof=1)) if n>1 else float('nan')
        ci=(tcrit.get(n,float('nan'))*sd/math.sqrt(n)) if n>1 else float('nan')
        results.append({'method':method,'shot':shot,'seeds':n,'mean_accuracy':mean,
                        'sd_across_seeds':sd,'ci95_low':mean-ci,'ci95_high':mean+ci})
    save(root/'fewshot_summary.csv',results)
    paired=[]
    target='neuro_selected'
    for (method,shot),seed_scores in sorted(grouped.items()):
        if method==target:continue
        old=grouped.get((target,shot),{})
        common=sorted(set(seed_scores)&set(old));delta=np.array([old[s]-seed_scores[s] for s in common]);n=len(delta)
        mean=float(delta.mean()) if n else float('nan')
        sd=float(delta.std(ddof=1)) if n>1 else float('nan')
        ci=tcrit.get(n,float('nan'))*sd/math.sqrt(n) if n>1 else float('nan')
        paired.append({'comparison':f'{target} minus {method}','shot':shot,'paired_seeds':n,
                       'mean_delta':mean,'ci95_low':mean-ci,'ci95_high':mean+ci})
    save(root/'fewshot_paired_differences.csv',paired)
    print('Wrote seed-level summaries and paired differences under',root)
    print('Warning: short pilots and n<=5 are exploratory; do not claim statistical significance.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path,default=Path('results'),nargs='?')
    aggregate(p.parse_args().root)
