"""NeuroWeave 1.6.6: audit-controlled class incremental learning.

No task IDs supplied to inference. A single expanding head covers all observed
classes; no previous model is reset during increments. Validation is used only
for optional branch acceptance. Query/test images never enter training/selection.
"""
from __future__ import annotations
import argparse
import copy
import csv
import json
import random
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from .data import build_data
from .model import DendriticGraph, GraphClassifier, parameter_count
from .plasticity import choose_source, refresh_depths
from .paper_controls import (FrozenPrototypeGraph, current_task_importance,
    consolidate_importance, old_class_diagnostics, zero_replay_growth, structural_effect_test)


@dataclass
class Stream:
    train: dict[int, torch.Tensor]
    val: dict[int, torch.Tensor]
    test: dict[int, torch.Tensor]
    names: list[int]
    stage_groups: list[list[int]]
    input_dim: int


def build_stream(bundle, increment:int=4, shots:int=4) -> Stream:
    """Independent train/val/query splits with globally stable class IDs."""
    if increment < 1 or shots < 1:
        raise ValueError('increment and shots must be positive')
    source_count=len(bundle.source_classes)
    names=list(bundle.source_classes)+list(bundle.novel_classes)
    if len(set(names)) != len(names):
        raise ValueError('Duplicate original category IDs')
    train={};val={};test={}
    for i in range(source_count):
        mask=bundle.source_train_y==i
        train[i]=bundle.source_train_x[mask].clone()
        val[i]=bundle.source_val_x[bundle.source_val_y==i].clone()
        test[i]=bundle.source_test_x[bundle.source_test_y==i].clone()
    for j,cat in enumerate(bundle.novel_classes):
        idx=source_count+j
        bank=bundle.novel[cat]
        if 'validation' not in bank:
            raise ValueError('Novel-class validation data are required; update data.py')
        train[idx]=bank['support'][:shots].clone()
        val[idx]=bank['validation'].clone()
        test[idx]=bank['query'].clone()
    if any(len(train[i])<1 or len(val[i])<1 or len(test[i])<1 for i in range(len(names))):
        raise ValueError('Every category must have disjoint train/val/query examples')
    stages=[list(range(source_count))]
    stages += [list(range(source_count+i,min(len(names),source_count+i+increment)))
               for i in range(0,len(bundle.novel_classes),increment)]
    return Stream(train,val,test,names,stages,int(bundle.source_train_x.shape[1]))


def collect(part:dict[int,torch.Tensor], labels:list[int], device):
    if not labels:
        raise ValueError('Empty class list')
    return (torch.cat([part[i] for i in labels]).to(device),
            torch.cat([torch.full((len(part[i]),),i,dtype=torch.long) for i in labels]).to(device))


def replay_memory(stream:Stream, seen:list[int], per_class:int, seed:int):
    """Fixed labelled exemplars from training only; never validation or query."""
    if per_class<0: raise ValueError('negative replay budget')
    memory={}
    for c in seen:
        pool=stream.train[c]
        # Fixed class-local RNG ensures the very same exemplars across methods.
        chosen=random.Random(seed+9107*c).sample(range(len(pool)),min(per_class,len(pool)))
        memory[c]=pool[chosen].clone()
    return memory


def expand_classes(model:GraphClassifier,new_total:int, bias_offset:float=0.2,
                   support_x=None, support_y=None):
    """Expand global output labels without altering logits for old categories.

    With novel training support, initialise new rows from representations of
    *labelled support only*. No val/query images, no prior task-ID at inference.
    """
    old=model.head
    if new_total<=old.out_features:raise ValueError('Class count must grow')
    new=nn.Linear(old.in_features,new_total).to(device=old.weight.device,dtype=old.weight.dtype)
    with torch.no_grad():
        new.weight[:old.out_features].copy_(old.weight)
        new.bias[:old.out_features].copy_(old.bias)
        new.weight[old.out_features:].zero_()
        new.bias[old.out_features:].fill_(float(old.bias.mean().item())-bias_offset)
        if (support_x is None) != (support_y is None):
            raise ValueError('Support features and labels must both be supplied')
        if support_x is not None:
            was_training=model.training
            model.eval()
            reps=model.graph(support_x)
            model.train(was_training)
            center=reps.mean(0)
            scale=old.weight.norm(dim=1).mean().clamp_min(.1)
            for c in range(old.out_features,new_total):
                group=reps[support_y==c]
                if not len(group):raise ValueError(f'No support examples for new class {c}')
                direction=group.mean(0)-center
                norm=direction.norm()
                if norm>1e-7:
                    new.weight[c].copy_(scale*direction/norm)
    model.head=new
    return model


def importance_from_memory(model,bank:dict[int,torch.Tensor],device):
    """Approximate gradient-squared importance using ONLY historical train exemplars.

    Classwise gradients avoid cancellation across classes. Used for selective
    structural exploration and parameter anchoring; not biological Fisher data.
    """
    model.eval()
    values={n:torch.zeros_like(p) for n,p in model.named_parameters()}
    if not bank:return values
    for c,x in sorted(bank.items()):
        if not len(x):continue
        model.zero_grad(set_to_none=True)
        logits=model(x.to(device))
        target=torch.full((len(x),),c,dtype=torch.long,device=device)
        F.cross_entropy(logits,target).backward()
        for n,p in model.named_parameters():
            if p.grad is not None:values[n].add_(p.grad.detach().square())
    model.zero_grad(set_to_none=True)
    scale=max(1,len(bank))
    # A shared scale preserves relative importance BETWEEN neurons.
    avg=torch.stack([v.mean() for v in values.values()]).mean().clamp_min(1e-8)
    for n in values:
        values[n]=((values[n]/scale)/(avg/scale)).clamp(0,10).detach()
    return values


def neuron_importance(fisher:dict[str,torch.Tensor],number:int):
    return [sum(float(v.mean().item()) for k,v in fisher.items()
                if k.startswith(f'graph.units.{i}.')) for i in range(number)]


def anchored_penalty(model,anchor,importance):
    if anchor is None:return next(model.parameters()).new_zeros(())
    costs=[]
    for n,p in model.named_parameters():
        if n not in anchor: continue
        a=anchor[n];f=importance[n]
        # Expanded head, branches or neurons: only pre-existing parameters anchored.
        if p.ndim !=a.ndim or any(new<old for new,old in zip(p.shape,a.shape)):
            raise RuntimeError(f'Unexpected parameter shrinkage: {n}')
        prefix=tuple(slice(0,dim) for dim in a.shape)
        costs.append((f*(p[prefix]-a).square()).mean())
    return torch.stack(costs).mean() if costs else next(model.parameters()).new_zeros(())


def train_stage(model,x,y,epochs,lr,batch,seed,prior=None,anchor=None,
                importance=None,anchoring=0.0,distillation=0.0,absolute_logit_weight=0.0):
    """Deterministic batches; class-balanced CE. Rebuild optimizer after structural changes."""
    if epochs<0 or batch<1:raise ValueError('Invalid training budget')
    if not len(x):raise ValueError('Empty training set')
    if prior is not None:prior.eval()
    counts=torch.bincount(y,minlength=model.head.out_features).clamp_min(1)
    class_weight=1.0/counts.float()
    class_weight=class_weight/class_weight.max()
    params=[p for p in model.parameters() if p.requires_grad]
    if not params:raise ValueError('No trainable parameters')
    opt=torch.optim.Adam(params,lr=lr)
    # Save and restore RNG state, including CUDA generator, to match control batches.
    cuda_devices=[x.device.index if x.device.index is not None else torch.cuda.current_device()] if x.is_cuda else []
    if x.is_cuda:torch.cuda.synchronize(x.device)
    start=time.perf_counter()
    with torch.random.fork_rng(devices=cuda_devices):
        torch.manual_seed(seed)
        model.train()
        for epoch in range(epochs):
            order=torch.randperm(len(x),device=x.device)
            for ids in order.split(batch):
                logits=model(x[ids]);yb=y[ids]
                ce=F.cross_entropy(logits,yb,weight=class_weight)
                loss=ce
                if prior is not None and distillation>0:
                    old_classes=prior.head.out_features
                    with torch.no_grad(): old=prior(x[ids])
                    temp=2.0
                    dist=F.kl_div(F.log_softmax(logits[:,:old_classes]/temp,dim=-1),
                                  F.softmax(old/temp,dim=-1),reduction='batchmean')*(temp*temp)
                    loss=loss+distillation*dist
                if prior is not None and absolute_logit_weight>0:
                    with torch.no_grad(): old_abs=prior(x[ids])
                    # Preserve old logit magnitude on novel inputs, not just the
                    # old-class conditional softmax distribution.
                    loss=loss+absolute_logit_weight*F.mse_loss(logits[:,:prior.head.out_features],old_abs)
                if anchor is not None and anchoring>0:
                    loss=loss+anchoring*anchored_penalty(model,anchor,importance)
                opt.zero_grad(set_to_none=True)
                loss.backward();opt.step()
    if x.is_cuda:torch.cuda.synchronize(x.device)
    return time.perf_counter()-start


@torch.no_grad()
def measure(model,stream,seen,device,split='test'):
    model.eval()
    if not seen or min(seen)<0 or max(seen)>=model.head.out_features:
        raise ValueError('Requested class outside current classifier head')
    x,y=collect(getattr(stream,split),seen,device)
    pred=model(x).argmax(dim=-1)
    good=(pred==y)
    return {'accuracy':float(good.float().mean().item()),
            'per_class':{str(c):float(good[y==c].float().mean().item()) for c in seen},
            'total':int(len(y))}


def val_score(model,stream,old,new,device):
    model.eval()
    with torch.no_grad():
        xx,yy=collect(stream.val,old+new,device)
        loss=float(F.cross_entropy(model(xx),yy).item())
        new_accuracy=measure(model,stream,new,device,'val')['accuracy'] if new else 1.
        old_accuracy=measure(model,stream,old,device,'val')['accuracy'] if old else 1.
    return {'loss':loss,'new_accuracy':new_accuracy,'old_accuracy':old_accuracy}


def strict_selection_score(model,stream,old,new,device):
    """Novel labels used here are ONLY the labelled training support.

    Old-class validation is disjoint; novel support loss is optimistic, so the
    final comparison must be made on the never-accessed novel query split.
    """
    model.eval()
    old_x,old_y=collect(stream.val,old,device)
    new_x,new_y=collect(stream.train,new,device)
    with torch.no_grad():
        old_logits=model(old_x);new_logits=model(new_x)
        old_acc=float((old_logits.argmax(1)==old_y).float().mean().item())
        new_acc=float((new_logits.argmax(1)==new_y).float().mean().item())
        score=float((F.cross_entropy(old_logits,old_y)+F.cross_entropy(new_logits,new_y)).item()/2)
    return {'loss':score,'new_accuracy':new_acc,'old_accuracy':old_acc}


def recruit_constrained(model:GraphClassifier, importance:list[float], seed:int, count:int=2):
    """Stochastic synapse recruitment in less important existing neurons.

    Parameter count stays fixed. No validation-guided proposal ranking.
    """
    rng=random.Random(seed)
    ranks=sorted(range(len(model.graph.units)),key=lambda i:importance[i])
    eligible=ranks[:max(1,len(ranks)//2)]
    events=[]
    for attempt in range(count):
        targets=[i for i in eligible if (model.graph.units[i].synapse_mask==0).any().item()]
        if not targets:break
        idx=rng.choice(targets);unit=model.graph.units[idx]
        coords=torch.nonzero(unit.synapse_mask==0,as_tuple=False).tolist()
        b,j=rng.choice(coords)
        old=int(unit.source_ids[b,j].item())
        src=choose_source(model.graph,idx,rng,prefer_neuron=True)
        with torch.no_grad():
            unit.source_ids[b,j]=src;unit.synapse_mask[b,j]=1
            unit.weights[b,j]=(.02 if rng.random()<.5 else -.02)
        events.append({'action':'recruit','neuron':idx,'branch':b,'slot':j,
                       'old_source':old,'new_source':src})
    refresh_depths(model.graph)
    return events


def propose_branch(model:GraphClassifier,importance:list[float],seed:int):
    """Add a nonlinear branch to an existing neuron, keeping soma count fixed."""
    rng=random.Random(seed)
    ranked=sorted(range(len(importance)),key=lambda k:importance[k])
    target=rng.choice(ranked[:max(1,len(ranked)//2)])
    srcs=[choose_source(model.graph,target,rng,prefer_neuron=(i%2==0))
          for i in range(model.graph.fanin)]
    model.graph.units[target].add_branch(srcs)
    refresh_depths(model.graph)
    return {'action':'branch','neuron':target,'sources':srcs}


def growth_if_needed(model,stream,seen_before,new,device,train_x,train_y,prior,anchor,
                     importance,lr,batch,epochs,seed,min_gain=.001,
                     new_floor=.80,all_floor=.90,old_tolerance=.03,penalty=.00001,
                     anchoring=.5,distillation=.5,strict_fewshot=True):
    """Train matched reference and branch candidate; never use held-out test.

    Default strict mode consults old validation + novel labelled TRAIN support,
    not additional labelled novel validation samples. Support-based selection
    can overfit: the novel test/query partition remains the final arbiter.

    If no validation evidence of insufficient capability, do nothing.
    New branch is randomly proposed, not ranked by validation.
    """
    scorer=strict_selection_score if strict_fewshot else val_score
    current=scorer(model,stream,seen_before,new,device)
    all_val=(current['old_accuracy']+current['new_accuracy'])/2 if strict_fewshot else measure(model,stream,seen_before+new,device,'val')['accuracy']
    triggered=(current['new_accuracy']<new_floor or all_val<all_floor)
    event={'action':'branch_if_needed','triggered':int(triggered),'accepted':0,
           'strict_fewshot_selection':int(strict_fewshot),
           'before_val_loss':current['loss'],'before_val_new':current['new_accuracy'],
           'before_val_old':current['old_accuracy'],'before_val_all':all_val}
    if not triggered or epochs<=0:return model,event,0.0
    reference=copy.deepcopy(model);candidate=copy.deepcopy(model)
    before_n=parameter_count(reference)
    proposal=propose_branch(candidate,neuron_importance(importance,len(candidate.graph.units)),seed)
    elapsed=train_stage(reference,train_x,train_y,epochs,lr,batch,seed+500,
                        prior,anchor,importance,anchoring,distillation)
    elapsed+=train_stage(candidate,train_x,train_y,epochs,lr,batch,seed+500,
                         prior,anchor,importance,anchoring,distillation)
    ref=scorer(reference,stream,seen_before,new,device)
    cand=scorer(candidate,stream,seen_before,new,device)
    improvement=ref['loss']-cand['loss']-penalty*(parameter_count(candidate)-before_n)
    accepted=improvement>min_gain and cand['old_accuracy']>=ref['old_accuracy']-old_tolerance
    event.update(proposal)
    event.update({'accepted':int(accepted),'ref_val_loss':ref['loss'],
        'candidate_val_loss':cand['loss'],'score':improvement,
        'ref_old_accuracy':ref['old_accuracy'],'candidate_old_accuracy':cand['old_accuracy'],
        'candidate_new_accuracy':cand['new_accuracy'],
        'extra_parameters':parameter_count(candidate)-before_n})
    return (candidate if accepted else reference),event,elapsed


def accuracy_matrix(rows,method,stage_total):
    """Per-experience accuracy on original class groups under task-free inference."""
    selected=[r for r in rows if r['method']==method and r['split']=='test']
    matrix=[[None]*stage_total for _ in range(stage_total)]
    for r in selected:matrix[int(r['stage'])][int(r['group'])]=float(r['accuracy'])
    return matrix


def save_checkpoint(model,path,stream,stage,method):
    """Trusted-source tensor-only checkpoint, preserving plastic topology."""
    torch.save({'state_dict':model.state_dict(),
        'source_ids':[u.source_ids.detach().cpu().tolist() for u in model.graph.units],
        'kind':model.graph.kind,'input_dim':model.graph.input_dim,
        'branches':model.graph.branches,'fanin':model.graph.fanin,
        'nclasses':model.head.out_features,
        'stream_names':stream.names,'stage':stage,'method':method},path)


def load_checkpoint(path,device='cpu'):
    saved=torch.load(path,map_location='cpu',weights_only=True)
    graph=DendriticGraph(int(saved['input_dim']),0,int(saved['branches']),int(saved['fanin']),
                         kind=saved['kind'])
    for sources in saved['source_ids']:
        graph.add_neuron(source_ids=sources)
    model=GraphClassifier(graph,int(saved['nclasses']))
    model.load_state_dict(saved['state_dict'],strict=True)
    refresh_depths(model.graph)
    return model.to(device).eval(),saved


def save_checkpoint_v166(model,path,stream,stage,method,importance):
    """Preserve expanded topology, saved prototypes and online consolidation state."""
    torch.save({'state_dict':model.state_dict(),
       'source_ids':[u.source_ids.detach().cpu().tolist() for u in model.graph.units],
       'kind':model.graph.kind,'input_dim':model.graph.input_dim,
       'branches':model.graph.branches,'fanin':model.graph.fanin,
       'nclasses':model.head.out_features,'stream_names':stream.names,
       'stage':stage,'method':method,
       'classifier_type':'prototype' if isinstance(model,FrozenPrototypeGraph) else 'linear',
       'online_importance':{k:v.detach().cpu() for k,v in importance.items()}},path)


def load_checkpoint_v166(path,device='cpu'):
    saved=torch.load(path,map_location='cpu',weights_only=True)
    graph=DendriticGraph(int(saved['input_dim']),0,int(saved['branches']),int(saved['fanin']),kind=saved['kind'])
    for sources in saved['source_ids']:graph.add_neuron(source_ids=sources)
    if saved.get('classifier_type')=='prototype':
        model=FrozenPrototypeGraph(graph,int(saved['nclasses']))
        model.class_prototypes=torch.empty_like(saved['state_dict']['class_prototypes'])
    else:model=GraphClassifier(graph,int(saved['nclasses']))
    model.load_state_dict(saved['state_dict'],strict=True)
    refresh_depths(model.graph)
    return model.to(device).eval(),saved


def write_csv(path,rows):
    if not rows:return
    keys=list(dict.fromkeys(k for row in rows for k in row.keys()))
    with open(path,'w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)


def run(args):
    if args.source_classes<2 or args.novel_classes<1:
        raise ValueError('Need at least 2 source and 1 novel class')
    if args.memory<0 or args.increment<1 or args.fewshot<1:raise ValueError('Invalid increment or memory')
    torch.set_num_threads(max(1,args.cpu_threads))
    random.seed(args.seed);np.random.seed(args.seed);torch.manual_seed(args.seed)
    device=torch.device('cuda',torch.cuda.current_device()) if torch.cuda.is_available() and not args.cpu else torch.device('cpu')
    bundle=build_data(args.dataset,Path(args.data_root),args.seed,args.image_size,
                      args.source_classes,args.novel_classes,args.max_train,args.max_val)
    stream=build_stream(bundle,args.increment,args.fewshot)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    initial_n=len(stream.stage_groups[0])
    initial=GraphClassifier(DendriticGraph(stream.input_dim,args.neurons,args.branches,args.fanin,
               kind='dendritic',seed=args.seed,initial_wiring_probability=0.,
               initial_synapse_fraction=args.initial_synapses,spatial_sensory=True),initial_n).to(device)
    sx,sy=collect(stream.train,stream.stage_groups[0],device)
    initial_seconds=train_stage(initial,sx,sy,args.epochs,args.lr,args.batch,args.seed+100)
    # CONTROL: all methods start from the *same* learned initial graph.
    methods=['naive_finetune','fixed_head_only','selective_plasticity',
             'selective_plasticity_extra_training',
             'stochastic_recruitment','capacity_triggered_branch','point_fixed_plasticity',
             'point_budget_matched_plasticity','online_absolute_logits','frozen_prototype','point_frozen_prototype']
    base_graph=copy.deepcopy(initial)
    models={key:copy.deepcopy(base_graph) for key in methods if not key.startswith('point_') and key!='frozen_prototype'}
    prototype=FrozenPrototypeGraph(copy.deepcopy(initial.graph),initial_n).to(device)
    prototype.head.load_state_dict(initial.head.state_dict())
    prototype.enroll(sx,sy)
    models['frozen_prototype']=prototype
    point=GraphClassifier(DendriticGraph(stream.input_dim,args.neurons,args.branches,args.fanin,
           kind='point',seed=args.seed,initial_wiring_probability=0.,
           initial_synapse_fraction=args.initial_synapses,spatial_sensory=True),initial_n).to(device)
    point_initial_seconds=train_stage(point,sx,sy,args.epochs,args.lr,args.batch,args.seed+100)
    models['point_fixed_plasticity']=point
    point_prototype=FrozenPrototypeGraph(copy.deepcopy(point.graph),initial_n).to(device)
    point_prototype.head.load_state_dict(point.head.state_dict())
    point_prototype.enroll(sx,sy)
    models['point_frozen_prototype']=point_prototype
    target_params=parameter_count(initial)
    # Approximately matched trainable parameter budget at initial experience.
    # This is a separate control from the 32-soma point-neuron architecture.
    candidates=[]
    for n in range(1,max(args.neurons*3,100)):
        estimate=n*(args.branches*args.fanin+1+initial_n)+initial_n
        candidates.append((abs(estimate-target_params),n))
    matched_n=min(candidates)[1]
    point_matched=GraphClassifier(DendriticGraph(stream.input_dim,matched_n,args.branches,args.fanin,
           kind='point',seed=args.seed,initial_wiring_probability=0.,
           initial_synapse_fraction=args.initial_synapses,spatial_sensory=True),initial_n).to(device)
    matched_initial_seconds=train_stage(point_matched,sx,sy,args.epochs,args.lr,args.batch,args.seed+100)
    models['point_budget_matched_plasticity']=point_matched
    stages=len(stream.stage_groups)
    stage_rows=[]; group_rows=[]; class_rows=[]; event_rows=[];importance_rows=[]; cost_rows=[]; diagnostic_rows=[]
    # Capture importance *during each experience*, while labelled training data
    # for that experience are available; retain statistics but not the images.
    importance_history={name:current_task_importance(model,sx,sy,device)
                        for name,model in models.items() if not isinstance(model,FrozenPrototypeGraph)}
    previous_group_results={method:{} for method in methods}
    all_seen=list(stream.stage_groups[0]);memory_old=replay_memory(stream,all_seen,args.memory,args.seed)
    for method,model in models.items():
        save_checkpoint_v166(model,out/f'{method}_stage0.pt',stream,0,method,
                       importance_history.get(method,{}))
        result=measure(model,stream,all_seen,device)
        group_rows.append({'method':method,'stage':0,'group':0,'split':'test',
                           'classes':str(all_seen),'accuracy':result['accuracy']})
        previous_group_results[method][0]=result['accuracy']
        for c,acc in result['per_class'].items():
            class_rows.append({'method':method,'stage':0,'global_class':c,
                               'original_category':stream.names[int(c)],'test_accuracy':acc})
        stage_rows.append({'method':method,'stage':0,'seen_classes':len(all_seen),
            'old_test_accuracy':'','new_test_accuracy':result['accuracy'],
            'all_test_accuracy':result['accuracy'],'mean_forgetting':0.,
            'parameters':parameter_count(model),'neurons':len(model.graph.units),
            'max_depth':max(model.graph.depths),'active_synapses':model.graph.topology()['alive_synapses']})
        cost_rows.append({'method':method,'stage':0,'seconds':(point_initial_seconds if method=='point_frozen_prototype' else initial_seconds) if isinstance(model,FrozenPrototypeGraph) else (point_initial_seconds if method=='point_fixed_plasticity' else (matched_initial_seconds if method=='point_budget_matched_plasticity' else initial_seconds)),'memory_examples':0,
                          'prototype_memory_values':int(model.class_prototypes.numel()) if isinstance(model,FrozenPrototypeGraph) else 0})
    for stage in range(1,stages):
        newly=stream.stage_groups[stage]
        current_seen=all_seen+newly
        print(f'Stage {stage}/{stages-1}: {len(all_seen)} old + {len(newly)} new classes; total {len(current_seen)}',flush=True)
        nx,ny=collect(stream.train,newly,device)
        memx,memy=(collect(memory_old,all_seen,device) if args.memory>0 else (nx[:0],ny[:0]))
        xx=torch.cat([nx,memx]);yy=torch.cat([ny,memy])
        for method,model in models.items():
            old_model=copy.deepcopy(model).eval()
            for p in old_model.parameters():p.requires_grad_(True)
            # Importance is based exclusively on prior labelled training exemplars.
            # Zero replay is not zero consolidation: statistics were recorded
            # when previous task training examples were available.
            importance=(importance_history.get(method,{}) if not isinstance(model,FrozenPrototypeGraph) else {})
            neuron_scores=neuron_importance(importance,len(model.graph.units)) if importance else [0.]*len(model.graph.units)
            for idx,score in enumerate(neuron_scores):
                importance_rows.append({'method':method,'stage':stage,'neuron':idx,'importance':score})
            anchor={n:p.detach().clone() for n,p in old_model.named_parameters()}
            if isinstance(model,FrozenPrototypeGraph):
                # The prototype readout retains training-derived feature means,
                # and never modifies the original dendritic graph.
                expand_classes(model,len(current_seen))
                model.enroll(nx,ny)
                for p in model.head.parameters():p.requires_grad_(False)
            else:
                expand_classes(model,len(current_seen),support_x=nx,support_y=ny)
            if not isinstance(model,FrozenPrototypeGraph):
                for p in model.parameters():p.requires_grad_(True)
            if method=='fixed_head_only':
                for p in model.graph.parameters():p.requires_grad_(False)
            structural=[]
            if method=='stochastic_recruitment':
                structural=recruit_constrained(model,neuron_scores,args.seed+stage*1001,args.rewire_count)
            for e in structural:event_rows.append({'method':method,'stage':stage,'accepted':1,**e})
            adaptive=method in ('selective_plasticity','selective_plasticity_extra_training','stochastic_recruitment','capacity_triggered_branch','point_fixed_plasticity','point_budget_matched_plasticity','online_absolute_logits')
            start=time.perf_counter()
            if isinstance(model,FrozenPrototypeGraph):
                seconds=0.0
            else:
                seconds=train_stage(model,xx,yy,args.adapt_epochs,args.lr,args.batch,
                    args.seed+stage*997,prior=old_model if adaptive else None,
                    anchor=anchor if adaptive else None,
                    importance=importance if adaptive else None,
                    anchoring=args.anchor_lambda if adaptive else 0.,
                    distillation=args.distill_lambda if adaptive else 0.,
                    absolute_logit_weight=args.absolute_logits_lambda if method=='online_absolute_logits' else 0.)
            if method=='selective_plasticity_extra_training' and args.branch_trial_epochs>0:
                seconds+=train_stage(model,xx,yy,args.branch_trial_epochs,args.lr,args.batch,
                    args.seed+stage*2003+500,prior=old_model,anchor=anchor,
                    importance=importance,anchoring=args.anchor_lambda,
                    distillation=args.distill_lambda)
            if method=='capacity_triggered_branch':
                if args.memory==0 and not args.allow_historical_validation:
                    # No previous images, including held-out historical validation,
                    # can influence the selection decision in the zero-replay mode.
                    model,event,extra=zero_replay_growth(model,nx,ny,old_model,
                         anchor,importance,args.lr,args.batch,args.branch_trial_epochs,
                         args.seed+stage*2003,min_gain=args.min_gain,
                         penalty=args.parameter_penalty,new_floor=args.growth_new_floor)
                else:
                    model,event,extra=growth_if_needed(model,stream,all_seen,newly,device,
                        xx,yy,old_model,anchor,importance,args.lr,args.batch,args.branch_trial_epochs,
                        args.seed+stage*2003,args.min_gain,args.growth_new_floor,
                        args.growth_all_floor,args.old_tolerance,args.parameter_penalty,
                        args.anchor_lambda,args.distill_lambda,
                        strict_fewshot=not args.allow_novel_val_for_growth)
                    event['selection_uses_historical_images']=1
                seconds+=extra
                event_rows.append({'method':method,'stage':stage,**event})
            models[method]=model
            # Record importance at the end of the current task, with support only.
            # The old images need not be retained for the next task.
            if not isinstance(model,FrozenPrototypeGraph):
                fresh=current_task_importance(model,nx,ny,device)
                importance_history[method]=consolidate_importance(importance,fresh,
                                                       retain=args.importance_retain)
            diagnostic_rows.append({'method':method,'stage':stage,
                     'importance_source':'online_train_statistics' if not isinstance(model,FrozenPrototypeGraph) else 'none',
                     'mean_prior_importance':float(np.mean([v.mean().item() for v in importance.values()])) if importance else 0.,
                     **old_class_diagnostics(model,old_model,stream,all_seen,newly,device)})
            # Post-hoc structural ablation on untouched test only. These fields
            # are NEVER consulted by training or structural selection.
            for ev in event_rows:
                if ev.get('method')==method and ev.get('stage')==stage:
                    ev.update(structural_effect_test(model,stream,current_seen,device,ev))
            # Evaluate ONLY on seen classes, with the one global expanding head.
            old_eval=measure(model,stream,all_seen,device)
            new_eval=measure(model,stream,newly,device)
            all_eval=measure(model,stream,current_seen,device)
            for c,acc in all_eval['per_class'].items():
                class_rows.append({'method':method,'stage':stage,'global_class':c,
                                   'original_category':stream.names[int(c)],'test_accuracy':acc})
            prev_max=previous_group_results[method]
            forget=[]
            for grp in range(stage+1):
                group=stream.stage_groups[grp]
                ev=measure(model,stream,group,device)
                group_rows.append({'method':method,'stage':stage,'group':grp,'split':'test',
                                   'classes':str(group),'accuracy':ev['accuracy']})
                if grp<stage:
                    forget.append(max(0.,prev_max[grp]-ev['accuracy']))
                prev_max[grp]=max(prev_max.get(grp,0.),ev['accuracy'])
            stage_rows.append({'method':method,'stage':stage,'seen_classes':len(current_seen),
                'old_test_accuracy':old_eval['accuracy'],'new_test_accuracy':new_eval['accuracy'],
                'all_test_accuracy':all_eval['accuracy'],
                'mean_forgetting':float(np.mean(forget)) if forget else 0.,
                'parameters':parameter_count(model),'neurons':len(model.graph.units),
                'max_depth':max(model.graph.depths),'active_synapses':model.graph.topology()['alive_synapses']})
            cost_rows.append({'method':method,'stage':stage,'seconds':seconds,
                              'memory_examples':len(memx),'training_examples':len(xx),
                              'prototype_memory_values':int(model.class_prototypes.numel()) if isinstance(model,FrozenPrototypeGraph) else 0})
            save_checkpoint_v166(model,out/f'{method}_stage{stage}.pt',stream,stage,method,
                       importance_history.get(method,{}))
            print(f'  {method}: all={all_eval["accuracy"]:.3f} old={old_eval["accuracy"]:.3f} new={new_eval["accuracy"]:.3f} forget={stage_rows[-1]["mean_forgetting"]:.3f}',flush=True)
        all_seen=current_seen
        memory_old=replay_memory(stream,all_seen,args.memory,args.seed)
    write_csv(out/'continual_metrics.csv',stage_rows)
    write_csv(out/'experience_accuracy_matrix.csv',group_rows)
    write_csv(out/'per_class_accuracy.csv',class_rows)
    write_csv(out/'development_events.csv',event_rows)
    write_csv(out/'neuron_importance.csv',importance_rows)
    write_csv(out/'training_costs.csv',cost_rows)
    write_csv(out/'old_new_competition_diagnostics.csv',diagnostic_rows)
    summary={'version':'1.6.6','dataset':args.dataset,'seed':args.seed,
        'device':str(device),'source_class_ids':bundle.source_classes,
        'novel_class_ids':bundle.novel_classes,'global_class_mapping':{str(i):int(v) for i,v in enumerate(stream.names)},
        'experience_groups':stream.stage_groups,'stage_count':stages,
        'initial_test_n':sum(len(stream.test[i]) for i in stream.stage_groups[0]),
        'new_examples_per_class':args.fewshot,'replay_examples_per_prior_class':args.memory,
        'methods':methods,'neuron_count_initial':args.neurons,
        'validation_never_used_for_training':True,'test_never_used_for_selection':True,
        'novel_validation_used_for_growth':bool(args.allow_novel_val_for_growth and (args.memory>0 or args.allow_historical_validation)),
        'historical_validation_used_for_growth':bool(args.memory>0 or args.allow_historical_validation),
        'zero_replay_selection_historical_data_blocked':bool(args.memory==0 and not args.allow_historical_validation),
        'importance_retained_across_tasks':True,
        'prototype_memory_stores_feature_means':True,
        'all_seen_classes_compete_at_inference':True,
        'limitations':['COIL has no official class-incremental benchmark partition: custom angle protocol.',
           'Stochastic growth and consolidation are algorithmic analogies, not biological models.',
           'Distillation and importance anchoring use standard gradient-based optimization.',
           'Rehearsal memory stores labelled training examples; report memory budget.',
           'Task-known addition stages; unknown-category detection is not implemented.',
           'Frozen prototypes are compressed labelled-feature memory, NOT memory-free learning.',
           'Importance is retained as parameter statistics across experiences, NOT biology.',
           'Old-class diagnostic tests run after learning and are never used for selection.',
           'Zero-replay branch selection uses only novel training supports by default; inherently optimistic.',
           'Branch selection repeatedly inspects held-out validation; report independent test metrics.',
           'No claims of statistical significance without multiple seeds and repetitions.'],
        'args':{k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()}}
    (out/'run_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    print('Saved continual learning results:',out)
    return stage_rows, group_rows


def parse_args(argv=None):
    ap=argparse.ArgumentParser(description='NeuroWeave 1.6.6 audited class-incremental learning')
    ap.add_argument('--dataset',choices=['synthetic','coil100','pets'],default='synthetic')
    ap.add_argument('--data-root',default='data')
    ap.add_argument('--output',default='results/v165_smoke')
    ap.add_argument('--cpu',action='store_true')
    ap.add_argument('--cpu-threads',type=int,default=2)
    ap.add_argument('--seed',type=int,default=11)
    ap.add_argument('--image-size',type=int,default=16)
    ap.add_argument('--source-classes',type=int,default=6)
    ap.add_argument('--novel-classes',type=int,default=6)
    ap.add_argument('--increment',type=int,default=2)
    ap.add_argument('--fewshot',type=int,default=4)
    ap.add_argument('--max-train',type=int,default=4)
    ap.add_argument('--max-val',type=int,default=18)
    ap.add_argument('--memory',type=int,default=2)
    ap.add_argument('--neurons',type=int,default=32)
    ap.add_argument('--branches',type=int,default=4)
    ap.add_argument('--fanin',type=int,default=16)
    ap.add_argument('--initial-synapses',type=float,default=.55)
    ap.add_argument('--epochs',type=int,default=20)
    ap.add_argument('--adapt-epochs',type=int,default=20)
    ap.add_argument('--branch-trial-epochs',type=int,default=3)
    ap.add_argument('--rewire-count',type=int,default=2)
    ap.add_argument('--lr',type=float,default=.008)
    ap.add_argument('--batch',type=int,default=128)
    ap.add_argument('--anchor-lambda',type=float,default=.7)
    ap.add_argument('--distill-lambda',type=float,default=.5)
    ap.add_argument('--importance-retain',type=float,default=.9)
    ap.add_argument('--absolute-logits-lambda',type=float,default=1.0)
    ap.add_argument('--allow-historical-validation',action='store_true',
       help='Oracle analysis only: permit previous held-out validation images for selecting branches with no replay')
    ap.add_argument('--growth-new-floor',type=float,default=.8)
    ap.add_argument('--growth-all-floor',type=float,default=.9)
    ap.add_argument('--old-tolerance',type=float,default=.03)
    ap.add_argument('--allow-novel-val-for-growth',action='store_true',
        help='Exploratory only: use additional novel-class validation labels for branch selection; OFF by default for strict few-shot')
    ap.add_argument('--min-gain',type=float,default=.001)
    ap.add_argument('--parameter-penalty',type=float,default=.00001)
    return ap.parse_args(argv)


if __name__=='__main__':run(parse_args())
