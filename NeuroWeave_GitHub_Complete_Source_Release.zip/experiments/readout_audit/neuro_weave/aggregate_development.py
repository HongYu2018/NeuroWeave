"""Aggregate independent v1.6.4 seed folders; preserve paired seed comparisons."""
import argparse,csv,statistics
from pathlib import Path

def read_csv(path):
    with path.open(newline='',encoding='utf8') as f:return list(csv.DictReader(f))

def write(path,rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--results',type=Path,default=Path('results'))
    p.add_argument('--prefix',default='coil_development_seed')
    p.add_argument('--output',type=Path,default=Path('results/development_aggregate'))
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    sources=[];few=[]
    for folder in sorted(args.results.glob(args.prefix+'*')):
        sf=folder/'source_validation.csv';ef=folder/'fewshot_episodes.csv'
        if sf.exists() and ef.exists():
            sources+=read_csv(sf);few+=read_csv(ef)
    if not sources:raise SystemExit('No completed seed folders found')
    write(args.output/'all_source_seeds.csv',sources)
    buckets={}
    for r in sources:buckets.setdefault(r['method'],[]).append(r)
    summary=[]
    for method,rows in sorted(buckets.items()):
        acc=[float(r['source_test_accuracy']) for r in rows]
        summary.append({'method':method,'seed_count':len(rows),'mean_test_accuracy':statistics.mean(acc),
                        'sample_sd_test_accuracy':statistics.stdev(acc) if len(acc)>1 else 0,
                        'mean_parameters':statistics.mean(float(r['parameters']) for r in rows),
                        'mean_training_and_search_seconds':statistics.mean(float(r['training_and_search_seconds']) for r in rows)})
    write(args.output/'source_mean_sd.csv',summary)
    fb={}
    for r in few:fb.setdefault((r['method'],int(r['shot'])),[]).append(float(r['accuracy']))
    shotrows=[]
    for (method,shot),vals in sorted(fb.items()):
        shotrows.append({'method':method,'shot':shot,'episode_count':len(vals),'mean_accuracy':statistics.mean(vals),
                         'warning':'Episodes share images/classes; episode SD is not independent-seed uncertainty'})
    write(args.output/'fewshot_episode_means.csv',shotrows)
    pairs={}
    for r in sources:pairs.setdefault(int(r['seed']),{})[r['method']]=float(r['source_test_accuracy'])
    diffs=[]
    for seed,methods in sorted(pairs.items()):
        sel=methods.get('development_selected')
        if sel is None:continue
        for ctrl in ('development_random_unconditional','development_random_accept_matched',
                     'development_fixed','development_finetune_no_growth','point_budget_matched'):
            if ctrl in methods:diffs.append({'seed':seed,'control':ctrl,'selected_minus_control':sel-methods[ctrl]})
    write(args.output/'paired_seed_differences.csv',diffs)
    print('Aggregated',len(pairs),'seeds into',args.output)
if __name__=='__main__':main()
