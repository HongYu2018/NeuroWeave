from pathlib import Path
import copy
import torch
import pytest
from neuro_weave.model import DendriticGraph,GraphClassifier,MLPClassifier,parameter_count,matched_mlp_width
from neuro_weave.data import build_data
from neuro_weave.learning import fit,evaluate,structural_growth,few_shot,matched_random_schedule
from neuro_weave.diagnostics import neuron_diagnostics,perturb


def test_no_predefined_layers_and_causal_graph():
    g=DendriticGraph(27,8,3,5,seed=11)
    assert len(g.units)==8 and min(g.depths)==1
    assert max(g.depths)>=1
    for _ in range(5):g.add_neuron()
    assert any(d>1 for d in g.depths)
    for i,u in enumerate(g.units):
        assert int(u.source_ids.max())<27+i
    assert g(torch.rand(4,27)).shape==(4,13)
    assert g.topology()['max_depth']>=2


def test_multicompartment_differs_from_point_neuron():
    g=DendriticGraph(27,4,4,8,seed=1)
    h=DendriticGraph(27,4,4,8,kind='point',seed=1)
    x=torch.rand(7,27)
    assert not torch.allclose(g(x),h(x))
    assert parameter_count(g)>parameter_count(h)
    assert g.units[0].soma_weights.numel()==4


def test_train_and_silence_gradient():
    torch.manual_seed(0)
    graph=DendriticGraph(48,5,3,8)
    m=GraphClassifier(graph,3)
    x=torch.rand(24,48);y=torch.randint(0,3,(24,))
    old=m.graph.units[0].weights.detach().clone()
    fit(m,x,y,1,lr=.005)
    assert not torch.equal(old,m.graph.units[0].weights.detach())
    assert m(x, silence=0).shape==(24,3)
    assert m.graph(x,silence=0)[:,0].abs().sum().item()==0


def test_source_novel_split_disjoint():
    d=build_data('synthetic',Path('data'),seed=11,size=8,source_classes=6,novel_classes=4)
    assert not (set(d.source_classes)&set(d.novel_classes))
    assert d.source_train_x.shape[1]==8*8*3
    assert len(d.novel)==4
    for bank in d.novel.values():assert len(bank['support'])>=10 and len(bank['query'])>=12


def test_growth_does_not_examine_novel_queries():
    torch.manual_seed(5)
    d=build_data('synthetic',Path('data'),11,8,4,4,max_train=12,max_val=5)
    model=GraphClassifier(DendriticGraph(192,5,3,6,seed=1),4)
    fit(model,d.source_train_x,d.source_train_y,1)
    new,events,_=structural_growth(model,d.source_train_x,d.source_train_y,
                            d.source_val_x,d.source_val_y,proposals=1,max_accept=1,trial_epochs=1)
    assert len(events)==1 and len(new.graph.units) in (5,6)
    report=few_shot(new,d.novel,[1,5],ways=3,episodes=2,seed=31)
    assert len(report)==4
    assert all(0<=r['accuracy']<=1 for r in report)


def test_synaptic_pruning():
    g=DendriticGraph(24,5,4,8,seed=1)
    original=g.topology()['alive_synapses']
    n=g.units[0].prune_weak_synapses(.25)
    assert n>0 and g.topology()['alive_synapses']==original-n
    assert g(torch.rand(3,24)).shape==(3,5)


def test_perturbation_and_neuron_diagnostics():
    g=DendriticGraph(3*8*8,4,3,5,seed=1)
    m=GraphClassifier(g,3)
    x=torch.rand(12,3*8*8);y=torch.randint(0,3,(12,))
    assert perturb(x,8,'blur').shape==x.shape
    rows=neuron_diagnostics(m,x,y,8)
    assert len(rows)==4 and 'ablation_delta_loss' in rows[0]


def test_parameter_match_width():
    dim=768;nclasses=20
    target=15000
    width=matched_mlp_width(dim,nclasses,target)
    assert abs(parameter_count(MLPClassifier(dim,nclasses,width))-target) < dim+nclasses+1


def test_coil_partition_and_no_network(tmp_path,monkeypatch):
    from PIL import Image
    from neuro_weave import data
    images=tmp_path/'images';images.mkdir()
    for cls in range(1,6):
        for angle in [0,5,10,15,20,25,30,35]:
            Image.new('RGB',(8,8),(cls*20,angle,30)).save(images/f'obj{cls}__{angle}.png')
    monkeypatch.setattr(data,'prepare_coil',lambda root:images)
    bundle=data.build_data('coil100',tmp_path,11,8,3,2,max_train=2,max_val=2)
    assert len(bundle.source_classes)==3 and len(bundle.novel_classes)==2
    assert len(bundle.source_test_x)==3*4
    assert all(len(n['support'])==2 and len(n['query'])==4 for n in bundle.novel.values())


def test_pet_official_split_parser_without_network(tmp_path,monkeypatch):
    from PIL import Image
    from neuro_weave import data
    root=tmp_path/'pets';(root/'images').mkdir(parents=True);(root/'annotations').mkdir()
    train=[];test=[]
    for cls in range(1,6):
        for i in range(8):
            name=f'breed_{cls}_{i}';Image.new('RGB',(8,8),(cls*25,i*18,0)).save(root/'images'/f'{name}.jpg')
            (train if i<6 else test).append(f'{name} {cls} 1 1')
    (root/'annotations'/'trainval.txt').write_text('\n'.join(train))
    (root/'annotations'/'test.txt').write_text('\n'.join(test))
    monkeypatch.setattr(data,'prepare_pets',lambda _root:root)
    bundle=data.build_data('pets',tmp_path,11,8,3,2,max_train=3,max_val=2)
    assert len(bundle.source_test_x)==6
    assert len(bundle.novel)==2
    assert all(len(n['query'])==2 for n in bundle.novel.values())


def test_high_acceptance_threshold_rejects_unproven_growth():
    from neuro_weave.learning import structural_growth
    x=torch.rand(12,21);y=torch.randint(0,2,(12,))
    m=GraphClassifier(DendriticGraph(21,4,2,5,seed=13),2)
    m,events,_=structural_growth(m,x,y,x,y,proposals=2,max_accept=2,
                                  trial_epochs=1,min_gain=1000.)
    assert len(m.graph.units)==4
    assert all(not e['accepted'] for e in events)


def test_new_neuron_inherits_graph_device_and_dtype():
    """Regression for CPU tensors appended to an existing CUDA graph."""
    graph = DendriticGraph(24, 5, 3, 6, seed=3).to(dtype=torch.float64)
    graph.add_neuron(allow_existing=True)
    new_unit = graph.units[-1]
    assert new_unit.weights.dtype == torch.float64
    assert new_unit.synapse_mask.dtype == torch.float64
    assert new_unit.source_ids.dtype == torch.long
    assert new_unit.weights.device == graph.units[0].weights.device
    assert graph(torch.rand(4, 24, dtype=torch.float64)).shape == (4, 6)


def test_new_neuron_works_on_non_cpu_device():
    """Meta-device check runs even on hosts without an NVIDIA GPU."""
    graph = DendriticGraph(24, 4, 3, 5, seed=8).to('meta')
    classifier = GraphClassifier(graph, 3).to('meta')
    graph.add_neuron(allow_existing=True)
    assert graph.units[-1].weights.device.type == 'meta'
    assert graph.units[-1].synapse_mask.device.type == 'meta'
    assert graph.units[-1].source_ids.device.type == 'meta'
    classifier.expand()
    assert classifier.head.weight.device.type == 'meta'
    assert classifier(torch.empty(2, 24, device='meta')).shape == (2, 3)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA device not available')
def test_cuda_dynamic_growth_selected_and_random():
    """On GPU, verify real devices, buffers, forwards, and both growth outcomes.

    torch.device('cuda') is a device without an explicit index and does not
    compare equal to torch.device('cuda:0'), even on the default CUDA GPU.
    Compare against the actual input tensor device, which has an index.
    """
    device = torch.device('cuda', torch.cuda.current_device())
    torch.manual_seed(19)
    model = GraphClassifier(DendriticGraph(24, 5, 3, 6, seed=19), 3).to(device)
    x = torch.rand(16, 24, device=device)
    y = torch.randint(0, 3, (16,), device=device)
    assert model.head.weight.device == x.device

    def check_every_tensor(mod):
        assert all(p.device == x.device for p in mod.parameters())
        assert all(b.device == x.device for b in mod.buffers())
        with torch.no_grad():
            assert torch.isfinite(mod(x)).all()

    # Force acceptance to cover dynamically appended neuron on an actual GPU.
    grown, events, _ = structural_growth(copy.deepcopy(model), x, y, x, y,
                                        proposals=1, max_accept=1, trial_epochs=1,
                                        min_gain=-100., prune_fraction=0.)
    assert len(events) == 1 and events[0]['accepted'] == 1
    assert len(grown.graph.units) == 6
    check_every_tensor(grown)

    # Force rejection: the head-only reference branch also stays on GPU.
    rejected, rejection_events, _ = structural_growth(copy.deepcopy(model), x, y, x, y,
                                                      proposals=1, max_accept=1,
                                                      trial_epochs=1, min_gain=1000.)
    assert len(rejection_events) == 1 and rejection_events[0]['accepted'] == 0
    check_every_tensor(rejected)

    # Matched stochastic growth must have GPU-resident parameters and buffers.
    random_grown, _, _ = matched_random_schedule(copy.deepcopy(model), x, y,
                                                 proposals=1, accepted=1, epochs=1)
    assert len(random_grown.graph.units) == 6
    check_every_tensor(random_grown)


def test_accepted_growth_repeatedly_adds_compatible_neurons():
    """Force accepted candidates and verify multiple sequential graph expansions."""
    torch.manual_seed(10)
    x = torch.rand(12, 18)
    y = torch.randint(0, 2, (12,))
    base = GraphClassifier(DendriticGraph(18, 4, 3, 5, seed=10), 2)
    grown, events, _ = structural_growth(base, x, y, x, y, proposals=2,
                                         max_accept=2, trial_epochs=1,
                                         min_gain=-100., prune_fraction=0.)
    assert len(grown.graph.units) == 6
    assert sum(e['accepted'] for e in events) == 2
    assert grown(x).shape == (12, 2)
    assert all(u.weights.device == x.device for u in grown.graph.units)


def test_rejected_growth_explores_different_proposals():
    """Do not re-propose identical wiring when the selected model is rejected."""
    from neuro_weave.learning import structural_growth
    torch.manual_seed(120)
    x=torch.rand(18,30); y=torch.randint(0,3,(18,))
    base=GraphClassifier(DendriticGraph(30,6,3,5,seed=120),3)
    grown,events,_=structural_growth(base,x,y,x,y,proposals=4,
                                      max_accept=4,trial_epochs=1,min_gain=1000.)
    assert len(grown.graph.units)==6
    assert [e['accepted'] for e in events]==[0,0,0,0]
    assert len(set(e['source_indices'] for e in events))==4


def test_unconditional_growth_is_non_degenerate_and_consistent():
    """Random non-selected addition must happen even if selected accepts nothing."""
    from neuro_weave.learning import unconditional_growth
    torch.manual_seed(121)
    x=torch.rand(12,24); y=torch.randint(0,3,(12,))
    base=GraphClassifier(DendriticGraph(24,5,3,6,seed=121),3)
    grown,events,_=unconditional_growth(base,x,y,num_additions=3,epochs=1)
    assert len(events)==3
    assert all(e['accepted']==1 for e in events)
    assert len(grown.graph.units)==8
    assert grown.head.in_features==8
    assert torch.isfinite(grown(x)).all()
