"""Functional and leakage-oriented tests for v1.6.5. No external datasets needed."""
from __future__ import annotations
import copy
import random
from pathlib import Path
import pytest
import torch
from neuro_weave.data import build_data
from neuro_weave.continual import (
    build_stream,collect,replay_memory,expand_classes,importance_from_memory,
    neuron_importance,anchored_penalty,recruit_constrained,propose_branch,train_stage,
    measure,val_score,growth_if_needed,save_checkpoint,load_checkpoint,parse_args,run,
    accuracy_matrix)
from neuro_weave.model import DendriticGraph,GraphClassifier,parameter_count


def toy_model(seed=12,device='cpu',neurons=5):
    return GraphClassifier(DendriticGraph(3*8*8,neurons,2,5,seed=seed,
           initial_wiring_probability=0.,initial_synapse_fraction=.5,
           spatial_sensory=True),4).to(device)


def stream():
    data=build_data('synthetic',Path('unused'),17,size=8,
        source_classes=4,novel_classes=4,max_train=4,max_val=4)
    return build_stream(data,increment=2,shots=3)


def test_stream_keeps_disjoint_stable_classes():
    ss=stream()
    assert ss.stage_groups==[[0,1,2,3],[4,5],[6,7]]
    assert len(set(ss.names))==8
    assert all(len(ss.train[i])>0 and len(ss.val[i])>0 and len(ss.test[i])>0 for i in range(8))
    assert all(not torch.equal(ss.train[i][0],ss.val[i][0]) for i in range(8))
    assert all(not torch.equal(ss.train[i][0],ss.test[i][0]) for i in range(8))
    assert len(ss.train[4])==3


def test_novel_support_is_never_query_or_validation():
    ss=stream()
    assert not any(torch.equal(a,b) for a in ss.train[4] for b in ss.test[4])
    assert not any(torch.equal(a,b) for a in ss.train[4] for b in ss.val[4])


def test_collect_uses_global_labels_and_memory_is_training_only():
    ss=stream();x,y=collect(ss.train,[0,4,5],'cpu')
    assert set(y.tolist())=={0,4,5}
    mem=replay_memory(ss,[0,4,5],2,33)
    assert all(len(mem[c])==2 for c in mem)
    assert all(any(torch.equal(z,inp) for inp in ss.train[c]) for c in mem for z in mem[c])
    assert all(not any(torch.equal(z,val) for val in ss.val[c]) for c in mem for z in mem[c])
    assert all(torch.equal(mem[c],replay_memory(ss,[0,4,5],2,33)[c]) for c in mem)
    assert replay_memory(ss,[0],0,33)[0].shape[0]==0


def test_expanding_output_preserves_old_class_logits_and_device():
    m=toy_model()
    xx=torch.rand(6,3*8*8)
    before=m.eval()(xx).detach()
    initial_graph=list(m.graph.parameters())
    expand_classes(m,6)
    new=m.eval()(xx)
    assert torch.allclose(before,new[:,:4],atol=1e-7)
    assert m.head.out_features==6
    assert initial_graph[0] is list(m.graph.parameters())[0]
    assert all(p.device==xx.device for p in m.parameters())


def test_measure_on_old_subset_never_masks_new_class_competitors():
    ss=stream();m=toy_model()
    expand_classes(m,6)
    with torch.no_grad():
        m.head.weight.zero_();m.head.bias.zero_();m.head.bias[4]=100
    old=measure(m,ss,[0,1,2,3],'cpu')
    assert old['accuracy']==0.0, 'Full expanded output must compete at inference'


def test_importance_and_anchor_old_parameter_prefix():
    m=toy_model();ss=stream()
    mem=replay_memory(ss,[0,1,2,3],2,14)
    imp=importance_from_memory(m,mem,'cpu')
    assert len(imp)==len(list(m.named_parameters()))
    assert all(torch.isfinite(v).all() for v in imp.values())
    scores=neuron_importance(imp,5)
    assert len(scores)==5 and all(s>=0 for s in scores)
    anchors={k:v.detach().clone() for k,v in m.named_parameters()}
    expand_classes(m,6)
    assert anchored_penalty(m,anchors,imp).item()==pytest.approx(0.,abs=1e-9)
    with torch.no_grad():m.head.weight[0,0]+=1
    assert anchored_penalty(m,anchors,imp).item()>0.


def test_recruitment_changes_connections_not_parameter_total():
    m=toy_model();count=parameter_count(m)
    before=m.graph.topology()['alive_synapses']
    events=recruit_constrained(m,[0]*5,seed=19,count=3)
    assert len(events)==3
    assert m.graph.topology()['alive_synapses']==before+3
    assert parameter_count(m)==count
    for i,u in enumerate(m.graph.units):
        assert all(int(z)<m.graph.input_dim+i for z in u.source_ids.flatten().tolist())


def test_branch_growth_is_same_neuron_count_and_anchor_safe():
    m=toy_model();start=parameter_count(m)
    anchor={n:p.detach().clone() for n,p in m.named_parameters()}
    importance={n:torch.ones_like(p) for n,p in m.named_parameters()}
    desc=propose_branch(m,[0.]*5,seed=15)
    assert desc['action']=='branch' and len(m.graph.units)==5
    assert parameter_count(m)>start
    assert torch.isfinite(anchored_penalty(m,anchor,importance))
    assert torch.isfinite(m(torch.rand(2,3*8*8))).all()


def test_train_with_distillation_and_anchor_on_expanded_head():
    ss=stream();m=toy_model();old=copy.deepcopy(m)
    memory=replay_memory(ss,[0,1,2,3],2,8)
    importance=importance_from_memory(old,memory,'cpu')
    anchor={n:p.detach().clone() for n,p in old.named_parameters()}
    expand_classes(m,6)
    x,y=collect({**memory,4:ss.train[4],5:ss.train[5]},[0,1,2,3,4,5],'cpu')
    train_stage(m,x,y,2,.01,16,seed=123,prior=old,anchor=anchor,importance=importance,
                anchoring=.5,distillation=.4)
    assert torch.isfinite(m(x)).all()


def test_growth_not_triggered_when_full_val_good():
    ss=stream();m=toy_model();expand_classes(m,6)
    x,y=collect(ss.train,[4,5],'cpu')
    before=parameter_count(m)
    chosen,event,cost=growth_if_needed(m,ss,[0,1,2,3],[4,5],'cpu',x,y,
        copy.deepcopy(toy_model()),None,None,.01,16,1,19,
        new_floor=0.,all_floor=0.)
    assert cost==0 and event['triggered']==0 and parameter_count(chosen)==before


def test_growth_forced_rejection_preserves_topology_and_is_finite():
    ss=stream();m=toy_model();old=copy.deepcopy(m)
    memory=replay_memory(ss,[0,1,2,3],2,2)
    imp=importance_from_memory(old,memory,'cpu')
    anchors={n:p.detach().clone() for n,p in old.named_parameters()}
    expand_classes(m,6)
    x,y=collect({**memory,4:ss.train[4],5:ss.train[5]},[0,1,2,3,4,5],'cpu')
    chosen,event,_=growth_if_needed(m,ss,[0,1,2,3],[4,5],'cpu',x,y,
        old,anchors,imp,.01,16,1,21,min_gain=1e6,new_floor=2.,all_floor=2.)
    assert event['triggered']==1 and event['accepted']==0
    assert parameter_count(chosen)==parameter_count(m)
    assert torch.isfinite(chosen(x)).all()


def test_checkpoint_roundtrip_with_expanding_head_and_dendritic_branch(tmp_path):
    ss=stream();m=toy_model();expand_classes(m,6)
    propose_branch(m,[0]*5,10)
    x=torch.rand(7,3*8*8)
    pred=m.eval()(x).detach()
    path=tmp_path/'one.pt'
    save_checkpoint(m,path,ss,1,'test')
    loaded,metadata=load_checkpoint(path,'cpu')
    assert metadata['stream_names']==ss.names
    assert len(loaded.graph.units)==len(m.graph.units)
    assert torch.allclose(pred,loaded(x),atol=1e-7)
    assert loaded.graph.topology()['alive_synapses']==m.graph.topology()['alive_synapses']


def test_accuracy_matrix_preserves_previous_groups():
    rows=[dict(method='m',split='test',stage=0,group=0,accuracy=.8),
          dict(method='m',split='test',stage=1,group=0,accuracy=.7),
          dict(method='m',split='test',stage=1,group=1,accuracy=.9)]
    assert accuracy_matrix(rows,'m',2)==[[.8,None],[.7,.9]]


def test_end_to_end_synthetic_class_incremental(tmp_path):
    args=parse_args(['--dataset','synthetic','--cpu','--output',str(tmp_path),
        '--source-classes','4','--novel-classes','4','--increment','2',
        '--image-size','8','--neurons','5','--branches','2','--fanin','5',
        '--max-train','4','--max-val','4','--fewshot','2','--memory','1',
        '--epochs','2','--adapt-epochs','2','--branch-trial-epochs','1'])
    stages,matrix=run(args)
    assert {int(r['stage']) for r in stages}=={0,1,2}
    assert len(stages)==24  # eight methods x three stages
    assert {int(r['seen_classes']) for r in stages}=={4,6,8}
    assert (tmp_path/'continual_metrics.csv').exists()
    assert (tmp_path/'development_events.csv').exists()
    assert all(0<=float(r['all_test_accuracy'])<=1 for r in stages)
    assert all(int(r['neurons'])==5 for r in stages if not r['method'].startswith('point_budget_'))
    assert all(len([r for r in matrix if r['method']==m and r['stage']==2])==3
               for m in {r['method'] for r in stages})
    checkpoint,_=load_checkpoint(tmp_path/'capacity_triggered_branch_stage2.pt')
    assert checkpoint.head.out_features==8


@pytest.mark.skipif(not torch.cuda.is_available(),reason='CUDA unavailable')
def test_cuda_dynamic_expansion_recruitment_branch_and_learning():
    dev=torch.device('cuda',torch.cuda.current_device())
    ss=stream();m=toy_model(device=dev)
    prior=copy.deepcopy(m)
    imp=importance_from_memory(prior,replay_memory(ss,[0,1,2,3],2,3),dev)
    anchor={n:p.detach().clone() for n,p in prior.named_parameters()}
    expand_classes(m,6)
    recruit_constrained(m,neuron_importance(imp,5),34,2)
    propose_branch(m,neuron_importance(imp,5),35)
    x,y=collect({**replay_memory(ss,[0,1,2,3],2,3),4:ss.train[4],5:ss.train[5]},list(range(6)),dev)
    train_stage(m,x,y,1,.01,16,1,prior,anchor,imp,.5,.5)
    assert all(p.device==dev for p in m.parameters())
    assert all(b.device==dev for b in m.buffers())
    assert torch.isfinite(m(x)).all()


def test_prototype_head_rows_are_initialized_from_training_support_only():
    torch.manual_seed(44)
    m=toy_model();x=torch.rand(8,3*8*8)
    old=m(x).detach().clone()
    y=torch.tensor([4]*4+[5]*4)
    expand_classes(m,6,support_x=x,support_y=y)
    assert torch.allclose(m(x)[:,:4],old,atol=1e-7)
    assert torch.isfinite(m.head.weight).all()
    assert not torch.allclose(m.head.weight[4],m.head.weight[5])


def test_strict_growth_does_not_read_novel_validation_images():
    ss=stream();m=toy_model();old=copy.deepcopy(m)
    importance=importance_from_memory(old,replay_memory(ss,[0,1,2,3],2,44),'cpu')
    anchor={n:p.detach().clone() for n,p in old.named_parameters()}
    expand_classes(m,6,support_x=torch.cat([ss.train[4],ss.train[5]]),
                   support_y=torch.tensor([4]*3+[5]*3))
    memory=replay_memory(ss,[0,1,2,3],2,44)
    xx,yy=collect({**memory,4:ss.train[4],5:ss.train[5]},list(range(6)),'cpu')
    # If strict selection tries to use novel val for branch selection, this fails.
    ss.val[4]=torch.empty(0,3*8*8)
    ss.val[5]=torch.empty(0,3*8*8)
    chosen,event,_=growth_if_needed(m,ss,[0,1,2,3],[4,5],'cpu',xx,yy,
         old,anchor,importance,.01,16,1,37,new_floor=2.,all_floor=2.,
         strict_fewshot=True,min_gain=1e8)
    assert event['strict_fewshot_selection']==1
    assert chosen.head.out_features==6


def test_aggregator_requires_paired_methods_and_seeds():
    from neuro_weave.aggregate_continual import aggregate
    rows=[]
    for seed in [11,12]:
        for method in ['selective_plasticity','naive_finetune']:
            rows.append({'seed':seed,'stage':1,'method':method,
                'all_test_accuracy':'0.7','old_test_accuracy':'0.8',
                'new_test_accuracy':'0.6','mean_forgetting':'0.1',
                'parameters':'100','active_synapses':'90'})
    summary,paired=aggregate(rows,[11,12])
    assert len(summary)==2 and len(paired)==1
    assert paired[0]['accuracy_delta_mean']==pytest.approx(0)
    with pytest.raises(ValueError):aggregate(rows[:-1],[11,12])
