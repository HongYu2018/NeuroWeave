"""Regression tests for developmental growth, local sensory wiring and controls."""
import copy
import random
import pytest
import torch
from neuro_weave.model import DendriticGraph,GraphClassifier
from neuro_weave.plasticity import (propose_action,refresh_depths,development_selected,
                                    development_random,branch_dependency)


def test_initial_development_has_no_hidden_stack():
    g=DendriticGraph(3*8*8,initial_neurons=12,branches=3,fanin=8,seed=11,
       initial_wiring_probability=0.,initial_synapse_fraction=.5,spatial_sensory=True)
    assert max(g.depths)==1
    assert g.topology()['alive_synapses'] < 12*3*8
    assert all(int(k)<g.input_dim for u in g.units for k in u.source_ids.flatten().tolist())
    assert g(torch.rand(4,3*8*8)).shape==(4,12)


def test_synaptic_recruitment_and_rewiring_modify_graph_not_parameters():
    m=GraphClassifier(DendriticGraph(48,8,3,6,seed=3,
                       initial_wiring_probability=0.,initial_synapse_fraction=.5),3)
    before=sum(int(u.synapse_mask.sum().item()) for u in m.graph.units)
    event=propose_action(m,'synapse',random.Random(10))
    assert event is not None
    assert m.graph.topology()['alive_synapses']==before+1
    event2=propose_action(m,'rewire',random.Random(11))
    assert event2 is not None and event2['old_source']!=event2['new_source']
    assert m.graph(torch.randn(3,48)).shape==(3,8)


def test_dendritic_branch_growth_preserves_older_weights_and_device():
    g=DendriticGraph(64,6,3,8,seed=4,initial_wiring_probability=0.)
    unit=g.units[2]
    old=unit.weights.detach().clone()
    m=GraphClassifier(g,3)
    info=propose_action(m,'branch',random.Random(12))
    target=m.graph.units[info['target']]
    assert target.weights.size(0)==4
    assert target.branch_mask.shape==(4,)
    assert target.weights.device==m.head.weight.device
    assert m(torch.rand(3,64)).shape==(3,3)
    if info['target']==2:
        assert torch.allclose(old,target.weights[:3])


def test_new_neuron_expands_classifier_and_graph_depth():
    m=GraphClassifier(DendriticGraph(48,6,2,6,seed=9,initial_wiring_probability=0.),3)
    info=propose_action(m,'neuron',random.Random(1))
    assert info['target']==6
    assert len(m.graph.units)==7 and m.head.in_features==7
    assert m(torch.rand(2,48)).shape==(2,3)
    assert m.graph.depths[-1]>=2


def test_actions_restrict_neuron_inputs_to_earlier_units():
    g=DendriticGraph(30,8,3,6,seed=10,initial_wiring_probability=0.,initial_synapse_fraction=.5)
    m=GraphClassifier(g,3)
    rng=random.Random(18)
    for action in ('synapse','rewire','branch','neuron','synapse','rewire'):
        propose_action(m,action,rng)
    refresh_depths(m.graph)
    for i,u in enumerate(m.graph.units):
        for src in u.source_ids.flatten().tolist():
            assert src<g.input_dim+i
    assert torch.isfinite(m(torch.randn(2,30))).all()


def test_selected_and_random_growth_runs_and_distinct_policies():
    torch.manual_seed(19)
    x=torch.rand(24,48);y=torch.randint(0,3,(24,))
    base=GraphClassifier(DendriticGraph(48,7,2,6,seed=13,
        initial_wiring_probability=0.,initial_synapse_fraction=.5),3)
    selected,events,_=development_selected(base,x,y,x,y,steps=4,trial_epochs=1,
             min_gain=-100.,seed=13,prune=0.)
    rnd,revents,_=development_random(base,x,y,steps=4,trial_epochs=1,seed=44,prune=0.)
    assert [e['action'] for e in events]==['synapse','rewire','branch','neuron']
    assert len(selected.graph.units)==8 and len(rnd.graph.units)==8
    assert len(revents)==4
    assert all(e['accepted']==1 for e in events)
    assert selected.graph.topology()['alive_synapses']>base.graph.topology()['alive_synapses']
    assert torch.isfinite(selected(x)).all()


def test_strict_selection_can_reject_all_development():
    x=torch.randn(15,24);y=torch.randint(0,2,(15,))
    base=GraphClassifier(DendriticGraph(24,6,2,5,seed=3,
       initial_wiring_probability=0.,initial_synapse_fraction=.5),2)
    chosen,events,_=development_selected(base,x,y,x,y,steps=4,
                     trial_epochs=1,min_gain=1000.,seed=2)
    assert all(not e['accepted'] for e in events)
    assert len(chosen.graph.units)==6
    assert chosen.graph.topology()['alive_synapses']==base.graph.topology()['alive_synapses']


def test_branch_ablation_restores_mask_and_evaluates_all_branches():
    x=torch.rand(13,24);y=torch.randint(0,3,(13,))
    m=GraphClassifier(DendriticGraph(24,5,3,6,seed=5),3)
    rows=branch_dependency(m,x,y,unit_ids=[1,3],max_units=2)
    assert len(rows)==6 and all('delta_test_loss' in row for row in rows)
    assert all(torch.all(u.branch_mask==1) for u in m.graph.units)


def test_branch_growth_on_meta_device():
    m=GraphClassifier(DendriticGraph(24,5,2,6,seed=21),3).to('meta')
    # Meta tensors contain no values, so source-selection logic requiring
    # nonzero()/tolist() cannot run; test the dynamic branch allocation directly.
    m.graph.units[2].add_branch([0]*6)
    assert m.graph.units[2].weights.device.type=='meta'
    assert m.graph.units[2].branch_mask.device.type=='meta'
    assert m(torch.empty(2,24,device='meta')).shape==(2,3)


@pytest.mark.skipif(not torch.cuda.is_available(),reason='CUDA unavailable in test environment')
def test_cuda_all_development_operations():
    device=torch.device('cuda',torch.cuda.current_device())
    m=GraphClassifier(DendriticGraph(24,6,3,7,seed=9,
          initial_wiring_probability=0.,initial_synapse_fraction=.5),3).to(device)
    rng=random.Random(9)
    for action in ('synapse','rewire','branch','neuron'):
        propose_action(m,action,rng)
        assert all(p.device==device for p in m.parameters())
        assert all(buf.device==device for buf in m.buffers())
        assert torch.isfinite(m(torch.rand(4,24,device=device))).all()


def test_checkpoint_restores_dynamic_branches_and_wiring(tmp_path):
    from neuro_weave.checkpoint import load_development_checkpoint
    graph=DendriticGraph(3*8*8,6,2,6,seed=4,initial_wiring_probability=0.,
                         initial_synapse_fraction=.5)
    model=GraphClassifier(graph,3)
    rng=random.Random(12)
    for action in ('synapse','rewire','branch','neuron'):
        propose_action(model,action,rng)
    ckpt=tmp_path/'one.pt'
    torch.save({'state_dict':model.state_dict(),
                'source_ids':[u.source_ids.tolist() for u in model.graph.units],
                'synapse_masks':[u.synapse_mask.tolist() for u in model.graph.units],
                'kind':'dendritic',
                'configuration':{'image_size':8,'branches':2,'fanin':6,
                                 'source_classes':3,'seed':4}},ckpt)
    loaded=load_development_checkpoint(ckpt)
    xx=torch.rand(2,3*8*8)
    assert torch.allclose(model.eval()(xx),loaded(xx),atol=1e-7)
