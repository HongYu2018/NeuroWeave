"""Paper-critical regression tests for the v1.6.6 audited research extension."""
import copy
import json
from pathlib import Path
import pytest
import torch
from neuro_weave.data import build_data
from neuro_weave.model import DendriticGraph,GraphClassifier
from neuro_weave.continual import build_stream,collect,expand_classes
from neuro_weave.continual_v166 import (parse_args,run,save_checkpoint_v166,load_checkpoint_v166)
from neuro_weave.paper_controls import (FrozenPrototypeGraph,current_task_importance,
    consolidate_importance,old_class_diagnostics,zero_replay_growth,structural_effect_test)


def mini_stream():
    b=build_data('synthetic',Path('unused'),31,size=8,source_classes=4,novel_classes=4,max_train=4,max_val=4)
    return build_stream(b,increment=2,shots=3)


def base():
    return GraphClassifier(DendriticGraph(192,5,2,5,seed=31,initial_wiring_probability=0.,initial_synapse_fraction=.5,spatial_sensory=True),4)


def test_history_importance_exists_at_zero_replay_and_changes_anchor():
    torch.manual_seed(1)
    ss=mini_stream();m=base();sx,sy=collect(ss.train,[0,1,2,3],'cpu')
    imp=current_task_importance(m,sx,sy,'cpu')
    assert imp and any(v.abs().sum()>0 for v in imp.values())
    old=copy.deepcopy(imp)
    expand_classes(m,6)
    nx,ny=collect(ss.train,[4,5],'cpu')
    fresh=current_task_importance(m,nx,ny,'cpu')
    merged=consolidate_importance(old,fresh,.9)
    assert merged['head.weight'].shape[0]==6
    assert torch.allclose(merged['head.weight'][:4],.9*old['head.weight']+.1*fresh['head.weight'][:4],atol=1e-5)
    assert merged['head.weight'].abs().sum()>0


def test_prototype_training_memory_only_and_old_logits_stable():
    ss=mini_stream();p=FrozenPrototypeGraph(base().graph,4)
    sx,sy=collect(ss.train,[0,1,2,3],'cpu')
    p.enroll(sx,sy)
    testx,testy=collect(ss.test,[0,1,2,3],'cpu')
    original=p(testx).detach().clone()
    before_graph=[t.detach().clone() for t in p.graph.parameters()]
    expand_classes(p,6)
    nx,ny=collect(ss.train,[4,5],'cpu')
    p.enroll(nx,ny)
    assert p(testx).shape==(len(testx),6)
    assert torch.allclose(original,p(testx)[:,:4])
    assert all(torch.equal(a,b) for a,b in zip(before_graph,p.graph.parameters()))
    assert not any(t.requires_grad for t in p.graph.parameters())


def test_prototype_checkpoint_with_new_classes_and_importance(tmp_path):
    ss=mini_stream();p=FrozenPrototypeGraph(base().graph,4)
    x,y=collect(ss.train,[0,1,2,3],'cpu');p.enroll(x,y)
    expand_classes(p,6)
    x2,y2=collect(ss.train,[4,5],'cpu');p.enroll(x2,y2)
    pred=p(x2).detach().clone()
    path=tmp_path/'proto.pt';save_checkpoint_v166(p,path,ss,1,'frozen_prototype',{})
    restored,info=load_checkpoint_v166(path)
    assert info['classifier_type']=='prototype'
    assert torch.allclose(restored(x2),pred,atol=1e-7)
    assert restored.class_prototypes.shape==(6,5)


def test_zero_replay_growth_does_not_consult_old_validation(monkeypatch):
    ss=mini_stream();m=base();prior=copy.deepcopy(m)
    nx,ny=collect(ss.train,[4,5],'cpu')
    imp=current_task_importance(prior,*collect(ss.train,[0,1,2,3],'cpu'),'cpu')
    anchor={n:p.detach().clone() for n,p in prior.named_parameters()}
    expand_classes(m,6,support_x=nx,support_y=ny)
    for c in range(6):ss.val[c]=None  # poison all historical validation images
    got,event,sec=zero_replay_growth(m,nx,ny,prior,anchor,imp,
      lr=.003,batch=16,epochs=1,seed=17,new_floor=2,min_gain=1e8)
    assert got.head.out_features==6
    assert event['selection_uses_historical_images']==0
    assert event['selection_uses_novel_validation_images']==0
    assert sec>=0


def test_old_class_competition_diagnostics_separate_old_only_from_full():
    ss=mini_stream();m=base();old=copy.deepcopy(m)
    expand_classes(m,6)
    with torch.no_grad():
        m.head.weight.zero_();m.head.bias.zero_();m.head.bias[4]=50.
    result=old_class_diagnostics(m,old,ss,[0,1,2,3],[4,5],'cpu')
    assert result['old_full_accuracy']==0.
    assert result['old_predictions_as_new_fraction']==1.
    assert 0<=result['old_only_accuracy']<=1
    assert result['graph_representation_RMSE']==pytest.approx(0.,abs=1e-7)


def test_replay_free_full_run_has_online_importance_and_prototype_control(tmp_path):
    args=parse_args(['--dataset','synthetic','--cpu','--output',str(tmp_path),
        '--source-classes','4','--novel-classes','4','--increment','2',
        '--image-size','8','--neurons','5','--branches','2','--fanin','5',
        '--max-train','4','--max-val','4','--fewshot','2','--memory','0',
        '--epochs','2','--adapt-epochs','2','--branch-trial-epochs','1'])
    rows,_=run(args)
    assert len(rows)==3*11
    assert (tmp_path/'old_new_competition_diagnostics.csv').exists()
    summary=json.loads((tmp_path/'run_summary.json').read_text())
    assert summary['zero_replay_selection_historical_data_blocked']
    assert summary['importance_retained_across_tasks']
    p,s=load_checkpoint_v166(tmp_path/'selective_plasticity_stage2.pt')
    assert s['online_importance'] and any(v.abs().sum()>0 for v in s['online_importance'].values())
    q,t=load_checkpoint_v166(tmp_path/'frozen_prototype_stage2.pt')
    assert q.class_prototypes.shape[0]==8
    z,u=load_checkpoint_v166(tmp_path/'point_frozen_prototype_stage2.pt')
    assert z.class_prototypes.shape[0]==8


@pytest.mark.skipif(not torch.cuda.is_available(),reason='CUDA not present here')
def test_cuda_prototype_and_importance_roundtrip(tmp_path):
    dev=torch.device('cuda',torch.cuda.current_device())
    ss=mini_stream();m=base().to(dev)
    sx,sy=collect(ss.train,[0,1,2,3],dev)
    imp=current_task_importance(m,sx,sy,dev)
    assert all(t.device==dev for t in imp.values())
    p=FrozenPrototypeGraph(copy.deepcopy(m.graph),4).to(dev);p.enroll(sx,sy)
    expand_classes(p,6)
    nx,ny=collect(ss.train,[4,5],dev);p.enroll(nx,ny)
    save_checkpoint_v166(p,tmp_path/'gpu.pt',ss,1,'frozen_prototype',{})
    q,_=load_checkpoint_v166(tmp_path/'gpu.pt',dev)
    assert torch.allclose(p(nx),q(nx),atol=1e-6)


def test_posthoc_accepted_branch_effect_and_state_restoration():
    ss=mini_stream();m=base();
    from neuro_weave.continual import propose_branch
    event=propose_branch(m,[0.]*len(m.graph.units),seed=22)
    event['accepted']=1
    xx,yy=collect(ss.test,[0,1,2,3],'cpu')
    original=m(xx).detach().clone()
    result=structural_effect_test(m,ss,[0,1,2,3],'cpu',event)
    assert result['test_ablation_applicable']==1
    assert torch.allclose(m(xx),original)
    assert isinstance(result['test_loss_increase_when_disabled'],float)


def test_posthoc_recruited_contact_effect_and_state_restoration():
    from neuro_weave.continual import recruit_constrained
    ss=mini_stream();m=base()
    event=recruit_constrained(m,[0.]*len(m.graph.units),seed=21,count=1)[0]
    event['accepted']=1
    x,y=collect(ss.test,[0,1,2,3],'cpu')
    old=m(x).detach().clone()
    got=structural_effect_test(m,ss,[0,1,2,3],'cpu',event)
    assert got['test_ablation_applicable']==1
    assert torch.allclose(old,m(x))
