# Archived result provenance

* `COIL_v21_seed11`: single-seed protected-core class-incremental recognition, per-method logs and configuration (source implementation available in `experiments/protected_core`).
* `digits_seed11` to `digits_seed15`: five-seed protected-core protocol, independent per-seed data splits, code in `experiments/protected_core`.
* `COIL_v166_audit_*`: frozen-representation versus expanding-classifier zero-replay audit, source code in `experiments/readout_audit`.
* `cifar10_graph_protocol_two_seed_means.csv`: manually transcribed two-seed aggregate from distinct CNN-to-graph protocol; original run source and seed logs not available in this archive.

Raw COIL-100 and CIFAR-10 images are not redistributed. Dataset acquisition is handled by experiment loaders. The provided CSVs are archived outcomes, not ground truth for training.
