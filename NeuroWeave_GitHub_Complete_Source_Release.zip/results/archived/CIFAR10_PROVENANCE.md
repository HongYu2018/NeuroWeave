# CIFAR-10 numeric evidence and source limitation

The CSV `cifar10_graph_protocol_two_seed_means.csv` contains **transcribed published aggregate means**, not independently recovered per-seed experimental logs. It records two seeds (7, 11) from a distinct protocol that used a CNN sensory representation of 48 features, graph growth, and task-specific readouts. The original training script and per-seed result files for that graph-construction experiment were **not present in the source archives available when this release was prepared**. Therefore the CSV alone cannot reproduce or independently verify its training run, and these values must not be pooled with the protected-core experiments.

The complete `experiments/protected_core` implementation includes an official-data CIFAR-10 loader and runnable, **unexecuted** protected-core CIFAR-10 experiment. It is a different experiment. New results from that runner must never be presented as reproducing this historical aggregate.

If the original CIFAR-10 graph-construction source and logs are recovered, they should be added with their checksums and the exact environment rather than retrofitted to existing methods.
